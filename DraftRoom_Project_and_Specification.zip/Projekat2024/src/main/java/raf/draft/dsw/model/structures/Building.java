package raf.draft.dsw.model.structures;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;

import java.awt.*;

@Getter
@Setter
public class Building extends DraftNodeComposite {
    @JsonIgnore
    private String oldName = "";
    @JsonIgnore
    private Color roomTabColor;

    public Building(String name, DraftNode parent) {
        super(name, parent);
    }

    @Override
    public void display(String name) {

    }

    @Override
    public void addChild(DraftNode child) {
        if(child != null && child instanceof Room){
            Room childRoom = (Room) child;

            if(!this.getChildren().contains(childRoom)){
                this.getChildren().add(childRoom);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void removeChild(DraftNode child) {
        if(child != null && child instanceof Room){
            Room childRoom = (Room) child;

            if(this.getChildren().contains(childRoom)){
                this.getChildren().remove(childRoom);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void setNodeName(String newName) {
        this.oldName = this.getName();
        this.setName(newName);
        notifySubscribers(this);
    }

}
