package raf.draft.dsw.state.concrete;

import com.sun.tools.javac.Main;
import raf.draft.dsw.controller.command.concrete.CopyPasteCommand;
import raf.draft.dsw.controller.command.concrete.RemoveCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.painters.itemPainters.*;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.Prototype;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CopyPasteState implements State {
    int offset = 0;

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        offset += 20;

        if(!roomView.getCopiedPainters().isEmpty()){

            CopyPasteCommand copyPasteCommand = new CopyPasteCommand(roomView, List.copyOf(roomView.getCopiedPainters()), offset);
            roomView.getCommandManager().addCommand(copyPasteCommand);

            //LOGIC MIGRATED TO CopyPasteCommand
//            Boolean showMessage = false;
//
//            for(ItemPainter painter : roomView.getCopiedPainters()){
//                int newX = ((RoomItem)painter.getNode()).getLocationX() + offset;
//                int newY = ((RoomItem)painter.getNode()).getLocationY() + offset;
//
//                if(!roomView.outOfRoomBounds(newX, newY, ((RoomItem)painter.getNode()).getWidth(), ((RoomItem)painter.getNode()).getWidth() )){
//
//                    Prototype copy = ((RoomItem) painter.getNode()).kloniraj();
//                    ((RoomItem) copy).setLocationX(((RoomItem) painter.getNode()).getLocationX() + offset);
//                    ((RoomItem) copy).setLocationY(((RoomItem) painter.getNode()).getLocationY() + offset);
//
//                    ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(roomView.getRoom(), (DraftNode) copy); // Adding child to model
//                    ((DraftNode)copy).addSubscriber(roomView);
//
//                    ItemPainter copyPainter = null;
//                    if(painter instanceof BedPainter){
//                        copyPainter = new BedPainter((DraftNode) copy);
//                    }if(painter instanceof BoilerPainter){
//                        copyPainter = new BoilerPainter((DraftNode) copy);
//                    }if(painter instanceof ClosetPainter){
//                        copyPainter = new ClosetPainter((DraftNode) copy);
//                    }if(painter instanceof DoorPainter){
//                        copyPainter = new DoorPainter((DraftNode) copy);
//                    }if(painter instanceof ShowerPainter){
//                        copyPainter = new ShowerPainter((DraftNode) copy);
//                    }if(painter instanceof SinkPainter){
//                        copyPainter = new SinkPainter((DraftNode) copy);
//                    }if(painter instanceof TablePainter){
//                        copyPainter = new TablePainter((DraftNode) copy);
//                    }if(painter instanceof ToiletPainter){
//                        copyPainter = new ToiletPainter((DraftNode) copy);
//                    }if(painter instanceof WasherPainter){
//                        copyPainter = new WasherPainter((DraftNode) copy);
//                    }
//
//                    roomView.getPainters().add(copyPainter);
//
//                }else{
//                    showMessage = true;
//                }
//            }
//
//            if(showMessage){
//                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
//            }
        }
    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
        MainFrame.getInstance().getMountedProject().openRoom().getCopiedPainters().clear();
        offset = 0;

        if(MainFrame.getInstance().getMountedProject().openRoom() != null) {
            if (MainFrame.getInstance().getMountedProject().openRoom().getSelectedPainters().isEmpty()) {
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NOTHING_COPIED);
            } else {
                List<ItemPainter> painters = new ArrayList<>();
                for (ItemPainter painter : MainFrame.getInstance().getMountedProject().openRoom().getSelectedPainters()) {
                    painters.add(painter);
                }
                MainFrame.getInstance().getMountedProject().openRoom().setCopiedPainters(painters);
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEMS_COPIED);
            }
        }
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
