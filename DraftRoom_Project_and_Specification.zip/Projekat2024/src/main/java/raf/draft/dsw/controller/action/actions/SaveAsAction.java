package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

public class SaveAsAction extends AbstractRoomAction {

    public SaveAsAction(){
        putValue(SMALL_ICON, loadIcon("/images/saveAs.png"));
        putValue(NAME, "Save As");
        putValue(SHORT_DESCRIPTION, "Save As");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            JFileChooser jfc = new JFileChooser();

            Project project = (Project) MainFrame.getInstance().getMountedProject().getRelatedProject();
            File projectFile = null;

            if (project.getPathToFolder().equals("Not Defined") || project.getPathToFolder().isEmpty()) {
                if (jfc.showSaveDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
                    projectFile = jfc.getSelectedFile();
                    project.setPathToFolder(projectFile.getPath());
                } else {
                    return;
                }

            }

            try {
                ApplicationFramework.getInstance().getSerializer().saveProjectAs(project);
                project.setChanged(false);
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.PROJECT_SAVED);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }

        }
    }
}
