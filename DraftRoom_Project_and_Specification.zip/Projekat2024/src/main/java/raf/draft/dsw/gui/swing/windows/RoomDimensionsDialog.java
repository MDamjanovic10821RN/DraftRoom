package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.action.actions.CreateNodeAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.*;

public class RoomDimensionsDialog extends JDialog {
    private JTextField widthField;
    private JTextField lengthField;
    private JButton createRoomButton;
    private int width;
    private int length;

    CreateNodeAction controllerClass;

    public RoomDimensionsDialog(CreateNodeAction createNodeAction) {
        controllerClass = createNodeAction;

        setTitle("Room Dimensions");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setResizable(false);
        getContentPane().setBackground(new Color(240, 240, 240));

        // Panel for input fields
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Width input
        JLabel widthLabel = new JLabel("Width(cm):");
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(widthLabel, gbc);

        widthField = new JTextField();
        widthField.setPreferredSize(new Dimension(90, 25));
        gbc.gridx = 1; gbc.gridy = 0;
        inputPanel.add(widthField, gbc);

        // Length input
        JLabel lengthLabel = new JLabel("Length(cm):");
        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(lengthLabel, gbc);

        lengthField = new JTextField();
        lengthField.setPreferredSize(new Dimension(100, 25));
        gbc.gridx = 1; gbc.gridy = 1;
        inputPanel.add(lengthField, gbc);

        add(inputPanel, BorderLayout.CENTER);

        // Create Room button
        createRoomButton = new JButton("Create Room");
        stylizeButton(createRoomButton);

        createRoomButton.addActionListener(e -> {
            try {
                width = Integer.parseInt(widthField.getText());
                length = Integer.parseInt(lengthField.getText());

                if (width <= 0 || length <= 0) {
                    MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.INVALID_TYPES);
                    dispose();
                    return;
                }

                DraftTreeItem selectedNode = MainFrame.getInstance().getDraftTree().getSelectedNode();
                if(selectedNode.getDraftNode() instanceof Project){
                    controllerClass.addChildToProject("ROOM", width, length);
                }else if(selectedNode.getDraftNode() instanceof Building){
                    controllerClass.addRoomToBuilding(width, length);
                }

            } catch (NumberFormatException ex) {
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.INVALID_TYPES);
            }
            dispose();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(createRoomButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setModal(true);
        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

}
