package raf.draft.dsw.gui.swing;

import raf.draft.dsw.controller.action.actions.CreateNodeAction;
import raf.draft.dsw.controller.action.actions.DeleteNodeAction;
import raf.draft.dsw.controller.action.actions.EditNodeAction;
import raf.draft.dsw.controller.action.actions.ExitAction;

import javax.swing.*;
import java.awt.*;

public class MyToolBar extends JToolBar {
    public MyToolBar(){
        super(HORIZONTAL);
        setFloatable(false);

        ExitAction ea = new ExitAction();
        CreateNodeAction cna = new CreateNodeAction();
        EditNodeAction ena = new EditNodeAction();
        DeleteNodeAction dna = new DeleteNodeAction();

        add(ea);
        add(cna);
        add(dna);
        add(ena);
        addSeparator();
        add(MainFrame.getInstance().getActionManager().getUseRoomTemplateAction());
        add(MainFrame.getInstance().getActionManager().getSaveRoomAsTemplateAction());

        addSeparator();
        add(Box.createHorizontalGlue());

        add(MainFrame.getInstance().getActionManager().getUndoAction());
        add(MainFrame.getInstance().getActionManager().getRedoAction());
        addSeparator(new Dimension(33, 0));
        add(MainFrame.getInstance().getActionManager().getSaveAsAction());
        add(MainFrame.getInstance().getActionManager().getSaveAction());

    }
}
