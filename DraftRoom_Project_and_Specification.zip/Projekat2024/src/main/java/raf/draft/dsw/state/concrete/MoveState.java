package raf.draft.dsw.state.concrete;

import com.sun.tools.javac.Main;
import raf.draft.dsw.controller.command.concrete.MoveCommand;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MoveState implements State {
    private RoomView currRoomView;
    private int startX; // Starting mouse x-coordinate
    private int startY; // Starting mouse y-coordinate
    private int deltaX;
    private int deltaY;
    private ItemPainter movingPainter; // The painter being moved
    private Boolean selection = false;

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.startX = x;
        this.startY = y;

        // Check if the mouse press is inside any painter
        for(ItemPainter painter : roomView.getPainters()) {
            if (painter.itemAt(new Point(x, y))) {
                movingPainter = painter;

                if(roomView.getSelectedPainters().contains(movingPainter)){
                    selection = true;
                }else{
                    selection = false;
                }

                break;
            }
        }
    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {
        if(movingPainter != null) {
            // Offset
            deltaX = x - startX;
            deltaY = y - startY;

            if(selection){
                for(ItemPainter painter : roomView.getSelectedPainters()){
                    RoomItem item = (RoomItem) painter.getNode();
                    painter.setTempX(item.getLocationX() + deltaX);
                    painter.setTempY(item.getLocationY() + deltaY);
                }
            }else {
                RoomItem item = (RoomItem) movingPainter.getNode();
                movingPainter.setTempX(item.getLocationX() + deltaX);
                movingPainter.setTempY(item.getLocationY() + deltaY);
            }

            /**
             * repaint se poziva na osnovu promenjene privremene vrednosti koordinata unutar samih paintera.
             * Potrebne su privremene koordinate da bi se odrzala mogucnost vracanja u OG poziciju prilikom preklapanja itema.
             */
            roomView.repaint();
        }
    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {
        if(movingPainter != null) {
            // Get the painter's current top-left coordinates
            deltaX = x - startX;
            deltaY = y - startY;

            if(selection){
                boolean allAreValid = true;

                // Validation loop -> ALL-OR-NOTHING approach
                for(ItemPainter painter : roomView.getSelectedPainters()){
                    RoomItem item = (RoomItem) painter.getNode();
                    int newX = item.getLocationX() + deltaX;
                    int newY = item.getLocationY() + deltaY;

                    boolean isValid = !roomView.outOfRoomBounds(newX, newY, item.getWidth(), item.getLength()) &&
                            !roomView.isIntersectingWithNonSelectedItems(item, newX, newY, item.getWidth(), item.getLength());

                    if(!isValid) {
                        allAreValid = false;
                        break;
                    }
                }

                if(allAreValid){
                    MoveCommand moveCommand = new MoveCommand(currRoomView, List.copyOf(roomView.getSelectedPainters()), deltaX, deltaY);
                    currRoomView.getCommandManager().addCommand(moveCommand);

                    //LOGIC MIGRATED TO MoveCommand
//                    // Updating models loop
//                    for(ItemPainter painter : roomView.getSelectedPainters()){
//                        RoomItem item = (RoomItem) painter.getNode();
//                        int newX = item.getLocationX() + deltaX;
//                        int newY = item.getLocationY() + deltaY;
//
//                        painter.setTempX(newX);
//                        painter.setTempY(newY);
//
//                        // Applying snapping to room borders
//                        applyBorderSnapping(painter);
//
//                        // To trigger update in Roomview when movement is validated ;)
//                        item.setCoords(painter.getTempX(), painter.getTempY());
//                    }
                }else{
                    // Reset loop
                    for(ItemPainter painter : roomView.getSelectedPainters()){
                        RoomItem item = (RoomItem) painter.getNode();

                        painter.setTempX(item.getLocationX());
                        painter.setTempY(item.getLocationY());
                    }
                    /**
                     * repaint se poziva na osnovu promenjene privremene vrednosti koordinata unutar samih paintera.
                     * Ovde se vraca privremena vrednost na prvobitnu... kad je izmenjena u modelu-> preko update() se azurira prikaz
                     */
                    currRoomView.repaint();
                }

            }else{
                RoomItem item = (RoomItem) movingPainter.getNode();

                int newX = item.getLocationX() + deltaX;
                int newY = item.getLocationY() + deltaY;

                // Validation
                boolean isValid = !roomView.outOfRoomBounds(newX, newY, item.getWidth(), item.getLength()) &&
                        !roomView.isIntersectingWithOtherItems(item, newX, newY, item.getWidth(), item.getLength());

                if (isValid) {
                    List<ItemPainter> painterList = new ArrayList<>();
                    painterList.add(movingPainter);

                    MoveCommand moveCommand = new MoveCommand(currRoomView, painterList, deltaX, deltaY);
                    currRoomView.getCommandManager().addCommand(moveCommand);

                    //LOGIC MIGRATED TO MoveCommand
//                    movingPainter.setTempX(newX);
//                    movingPainter.setTempY(newY);
//
//                    // Applying snapping to room borders
//                    applyBorderSnapping(movingPainter);
//
//                    // To trigger update in Roomview when movement is validated ;)
//                    item.setCoords(movingPainter.getTempX(), movingPainter.getTempY());

                } else {
                    movingPainter.setTempX(item.getLocationX());
                    movingPainter.setTempY(item.getLocationY());
                    /**
                     * repaint se poziva na osnovu promenjene privremene vrednosti koordinata unutar samih paintera.
                     * Ovde se vraca privremena vrednost na prvobitnu... kad je izmenjena u modelu-> preko update() se azurira prikaz
                     */
                    currRoomView.repaint();
                }
            }

            movingPainter = null;
        }
    }

    /**
     * Privatna metoda koju samo koristi MoveState.MouseReleased -> ne narusava se state sablon
     */
    private Boolean applyBorderSnapping(ItemPainter painter) {
        RoomItem roomItem = (RoomItem) painter.getNode();
        Boolean snapped = false;

        // Top border
        if (Math.abs(painter.getTempY() - currRoomView.getRoomTopLeft().y) <= 10) {
            roomItem.setLocationY(currRoomView.getRoomTopLeft().y);
            painter.setTempY(currRoomView.getRoomTopLeft().y);
            snapped = true;
        }

        // Left border
        if (Math.abs(painter.getTempX() - currRoomView.getRoomTopLeft().x) <= 10) {
            roomItem.setLocationX(currRoomView.getRoomTopLeft().x);
            painter.setTempX(currRoomView.getRoomTopLeft().x);
            snapped = true;
        }

        // Bottom border
        if (Math.abs(currRoomView.getRoomBottomRight().y - (painter.getTempY() + roomItem.getLength() * currRoomView.getCmToPx())) <= 10) {
            int newY = (int) (currRoomView.getRoomBottomRight().y - roomItem.getLength() * currRoomView.getCmToPx());
            roomItem.setLocationY(newY);
            painter.setTempY(newY);
            snapped = true;
        }

        // Right border
        if (Math.abs(currRoomView.getRoomBottomRight().x - (painter.getTempX() + roomItem.getWidth() * currRoomView.getCmToPx())) <= 10) {
            int newX = (int) (currRoomView.getRoomBottomRight().x - roomItem.getWidth() * currRoomView.getCmToPx());
            roomItem.setLocationX(newX);
            painter.setTempX(newX);
            snapped = true;
        }

        return snapped;
    }

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(true);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().setTempRoomPainterCoordinates();
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
