package raf.draft.dsw.state.concrete;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

public class ZoomState implements State {

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {

    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
