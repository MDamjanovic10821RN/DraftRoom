package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.action.actions.EditNodeAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.*;

public class EditProjectDialog extends JDialog{

    private EditNodeAction editNodeAction;
    private JButton button;
    private JTextField nameField;
    private JTextField authorField;
    private JTextField pathField;
    private JLabel nameLabel;
    private JLabel authorLabel;
    private JLabel pathLabel;

    public EditProjectDialog(EditNodeAction editNodeAction){
        super(MainFrame.getInstance(), "Edit Project", true);
        this.editNodeAction = editNodeAction;

        Project project = (Project) MainFrame.getInstance().getDraftTree().getSelectedNode().getDraftNode();

        setSize(400, 200);
        setLocationRelativeTo(null);

        nameLabel = new JLabel("New Name:");
        nameField = new JTextField(15);
        nameField.setText(project.getName());

        authorLabel = new JLabel("New Author:");
        authorField = new JTextField(15);
        authorField.setText(project.getAuthor());

        pathLabel = new JLabel("New Path:");
        pathField = new JTextField(15);
        pathField.setText(project.getPathToFolder());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(authorLabel);
        inputPanel.add(authorField);
        inputPanel.add(pathLabel);
        inputPanel.add(pathField);

        button = new JButton("Save");
        stylizeButton(button);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(button);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        button.addActionListener(e -> {
            if (nameField.getText().isEmpty() || authorField.getText().isEmpty()) {
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.FIELDS_CANNOT_BE_EMPTY);
            }else if(ApplicationFramework.getInstance().getDraftRoomRepository().exists(nameField.getText())
                    && (ApplicationFramework.getInstance().getDraftRoomRepository().getElement(nameField.getText()) != (DraftNode) project)){
                System.out.println(nameField.getText()+"is found in the repository");
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.DUPLICATES_NOT_PERMITTED);
            }else {
                editNodeAction.editProject(project, nameField.getText(), authorField.getText(), pathField.getText()); //Radi postovanja MVC
            }
            MainFrame.getInstance().getDraftTree().refresh();
            dispose();
        });

        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

}
