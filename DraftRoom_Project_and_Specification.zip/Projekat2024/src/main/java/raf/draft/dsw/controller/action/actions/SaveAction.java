package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

public class SaveAction extends AbstractRoomAction {

    public SaveAction(){
        putValue(SMALL_ICON, loadIcon("/images/save.png"));
        putValue(NAME, "Save");
        putValue(SHORT_DESCRIPTION, "Save");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){

            Project project = (Project) MainFrame.getInstance().getMountedProject().getRelatedProject();

            if (!project.isChanged()) {
                return;
            }

            String filePath = project.getPathToFolder();
            boolean isValidPath = filePath != null && !filePath.isEmpty() && new File(filePath).exists();

            if(!isValidPath){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.SAVE_AS_FIRST);
                return;
            }

            try {
                ApplicationFramework.getInstance().getSerializer().saveProject(project);
                project.setChanged(false);
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.PROJECT_SAVED);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}
