package raf.draft.dsw.controller.action.actions;

import lombok.SneakyThrows;
import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.controller.serializer.DraftSerializer;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.windows.AddProjectChildDialog;
import raf.draft.dsw.gui.swing.windows.RoomDimensionsDialog;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

public class UseRoomTemplateAction extends AbstractRoomAction {

    public UseRoomTemplateAction(){
        putValue(SMALL_ICON, loadIcon("/images/openTemplate.png"));
        putValue(NAME, "Use Room Template");
        putValue(SHORT_DESCRIPTION, "Use a Room Template");
    }

    @SneakyThrows
    @Override
    public void actionPerformed(ActionEvent e) {

        DraftTreeItem selectedNode = MainFrame.getInstance().getDraftTree().getSelectedNode();

        if(selectedNode instanceof DraftTreeItem){
            if(selectedNode.getDraftNode() instanceof Project || selectedNode.getDraftNode() instanceof Building){
                //TO DO: treba da se otvori jFileChooser na lokaciji templates i onemguciti korisniku da promeni putanju(ako je moguce);
                // ovo je za load
                // proslediti tu putanju serializeru.load i otpakovati tamo json i od tih informacija napraviti room(slicno kao load project).
                // ta funkcija treba ovde da vrati DraftNode koji treba da se ubaci u stablo kao dete datom selected nodu.(uzmi primer is openProjectAction

                String resourcesPath = new File("src/main/resources/templates").getCanonicalPath();

                // Create and configure the file chooser
                JFileChooser fileChooser = new JFileChooser(resourcesPath) {
                    @Override
                    public void changeToParentDirectory() {
                        if (!getCurrentDirectory().getAbsolutePath().equals(resourcesPath)) {
                            super.changeToParentDirectory();
                        }
                    }

                    @Override
                    public void approveSelection() {
                        File selectedFile = getSelectedFile();
                        try {
                            if (!selectedFile.getCanonicalPath().startsWith(resourcesPath)) {
                                JOptionPane.showMessageDialog(this,
                                        "You cannot select files outside the resources directory.",
                                        "Invalid Selection",
                                        JOptionPane.WARNING_MESSAGE);
                                return;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                            return;
                        }
                        super.approveSelection();
                    }
                };

                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
                fileChooser.setDialogTitle("Select a Template File");
                fileChooser.setAcceptAllFileFilterUsed(true);

                // Open the file chooser dialog
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {

                    try {
                        ApplicationFramework.getInstance().getSerializer().loadTemplate(fileChooser.getSelectedFile().getPath()
                                , selectedNode);

                    }catch (NullPointerException exception){
                        MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.MUST_OPEN_PROJECT_FIRST);
                    }

                }else{
                    System.out.println("ERROR: no file was selected");
                }







            }else{
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.HOW_TO_LOAD_TEMPLATE);
            }
        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.HOW_TO_LOAD_TEMPLATE);
        }



        //TODO: PRVO PROCITATI SPECIFIKACIJU!
        // Neka olaksica kao ideja: mozda da gleda koji treeNode je selektovan u stablu. ako je pokrenuta ova akcija,
        // a taj node koji je selektovan je tipa Project -> napraviti novu sobu, metnuti svu novu decu i sve atribute (osim imena) iz JSON-a
        // koji se nalazi na putanji resources/templates kojeg je korisnik izabrao. U suprotnom nista nemoj da se deci ili nek sa baci neki error. tako nesto...

    }

}
