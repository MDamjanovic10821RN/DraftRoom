package raf.draft.dsw.gui.swing.windows;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.controller.command.CommandManager;
import raf.draft.dsw.controller.listeners.RoomMouseListener;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.painters.itemPainters.*;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;
import raf.draft.dsw.state.StateType;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class RoomView extends JPanel implements ISubscriber {

    private Room room;
    private RoomMouseListener mouseListener;
    private CommandManager commandManager;

    private double cmToPx;

    // Room coordinates:
    private Point roomTopLeft;
    private Point roomBottomRight;

    // Painters
    private List<ItemPainter> painters;
    private List<ItemPainter> selectedPainters;
    private List<ItemPainter> copiedPainters;
    private ItemPainter clickedPainter = null;

    // Selection visual
    private Rectangle selectionRectangle = null;

    public RoomView(Room room, RoomMouseListener roomMouseListener){
        this.room = room;
        room.addSubscriber(this);
        this.setMouseListener(roomMouseListener);
        this.commandManager = new CommandManager(this);

        this.painters = new ArrayList<>();
        loadPainters(); // Loading painters from room node
        this.selectedPainters = new ArrayList<>();
        this.copiedPainters = new ArrayList<>();
    }


    public void setMouseListener(RoomMouseListener roomMouseListener){
        this.mouseListener = roomMouseListener;

        this.addMouseListener(mouseListener);
        this.addMouseMotionListener(mouseListener);
        this.addMouseWheelListener(mouseListener);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //----------------------------------------------------------Preparations:
        // Panel dimensions
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        // Room dimensions in cm
        double roomWidthCm = room.getRoomWidth();
        double roomHeightCm = room.getRoomLength();

        // Scaling factor (cm -> pixels) - always use smaller one
        cmToPx = Math.min(panelWidth / roomWidthCm, panelHeight / roomHeightCm);

        // Calculating room dimensions in pixels
        int rectWidth = (int) (roomWidthCm * cmToPx);
        int rectHeight = (int) (roomHeightCm * cmToPx);

        //------------------------------------------------------------------Room:
        // Centering room
        int xOffset = (panelWidth - rectWidth) / 2;
        int yOffset = (panelHeight - rectHeight) / 2;

        // Saving room coordinates
        roomTopLeft = new Point(xOffset, yOffset);
        roomBottomRight = new Point(xOffset + rectWidth, yOffset + rectHeight);

        // ROOM EDGES
        g2d.setColor(Color.WHITE);
        g2d.fillRect(xOffset, yOffset, rectWidth, rectHeight);

        // ROOM BORDER
        g2d.setColor(Color.BLACK);
        g2d.drawRect(xOffset, yOffset, rectWidth, rectHeight);

        //------------------------------------------------------------Room Items:
        for(ItemPainter painter : painters){
            paintScaledItem(g2d, painter);
        }

        //---------------------------------------------------Selection Rectangle:
        if (selectionRectangle != null) {
            g2d.setColor(new Color(0, 0, 255, 50)); // Transparent
            g2d.fill(selectionRectangle);

            g2d.setStroke(new BasicStroke(1));
            g2d.setColor(Color.BLUE); // Border
            g2d.draw(selectionRectangle);
        }

    }

    private void paintScaledItem(Graphics2D g2d, ItemPainter painter) {
        RoomItem item = (RoomItem) painter.getNode();

        // Original dimensions in cm
        int widthCm = item.getWidth();
        int heightCm = item.getLength();

        int scaledWidth = 0;
        int scaledHeight = 0;

        // If resizeState active -> must preview temporary dimensions
        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()){
            scaledWidth = painter.getTempScaledWidth();
            scaledHeight = painter.getTempScaledLength();
        }else {
            // Scaling dimensions to pixels
            scaledWidth = (int) (widthCm * cmToPx);
            scaledHeight = (int) (heightCm * cmToPx);
        }

        // Calling the right painter for given item
        if(painter instanceof BedPainter bedPainter){
            painter.paint(g2d, (RoomItem) bedPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof BoilerPainter boilerPainter){
            painter.paint(g2d, (RoomItem) boilerPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof ClosetPainter closetPainter){
            painter.paint(g2d, (RoomItem) closetPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof DoorPainter doorPainter){
            painter.paint(g2d, (RoomItem) doorPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof ShowerPainter showerPainter){
            painter.paint(g2d, (RoomItem) showerPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof SinkPainter sinkPainter){
            painter.paint(g2d, (RoomItem) sinkPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof TablePainter tablePainter){
            painter.paint(g2d, (RoomItem) tablePainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof ToiletPainter toiletPainter){
            painter.paint(g2d, (RoomItem) toiletPainter.getNode(), scaledWidth, scaledHeight);

        }else if(painter instanceof WasherPainter washerPainter){
            painter.paint(g2d, (RoomItem) washerPainter.getNode(), scaledWidth, scaledHeight);
        }
    }

    public void loadPainters(){
        for(DraftNode item : room.getChildren()){

            item.addSubscriber(this); // adding roomview as a subscriber to roomItem

            if(item instanceof Bed){
                this.painters.add(new BedPainter((Bed)item));
            }else if(item instanceof Boiler){
                this.painters.add(new BoilerPainter((Boiler)item));
            }else if(item instanceof Closet){
                this.painters.add(new ClosetPainter((Closet)item));
            }else if(item instanceof Door){
                this.painters.add(new DoorPainter((Door)item));
            }else if(item instanceof Shower){
                this.painters.add(new ShowerPainter((Shower)item));
            }else if(item instanceof Sink){
                this.painters.add(new SinkPainter((Sink)item));
            }else if(item instanceof Table){
                this.painters.add(new TablePainter((Table)item));
            }else if(item instanceof Toilet){
                this.painters.add(new ToiletPainter((Toilet)item));
            }else if(item instanceof Washer){
                this.painters.add(new WasherPainter((Washer)item));
            }
        }
    }

    public void setTemporaryDimensions(){
        for(ItemPainter painter : painters){
            painter.setTempScaledWidth((int) (((RoomItem)painter.getNode()).getWidth() * cmToPx));
            painter.setTempScaledLength((int) (((RoomItem)painter.getNode()).getLength() * cmToPx));
        }
    }

    public void setTemporaryCoords(){
        for(ItemPainter painter : painters){
            painter.setTempX(((RoomItem)painter.getNode()).getLocationX());
            painter.setTempY(((RoomItem)painter.getNode()).getLocationY());
        }
    }

    public void deselectAll(){
        for(ItemPainter painter : selectedPainters){
            painter.setSelected(false);
        }
    }

    public Boolean outOfRoomBounds(int x, int y, int w, int l) {
        int scaledWidth = (int) (w * cmToPx);
        int scaledLength = (int) (l * cmToPx);

        // Checking bounds
        boolean outOfBounds = x < roomTopLeft.x || y < roomTopLeft.y || (x + scaledWidth) > roomBottomRight.x || (y + scaledLength) > roomBottomRight.y;
        return outOfBounds;
    }

    /**
     * Is used when creating a new RoomItem
     */
    public boolean isIntersectingExistingItems(int x, int y, int w, int l) {
        int scaledWidth = (int) (w * cmToPx);
        int scaledLength = (int) (l * cmToPx);

        // Potential item bounds as rectangle
        Rectangle newItemBounds = new Rectangle(x, y, scaledWidth, scaledLength);

        // Check intersection with each existing painter
        for (ItemPainter painter : painters) {
            RoomItem existingItem = (RoomItem) painter.getNode();

            int existingWidth = (int) (existingItem.getWidth() * cmToPx);
            int existingLength = (int) (existingItem.getLength() * cmToPx);

            // Getting existing item's position
            int existingX = existingItem.getLocationX();
            int existingY = existingItem.getLocationY();

            // Existing item's bounds as a rectangle
            Rectangle existingItemBounds = new Rectangle(existingX, existingY, existingWidth, existingLength);

            // Checking if the new item intersects with existing item's rectangle
            if (newItemBounds.intersects(existingItemBounds)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Is used when editing an item. Item can only intersect with itself.
     */
    public boolean isIntersectingWithOtherItems(RoomItem item, int x, int y, int w, int l) {
        int scaledWidth = (int) (w * cmToPx);
        int scaledLength = (int) (l * cmToPx);

        // Potential item bounds as rectangle
        Rectangle newItemBounds = new Rectangle(x, y, scaledWidth, scaledLength);

        // Check intersection with each existing painter
        for (ItemPainter painter : painters) {
            RoomItem existingItem = (RoomItem) painter.getNode();

            if(item != existingItem) {
                int existingWidth = (int) (existingItem.getWidth() * cmToPx);
                int existingLength = (int) (existingItem.getLength() * cmToPx);

                // Getting existing item's position
                int existingX = existingItem.getLocationX();
                int existingY = existingItem.getLocationY();

                // Existing item's bounds as a rectangle
                Rectangle existingItemBounds = new Rectangle(existingX, existingY, existingWidth, existingLength);

                // Checking if the new item intersects with existing item's rectangle
                if (newItemBounds.intersects(existingItemBounds)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Is used when moving selected group.
     */
    public boolean isIntersectingWithNonSelectedItems(RoomItem item, int x, int y, int w, int l) {
        int scaledWidth = (int) (w * cmToPx);
        int scaledLength = (int) (l * cmToPx);

        // Potential item bounds as rectangle
        Rectangle newItemBounds = new Rectangle(x, y, scaledWidth, scaledLength);

        // Check intersection with each existing painter
        for (ItemPainter painter : painters) {
            RoomItem existingItem = (RoomItem) painter.getNode();

            if(item != existingItem && !selectedPainters.contains(painter)) {
                int existingWidth = (int) (existingItem.getWidth() * cmToPx);
                int existingLength = (int) (existingItem.getLength() * cmToPx);

                // Getting existing item's position
                int existingX = existingItem.getLocationX();
                int existingY = existingItem.getLocationY();

                // Existing item's bounds as a rectangle
                Rectangle existingItemBounds = new Rectangle(existingX, existingY, existingWidth, existingLength);

                // Checking if the new item intersects with existing item's rectangle
                if (newItemBounds.intersects(existingItemBounds)) {
                    return true;
                }
            }
        }

        return false;
    }

    /** Used for SelectState rectangle **/
    public List<ItemPainter> intersects(Rectangle rect) {
        List<ItemPainter> intersectingPainters = new ArrayList<>();

        // Check intersection with each existing painter
        for (ItemPainter painter : painters) {
            RoomItem existingItem = (RoomItem) painter.getNode();

            int existingWidth = (int) (existingItem.getWidth() * cmToPx);
            int existingLength = (int) (existingItem.getLength() * cmToPx);

            // Getting existing item's position
            int existingX = existingItem.getLocationX();
            int existingY = existingItem.getLocationY();

            // Existing item's bounds as a rectangle
            Rectangle existingItemBounds = new Rectangle(existingX, existingY, existingWidth, existingLength);

            // Checking if the new item intersects with existing item's rectangle
            if (rect.intersects(existingItemBounds)) {
                intersectingPainters.add(painter);
            }

        }
        return intersectingPainters;
    }

    public ItemPainter clickedPainter(Point pos){

        for(ItemPainter painter : painters){
            if(painter.itemAt(pos)){
                this.clickedPainter = painter;
                return painter;
            }
        }

        this.clickedPainter = null;
        return null;
    }


    @Override
    public void update(Object notification) {
        ((Project)MainFrame.getInstance().getMountedProject().getRelatedProject()).setChanged(true);

        // A child of room has been deleted from tree -> must update
        if(painters.size() > room.getChildren().size()){
            ItemPainter painterForDelete = getDeletedNodePainter();
            if(painterForDelete != null){
                painters.remove(painterForDelete);
            }
        // A child has been added through template choice
        }else if(painters.size() < room.getChildren().size() && room.getFromTemplate()){
            for(DraftNode node : room.getChildren()){
                Boolean found = false;
                String nodeName = node.getName();

                for(ItemPainter painter : painters){
                    if(painter.getNode().getName().equals(nodeName)) {
                        found = true;
                        break;
                    }
                }

                if(!found){
                    painters.add(newItemPainter(node));
                    room.setFromTemplate(false);
                }

            }
        }

        repaint();
    }

    public ItemPainter newItemPainter(DraftNode node){
        ItemPainter painter = null;
        if(node instanceof Bed){
            painter = new BedPainter(node);
        }else if(node instanceof Boiler){
            painter = new BoilerPainter(node);
        }else if(node instanceof Closet){
            painter = new ClosetPainter(node);
        }else if(node instanceof Door){
            painter = new DoorPainter(node);
        }else if(node instanceof Shower){
            painter = new ShowerPainter(node);
        }else if(node instanceof Sink){
            painter = new SinkPainter(node);
        }else if(node instanceof Table){
            painter = new TablePainter(node);
        }else if(node instanceof Toilet){
            painter = new ToiletPainter(node);
        }else if(node instanceof Washer){
            painter = new WasherPainter(node);
        }
        return painter;
    }

    public void clearSelectedPainters(){
        for(ItemPainter painter : selectedPainters){
            painter.setSelected(false);
        }
        selectedPainters.clear();
    }

    public Rectangle createRectangle(Point p1, Point p2) {
        int x = Math.min(p1.x, p2.x);
        int y = Math.min(p1.y, p2.y);
        int width = Math.abs(p1.x - p2.x);
        int height = Math.abs(p1.y - p2.y);
        return new Rectangle(x, y, width, height);
    }

    public void setSelectionRectangle(Point start, Point end) {
        if (start == null || end == null) {
            this.selectionRectangle = null;
            return;
        }
        int x = Math.min(start.x, end.x);
        int y = Math.min(start.y, end.y);
        int width = Math.abs(start.x - end.x);
        int height = Math.abs(start.y - end.y);
        this.selectionRectangle = new Rectangle(x, y, width, height);
    }

    public ItemPainter getDeletedNodePainter(){

        List<DraftNode> childList = room.getChildren();

        for(ItemPainter painter : painters){
            if(!childList.contains(painter.getNode())){
                return painter;
            }
        }

        return null;
    }

    @Override
    public String toString() {
        return "RoomView{" +
                "room=" + room +
                '}';
    }
}
