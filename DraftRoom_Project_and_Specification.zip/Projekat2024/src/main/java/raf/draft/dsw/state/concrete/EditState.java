package raf.draft.dsw.state.concrete;

import lombok.Getter;
import raf.draft.dsw.controller.command.concrete.EditCommand;
import raf.draft.dsw.controller.command.concrete.ResizeCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.EditItemDialog;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;

@Getter
public class EditState implements State {
    private RoomView currRoomView;
    ItemPainter clickedPainter;
    private int x;
    private int y;
    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.x = x;
        this.y = y;

        Room room = (Room)roomView.getRoom();
        this.clickedPainter = roomView.clickedPainter(new Point(x, y));

        if(clickedPainter != null) {
            EditItemDialog editItemDialog = new EditItemDialog();
        }
    }

    @Override
    public void edit(String name, int width, int length){
        DraftNode node = clickedPainter.getNode();

        int scaledWidth = (int)(width * currRoomView.getCmToPx());
        int scaledLength = (int)(length * currRoomView.getCmToPx());
        int nodeX = ((RoomItem)node).getLocationX();
        int nodeY = ((RoomItem)node).getLocationY();

        if(!currRoomView.outOfRoomBounds(nodeX, nodeY, scaledWidth, scaledLength) && !currRoomView.isIntersectingWithOtherItems((RoomItem) node, nodeX, nodeY, scaledWidth, scaledLength)){

            EditCommand editCommand = new EditCommand(currRoomView, clickedPainter, width, length, name);
            currRoomView.getCommandManager().addCommand(editCommand);

            //((RoomItem) node).edit(name, width, length);
            //MainFrame.getInstance().getDraftTree().refresh();
        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
        }
    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return currRoomView;
    }

    @Override
    public void direction(String direction) {

    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

}
