package raf.draft.dsw.gui.swing.TreeView;

import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.ProjectExplorer;

public interface DraftTree {
    public void addChild(DraftTreeItem parent);
    public void removeChild(DraftTreeItem child);
    public DraftTreeView generateTree(ProjectExplorer projectExplorer);
    public DraftTreeItem getSelectedNode();
    public void refresh();
}
