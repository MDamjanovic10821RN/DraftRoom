package raf.draft.dsw.controller.listeners;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.gui.swing.windows.RoomView;

import java.awt.event.*;
@Setter
@Getter
public class RoomMouseListener implements MouseListener, MouseMotionListener, MouseWheelListener {

    private ProjectView projectView;
    private RoomView currentRoom;

    public RoomMouseListener(ProjectView projectView) {
        this.projectView = projectView;
    }

    @Override
    public void mouseClicked(MouseEvent e) { projectView.mouseClicked(e.getX(), e.getY(), currentRoom); }

    @Override
    public void mousePressed(MouseEvent e) { projectView.mousePressed(e.getX(), e.getY(), currentRoom); }

    @Override
    public void mouseReleased(MouseEvent e) { projectView.mouseReleased(e.getX(), e.getY(), currentRoom); }

    @Override
    public void mouseDragged(MouseEvent e) { projectView.mouseDragged(e.getX(), e.getY(), currentRoom); }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {

    }
}
