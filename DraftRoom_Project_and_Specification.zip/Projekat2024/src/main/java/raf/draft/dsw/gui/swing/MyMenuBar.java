package raf.draft.dsw.gui.swing;

import lombok.Getter;
import lombok.Setter;

import javax.swing.*;
import java.awt.event.KeyEvent;

@Getter
@Setter
public class MyMenuBar extends JMenuBar {

    private JMenu editMenu;
    private JMenu fileMenu;

    public MyMenuBar(){
        fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        fileMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getOpenProjectAction()));
        fileMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getSaveAsAction()));
        fileMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getSaveAction()));
        fileMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getExitAction()));
        fileMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getAboutUsAction()));

        editMenu = new JMenu("Edit");
        editMenu.setMnemonic(KeyEvent.VK_E);
        editMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getCreateNodeAction()));
        editMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getEditNodeAction()));
        editMenu.add(new JMenuItem(MainFrame.getInstance().getActionManager().getDeleteNodeAction()));

        add(fileMenu);
        add(editMenu);
    }



}
