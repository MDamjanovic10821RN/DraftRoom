package raf.draft.dsw.model.structures.roomStructures;

public interface Prototype {
    Prototype kloniraj();
}
