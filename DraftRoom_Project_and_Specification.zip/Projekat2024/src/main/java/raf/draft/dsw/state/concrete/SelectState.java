package raf.draft.dsw.state.concrete;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;
import java.util.List;

public class SelectState implements State {
    private RoomView currRoomView;
    private Point startPoint; // Start of selection rectangle
    private Point endPoint;   // End of selection rectangle
    private int x;
    private int y;

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.x = x;
        this.y = y;

        // ClickedPainter == null if clicked on background
        ItemPainter clickedPainter = roomView.clickedPainter(new Point(x, y));
        currRoomView.deselectAll();
        currRoomView.clearSelectedPainters();

        // If smth selected -> set to selected in painter + add to selectedPainters list
        if(clickedPainter != null){
            currRoomView.getSelectedPainters().add(clickedPainter);
            clickedPainter.setSelected(true);
            currRoomView.repaint();
        }

        currRoomView.repaint();
    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.startPoint = new Point(x, y);
        this.endPoint = new Point(x, y);
    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {
        this.endPoint = new Point(x, y);
        currRoomView.setSelectionRectangle(startPoint, endPoint);
        currRoomView.repaint(); // To show updated rectangle
    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {
        this.endPoint = new Point(x, y);
        Rectangle selectionRect = currRoomView.createRectangle(startPoint, endPoint);

        // Clearing previous selections
        currRoomView.deselectAll();
        currRoomView.clearSelectedPainters();

        List<ItemPainter> paintersUnderRectangle = currRoomView.intersects(selectionRect);

        // Select all painters intersecting the selection rectangle
        if(!paintersUnderRectangle.isEmpty()) {
            for (ItemPainter painter : paintersUnderRectangle) {
                if (paintersUnderRectangle.contains(painter)) {
                    painter.setSelected(true);
                    roomView.getSelectedPainters().add(painter);
                }
            }
        }

        // Clear the selection rectangle
        currRoomView.setSelectionRectangle(null, null);
        currRoomView.repaint();
    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
