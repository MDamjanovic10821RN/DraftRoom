package raf.draft.dsw.gui.swing.windows;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.controller.listeners.RoomMouseListener;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.StateManager;
import raf.draft.dsw.state.StateType;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter

public class ProjectView extends JPanel implements ISubscriber {

    private StateManager stateManager;
    private RoomMouseListener roomMouseListener;

    private Boolean drawResizeBox = false;
    private Boolean dynamicDrawing = false;
    private String rotationDirection = "RIGHT";

    private JTabbedPane tabbedPane;
    private DraftNode relatedProject;
    private JLabel projectName;
    private JLabel projectAuthor;
    private JPanel headerPanel;
    private JLabel currentBuilding;

    private List<DraftNode> displayedProjectChildren;
    private Map<String, Color> tabColors;
    private List<Color> colors;
    private int colorSeed;
    private Color orphanColor = Color.WHITE; //boja za sve sobe bez zgrade

    public ProjectView(DraftNode relatedProject) {
        //bitan projectExplorer da bi mogli da resetujemo ukoliko se obrise otvoreni projekat ;)
        ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer().addSubscriber(this);
        this.relatedProject = relatedProject;
        this.roomMouseListener = new RoomMouseListener(this);

        this.setLayout(new BorderLayout());
        tabColors = new HashMap<>();
        colors = new ArrayList<>();
        displayedProjectChildren = new ArrayList<>();

        setLayout(new BorderLayout());
        tabbedPane = new JTabbedPane();
        headerPanel = new JPanel(new BorderLayout());
        projectName = new JLabel();
        projectAuthor = new JLabel();
        currentBuilding = new JLabel();

        //provera da li je uopste tipa Project-> u suprotnom nista ne radi!!
        if(!(relatedProject instanceof Project)){
            return;
        }

        //uzimamo sve room is project, za building ne radimo nista
        if(relatedProject != null){
            this.setBackground(new Color(210, 210, 210));



            projectName.setText(relatedProject.getName());
            projectName.setFont(new Font("Arial", Font.BOLD, 15));
            currentBuilding.setFont(new Font("Arial", Font.BOLD, 15));
            currentBuilding.setBorder(new EmptyBorder(0,270,0,0));
            projectAuthor.setText("By: "+((Project) relatedProject).getAuthor());
            projectAuthor.setFont(new Font("Arial", Font.BOLD, 15));

            headerPanel.add(projectName,BorderLayout.WEST);
            headerPanel.add(currentBuilding, BorderLayout.CENTER);
            headerPanel.add(projectAuthor,BorderLayout.EAST);
            headerPanel.setBorder(new EmptyBorder(3,10,3,10));
            headerPanel.setBackground(new Color(210, 210, 210));

            relatedProject.addSubscriber(this);
            List<DraftNode> projectItems = ((DraftNodeComposite)relatedProject).getChildren();

            colorSeed = 0;
            for (DraftNode projectItem : projectItems) {
                projectItem.addSubscriber(this); //pratimo sad svaku promenu u zgradama (brisanje dece)

                if(projectItem instanceof Building) { //ako je zgrada u pitanju -  sve po obicaju
                    //inicijalno postavljanje trenutno otvorene zgrade (prva na spisku)
                    if (colorSeed == 0) {
                        currentBuilding.setText(projectItem.getName());
                    }

                    colorSeed++;
                    Color nextColor = new Color((colorSeed * 1000) % 256, (colorSeed * 2000) % 256, (colorSeed * 3000) % 256);
                    ((Building) projectItem).setRoomTabColor(nextColor);
                    displayedProjectChildren.add(projectItem);
                    colors.add(nextColor);

                    DraftNodeComposite projectBuilding = (DraftNodeComposite) projectItem;
                    for (DraftNode child : projectBuilding.getChildren()) {

                        if (child != null) {
                            child.addSubscriber(this); //pratimo i sve promene u sobama (izmena imena)
                            ((Room) child).setFromTemplate(false);

                            RoomView roomView = new RoomView((Room) child, roomMouseListener);
                            tabbedPane.addTab(child.getName(), roomView);
                            tabbedPane.setBackgroundAt(tabbedPane.indexOfComponent(roomView), nextColor);

                            tabColors.put(child.getName(), nextColor);
                        }
                    }
                }else{ //ako nije zgrada - onda je soba u pitanju
                    ((Room) projectItem).setFromTemplate(false);
                    displayedProjectChildren.add(projectItem);

                    RoomView roomView = new RoomView((Room) projectItem, roomMouseListener);
                    tabbedPane.addTab(projectItem.getName(), roomView);
                    tabbedPane.setBackgroundAt(tabbedPane.indexOfComponent(roomView), orphanColor);

                    if(tabbedPane.getTabCount() == 1){
                        currentBuilding.setText("/");
                    }

                    tabColors.put(projectItem.getName(), orphanColor);
                }
            }

            if(tabbedPane.getSelectedIndex() != -1){ // Postavljanje listener-a na trenutno otvorenoj sobi
                Component selectedComponent = tabbedPane.getComponentAt(tabbedPane.getSelectedIndex());
                if(selectedComponent instanceof RoomView){
                    roomMouseListener.setCurrentRoom((RoomView) selectedComponent);
                }
            }

        }
        this.add(headerPanel,BorderLayout.NORTH);
        this.add(tabbedPane,BorderLayout.CENTER);

        //potrebno da bi se pratilo u kojem objektu je otvorena soba
        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int selectedIndex = tabbedPane.getSelectedIndex();
                if (selectedIndex != -1 && tabbedPane.getTitleAt(selectedIndex) != null
                        && ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(selectedIndex)) != null
                        && ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(selectedIndex)).getParent() != null) {

                    String selectedRoomName = tabbedPane.getTitleAt(selectedIndex);
                    DraftNode selectedRoom = ApplicationFramework.getInstance().getDraftRoomRepository().getElement(selectedRoomName);

                    if(selectedRoom.getParent() instanceof Project){
                        currentBuilding.setText("/");
                    }else{
                        currentBuilding.setText(selectedRoom.getParent().getName());
                    }

                    Component selectedComponent = tabbedPane.getComponentAt(tabbedPane.getSelectedIndex());
                    if(selectedComponent instanceof RoomView){// Postavljanje listener-a na trenutno otvorenoj sobi
                        roomMouseListener.setCurrentRoom((RoomView) selectedComponent);
                    }
                }
            }
        });

        stateManager = new StateManager();
    }

    //State Switching:-----------------------------------------------
    public void startStartState() { this.stateManager.setStartState(); }
    public void startAddState(ElementType elementType){
        this.stateManager.setAddState(elementType);
    }
    public void startCopyPasteState(){
        this.stateManager.setCopyPasteState();
    }
    public void startEditState(){
        this.stateManager.setEditState();
    }
    public void startMoveState(){
        this.stateManager.setMoveState();
    }
    public void startRemoveState(){
        this.stateManager.setRemoveState();
    }
    public void startResizeState(){
        this.stateManager.setResizeState();
    }
    public void startRotateState(){
        this.stateManager.setRotateState();
    }
    public void startSelectState(){
        this.stateManager.setSelectState();
    }
    public void startZoomState(){
        this.stateManager.setZoomState();
    }

    //State Methods:-------------------------------------------------
    public void mouseClicked(int x, int y, RoomView roomView) { this.stateManager.doMouseClicked(x, y, roomView); }
    public void mousePressed(int x, int y, RoomView roomView){ this.stateManager.doMousePressed(x, y, roomView); }
    public void mouseReleased(int x, int y, RoomView roomView) { this.stateManager.doMouseReleased(x, y, roomView); }
    public void mouseDragged(int x, int y, RoomView roomView) { this.stateManager.doMouseDragged(x, y, roomView); }
    public void edit(String name, int width, int length) { this.stateManager.doEdit(name, width, length); }
    public void prepare() { this.stateManager.doPrepare(); }
    public RoomView getOpenRoomView() { return this.stateManager.doGetRoomView(); }
    public void direction(String direction) { this.stateManager.doDirection(direction); }

    // dodavati sve nove metode koje su unesene u State interfejs i implementacije njega

    //---------------------------------------------------------------

    @Override
    public void update(Object notification) {
        ((Project)relatedProject).setChanged(true);

        if(notification instanceof ProjectExplorer){

            //Izmena ukoliko se obrise otvoreni projekat
            if(!(((ProjectExplorer)notification).getChildren()).contains(relatedProject)){
                MainFrame.getInstance().dismountProjectView();
            }

        }else if(notification instanceof Project){

            projectName.setText(((Project)notification).getName());
            projectAuthor.setText(" By: "+((Project)notification).getAuthor());

            //Izmena ukoliko pozvano removeChild
            if(displayedProjectChildren.size() > ((Project)notification).getChildren().size()){

                for(DraftNode ProjectChild : displayedProjectChildren){

                    if(ProjectChild instanceof Building) {
                        //ako spisak boja projektove dece ne sadrzi boju trenutne zgrade -> treba da se ukloni
                        if (!getProjectBuildingColors((Project) notification).contains(((Building)ProjectChild).getRoomTabColor())) {

                            List<String> tabsToRemove = new ArrayList<>();
                            for (Map.Entry<String, Color> tabColor : tabColors.entrySet()) {

                                String key = tabColor.getKey();
                                Color value = tabColor.getValue();
                                if (((Building)ProjectChild).getRoomTabColor().equals(value)) {
                                    tabsToRemove.add(key);
                                }

                            }

                            for (String tabName : tabsToRemove) {
                                removeTab(tabName);
                            }

                            colors.remove(((Building)ProjectChild).getRoomTabColor());
                            displayedProjectChildren.remove(ProjectChild);

                            if (tabbedPane.getSelectedIndex() == -1) {
                                currentBuilding.setText("");
                            } else if (ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())) != null &&
                                    ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() != null) {

                                if (ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() instanceof Project) {
                                    currentBuilding.setText("/");
                                } else {
                                    currentBuilding.setText(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent().getName());
                                }

                            }

                            return;
                        }
                    }else{ //slucaj za sobe
                        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                            String title = tabbedPane.getTitleAt(i);

                            //ako su bele boje, ali ne sadrzi sobu u spisku dece -> skidaj tab
                            if(orphanColor.equals(tabColors.get(title)) && !((Project)notification).containsChild(title)){

                                if (tabbedPane.getTabCount() > 0) {
                                    int newSelectedIndex = Math.min(i, tabbedPane.getTabCount() - 1);
                                    tabbedPane.setSelectedIndex(newSelectedIndex);
                                }

                                tabColors.remove(tabbedPane.getTitleAt(i));
                                undisplayRoom(tabbedPane.getTitleAt(i));
                                tabbedPane.removeTabAt(i);

                                if(tabbedPane.getSelectedIndex() != -1 && //sanity check
                                        ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())) != null &&
                                        ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() != null) {

                                    if(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() instanceof Project){
                                        currentBuilding.setText("/");
                                    }else {
                                        currentBuilding.setText(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent().getName());
                                    }

                                }else{
                                    currentBuilding.setText("");
                                }

                                return;
                            }
                        }
                    }
                }

            //Izmena ukoliko pozvano addChild
            }else if(displayedProjectChildren.size() < ((Project)notification).getChildren().size()){

                for(DraftNode projectChild : ((Project)notification).getChildren()){
                    //ako buildings lista ne sadrzi zgradu iz projekta -> dodaj je
                    if(!displayedProjectChildren.contains(projectChild)){
                        if(projectChild instanceof Building) {

                            addBuilding((Building) projectChild);
                            break;

                        }else if(projectChild instanceof Room){//ako nije zgrada, soba je

                            RoomView newRoom = new RoomView((Room) projectChild, roomMouseListener);
                            tabbedPane.addTab(projectChild.getName(), newRoom);
                            tabbedPane.setBackgroundAt(tabbedPane.indexOfComponent(newRoom), orphanColor);

                            displayedProjectChildren.add(projectChild);
                            tabColors.put(projectChild.getName(), orphanColor);

                            if(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())) != null
                                && ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() instanceof Project){
                                currentBuilding.setText("/");
                            }else if(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())) != null){
                                currentBuilding.setText(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent().getName());
                            }

                            projectChild.addSubscriber(this);

                            if(tabbedPane.getTabCount() == 1){ //ako je prva soba, mora biti postavljena u currentRoom u listeneru
                                roomMouseListener.setCurrentRoom(newRoom);
                            }

                            break;

                        }
                    }

                }

            }

        }else if(notification instanceof Building){

            //Izmena ukoliko promenjen naziv, a prikazan je trenutno
            if(currentBuilding.getText().equals(((Building)notification).getOldName())) {
                currentBuilding.setText(((Building) notification).getName());
            }
            //Izmena ukoliko pozvano removeChild
            if(getNumberOfDisplayedChildren((Building)notification) > ((Building)notification).getChildren().size()){

                for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                    String title = tabbedPane.getTitleAt(i);

                    //ako su boje zgrade, ali ne sadrzi sobu u spisku dece -> skidaj tab
                    if(((Building)notification).getRoomTabColor().equals(tabColors.get(title)) && !((Building)notification).containsChild(title)){

                        if (tabbedPane.getTabCount() > 0) {
                            int newSelectedIndex = Math.min(i, tabbedPane.getTabCount() - 1);
                            tabbedPane.setSelectedIndex(newSelectedIndex);
                        }

                        tabColors.remove(tabbedPane.getTitleAt(i));
                        tabbedPane.removeTabAt(i);

                        if(tabbedPane.getSelectedIndex() != -1 && //sanity check
                                ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())) != null &&
                                ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() != null) {

                            if(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent() instanceof Project){
                                currentBuilding.setText("/");
                            }else {
                                currentBuilding.setText(ApplicationFramework.getInstance().getDraftRoomRepository().getElement(tabbedPane.getTitleAt(tabbedPane.getSelectedIndex())).getParent().getName());
                            }

                        }else{
                            currentBuilding.setText("");
                        }

                        return;
                    }
                }

            //Izmena ukoliko pozvano addChild
            }else if(getNumberOfDisplayedChildren((Building)notification) < ((Building)notification).getChildren().size()){

                for (DraftNode child : ((Building)notification).getChildren()) {
                    String nodeName = child.getName();
                    boolean isTabPresent = false;

                    // da li child vec postoji medju tabovima?
                    for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                        String tabTitle = tabbedPane.getTitleAt(i);

                        if (tabTitle.equals(nodeName)) {
                            isTabPresent = true; // nadjen match -> postoji
                            break; //izlazi
                        }
                    }

                    // ukoliko nije prisutan, dodaj ga
                    if (!isTabPresent) {
                        RoomView newRoom = new RoomView((Room) child, roomMouseListener);
                        tabbedPane.addTab(nodeName, newRoom);
                        tabbedPane.setBackgroundAt(tabbedPane.indexOfComponent(newRoom), ((Building)notification).getRoomTabColor());
                        tabColors.put(nodeName, ((Building)notification).getRoomTabColor());

                        child.addSubscriber(this);

                        if(tabbedPane.getTabCount() == 1){ //ako je prva soba, mora biti postavljena u currentRoom u listeneru
                            roomMouseListener.setCurrentRoom(newRoom);
                        }

                        break;
                    }
                }
            }

        }else if(notification instanceof Room){
            for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                String title = tabbedPane.getTitleAt(i);
                if ((((Room)notification)).getOldName().equals(title)) {
                    tabbedPane.setTitleAt(i,((Room) notification).getName());
                    Color color = tabColors.get(((Room)notification).getOldName());
                    tabColors.remove(((Room)notification).getOldName());
                    tabColors.put(((Room)notification).getName(), color);
                }
            }
        }
    }

    public int getNumberOfDisplayedChildren(Building parent){
        int count = 0;
        for(int i = 0; i < tabbedPane.getTabCount(); i++){
            if(parent.getRoomTabColor().equals(tabColors.get(tabbedPane.getTitleAt(i)))){
                count++;
                continue;
            }
            for(DraftNode child : parent.getChildren()){

                if(tabbedPane.getTitleAt(i).equals(child.getName()) || parent.getRoomTabColor().equals(tabColors.get(tabbedPane.getTitleAt(i)))){
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    public void addBuilding(Building building){
        this.colorSeed++;
        Color nextColor = new Color((colorSeed * 1000) % 256, (colorSeed * 2000) % 256, (colorSeed * 3000) % 256);
        building.setRoomTabColor(nextColor);

        displayedProjectChildren.add(building);
        colors.add(nextColor);

        building.addSubscriber(this);
    }

    public List<Color> getProjectBuildingColors(Project project){
        List<Color> colorList = new ArrayList<>();
        for(DraftNode projectChild : project.getChildren()){
            if(projectChild instanceof Building) {
                colorList.add(((Building) projectChild).getRoomTabColor());
            }
        }
        return colorList;
    }

    public void removeTab(String roomName){

        for(int i = 0; i < tabbedPane.getTabCount(); i++){

            if (tabbedPane.getTitleAt(i).equals(roomName)) {

                tabbedPane.removeTabAt(i);
                tabColors.remove(roomName);

                if (tabbedPane.getTabCount() > 0) {
                    int newSelectedIndex = Math.min(i, tabbedPane.getTabCount() - 1);
                    tabbedPane.setSelectedIndex(newSelectedIndex);
                }

                break;
            }
        }

    }

    private void undisplayRoom(String title){
        for(DraftNode projectChild : displayedProjectChildren){
            if(projectChild.getName().equals(title)){
                displayedProjectChildren.remove(projectChild);
                return;
            }
        }
    }

    public void repaintRooms(){
        for(int i = 0; i < tabbedPane.getTabCount(); i++) {
            ((RoomView) tabbedPane.getComponentAt(i)).repaint();
        }
    }

    public void setTempRoomPainterDimensions(){
        for(int i = 0; i < tabbedPane.getTabCount(); i++) {
            ((RoomView) tabbedPane.getComponentAt(i)).setTemporaryDimensions();
        }
    }

    public void setTempRoomPainterCoordinates(){
        for(int i = 0; i < tabbedPane.getTabCount(); i++) {
            ((RoomView) tabbedPane.getComponentAt(i)).setTemporaryCoords();
        }
    }

    public RoomView openRoom(){
        int currTab = tabbedPane.getSelectedIndex();
        if(currTab != -1){
            Component component = tabbedPane.getComponentAt(currTab);
            if (component instanceof RoomView) {
                return (RoomView) component;
            }
        }
        return null;
    }

}
