package raf.draft.dsw.controller.observer;

public interface ISubscriber {
    void update(Object notification);
}
