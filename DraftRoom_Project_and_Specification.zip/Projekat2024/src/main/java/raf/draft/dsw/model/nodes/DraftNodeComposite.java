package raf.draft.dsw.model.nodes;

import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.util.ArrayList;
import java.util.List;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type"
)
@Getter
@Setter
public abstract class DraftNodeComposite extends DraftNode{

    private List<DraftNode> children;


    public DraftNodeComposite(String name, DraftNode parent) {
        super(name, parent);
        this.children = new ArrayList<>();
    }


    public abstract void addChild(DraftNode child);
    public abstract void removeChild(DraftNode child);
    public Boolean containsChild(String name){
        for(DraftNode child : children){
            if(child.getName().equals(name)){
                return true;
            }
        }
        return false;
    }

}
