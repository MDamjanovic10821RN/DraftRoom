package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.NameTemplateDialog;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.Room;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class SaveRoomAsTemplateAction extends AbstractRoomAction {

    public SaveRoomAsTemplateAction(){
        putValue(SMALL_ICON, loadIcon("/images/newTemplate.png"));
        putValue(NAME, "Save Room As Template");
        putValue(SHORT_DESCRIPTION, "Save Room As Template");
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //Project project = (Project) MainFrame.getInstance().getMountedProject().getRelatedProject();
        ProjectView projectView = MainFrame.getInstance().getMountedProject();

        if(projectView != null){
            //create themplate
            if(projectView.openRoom() != null){
                Room room = projectView.openRoom().getRoom();
                NameTemplateDialog dialog = new NameTemplateDialog(this, room);


            }else{
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_OPEN_ROOM);
            }

        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_OPEN_ROOM);
        }

        //TODO: PRVO PROCITATI SPECIFIKACIJU!
        //TODO: sacuvati trenutno otvorenu sobu kao Template time sto napravis novu metodu u serialiseru isto ako sto sam ja
        //      ,ali umesto projekta, samo pretvoris trenutnu sobu u JSON. Taj JSON sacuvati u ovom projektu u resources/templates
    }

    public void execute(String templateName, Room room) {


        try {
            ApplicationFramework.getInstance().getSerializer().saveTemplate(room , templateName);

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

}
