package raf.draft.dsw.model.structures;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;

@Getter
@Setter
public class ProjectExplorer extends DraftNodeComposite {
    public ProjectExplorer(String name, DraftNode parent) {
        super(name, parent);
    }
    public ProjectExplorer() {
        super("Project Explorer", null);
    }


    @Override
    public void addChild(DraftNode child) {
        if(child != null && child instanceof Project){
            Project childProject = (Project) child;

            if(!this.getChildren().contains(childProject)){
                this.getChildren().add(childProject);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void removeChild(DraftNode child) {
        if(child != null && child instanceof Project){
            Project childProject = (Project) child;

            if(this.getChildren().contains(childProject)){
                this.getChildren().remove(childProject);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void setNodeName(String newName) {
    }

    @Override
    public void display(String name) {

    }

}
