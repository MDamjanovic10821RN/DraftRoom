package raf.draft.dsw.model.messages;

public enum MessageType {
    ERROR,
    WARNING,
    NOTIFICATION
}
