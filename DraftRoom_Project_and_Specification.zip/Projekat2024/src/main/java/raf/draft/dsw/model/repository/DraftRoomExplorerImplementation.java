package raf.draft.dsw.model.repository;

import raf.draft.dsw.model.nodes.DraftNode;

import java.util.List;

public class DraftRoomExplorerImplementation {

    private DraftRoomRepository repository;

    public DraftRoomExplorerImplementation(DraftRoomRepository repository) {
        this.repository = repository;
    }

    public void explore(){
        List<DraftNode> nodes = repository.getElements();
        for(DraftNode node : nodes){
            System.out.println("Element:" + node.getName());

        }
    }


    // mozda cemo morati da dodamo primarni kljuc za elemente da ih bolje trazimo
    public void showElementDetails(String elementName){
        DraftNode element = repository.getElement(elementName);
        if(element != null){
            System.out.println(element.getName() +" " +  element.getParent());
        }else{
            System.out.println("Element nije pronadjen, element je null");
        }
    }


}
