package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import javax.swing.*;
import java.awt.*;

public class EditItemDialog extends JDialog {
    private JButton button;
    private JTextField nameField;
    private JTextField widthField;
    private JTextField lengthField;
    private JLabel nameLabel;
    private JLabel widthLabel;
    private JLabel lengthLabel;

    public EditItemDialog(){
        super(MainFrame.getInstance(), "Edit", true);

        RoomItem roomItem = (RoomItem) MainFrame.getInstance().getMountedProject().getOpenRoomView().getClickedPainter().getNode();

        setSize(400, 200);
        setLocationRelativeTo(null);

        nameLabel = new JLabel("Name:");
        nameField = new JTextField(15);
        nameField.setText( roomItem.getName() );

        widthLabel = new JLabel("Width:");
        widthField = new JTextField(15);
        widthField.setText(String.valueOf(roomItem.getWidth()));

        lengthLabel = new JLabel("Length:");
        lengthField = new JTextField(15);
        lengthField.setText(String.valueOf(roomItem.getLength()));

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(widthLabel);
        inputPanel.add(widthField);
        inputPanel.add(lengthLabel);
        inputPanel.add(lengthField);

        button = new JButton("Save");
        stylizeButton(button);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(button);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        button.addActionListener(e -> {
            if (nameField.getText().isEmpty() || widthField.getText().isEmpty() || lengthField.getText().isEmpty()) {
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.FIELDS_CANNOT_BE_EMPTY);

            }else if(ApplicationFramework.getInstance().getDraftRoomRepository().exists(nameField.getText())
                    && (ApplicationFramework.getInstance().getDraftRoomRepository().getElement(nameField.getText()) != (DraftNode) roomItem)){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.DUPLICATES_NOT_PERMITTED);

            }else {
                try {
                    int width = Integer.parseInt(widthField.getText());
                    int length = Integer.parseInt(lengthField.getText());

                    if (width <= 0 || length <= 0) {
                        MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.INVALID_TYPES);
                        dispose();
                        return;
                    }

                    MainFrame.getInstance().getMountedProject().edit(nameField.getText(), width, length);

                } catch (NumberFormatException ex) {
                    MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.INVALID_TYPES);
                }
                dispose();

            }
            dispose();

        });

        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

}
