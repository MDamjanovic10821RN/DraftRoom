package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class TablePainter extends ItemPainter {

    public int scaledLength;
    public int scaledWidth;
    public TablePainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;

        // Must dynamically render position if in MoveState
        if (MainFrame.getInstance().getMountedProject().getDynamicDrawing()) {
            x = getTempX();
            y = getTempY();
        } else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();

        int centerX = x + scaledWidth / 2;
        int centerY = y + scaledHeight / 2;

        int tempX = x;
        int tempY = y;

        // Adjust for rotation
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;
        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        if (rotation != 0) {
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);
        }

        // Draw the table rectangle
        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.ORANGE);
        }

        if (rotation == 1 || rotation == 3) {
            g.fillRect(tempX, tempY, scaledHeight, scaledWidth);
        } else {
            g.fillRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Draw the border
        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.DARK_GRAY);
        }

        if (rotation == 1 || rotation == 3) {
            g.drawRect(tempX, tempY, scaledHeight, scaledWidth);
        } else {
            g.drawRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Draw the circles close to edges and move them towards the center by 20%
        int circleDiameter = Math.min(scaledWidth, scaledHeight) / 8; // Diameter based on dimensions
        int circleRadius = circleDiameter / 2; // Radius
        g.setColor(Color.GRAY);

        // Calculate the inward offset (20% of the scaled dimensions)
        int inwardOffsetX = (int) (0.2 * (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth));
        int inwardOffsetY = (int) (0.2 * (rotation == 1 || rotation == 3 ? scaledWidth : scaledHeight));

        // Top-left circle
        g.fillOval(tempX + inwardOffsetX - circleRadius,
                tempY + inwardOffsetY - circleRadius,
                circleDiameter, circleDiameter);

        // Top-right circle
        g.fillOval(tempX + (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth) - inwardOffsetX - circleRadius,
                tempY + inwardOffsetY - circleRadius,
                circleDiameter, circleDiameter);

        // Bottom-left circle
        g.fillOval(tempX + inwardOffsetX - circleRadius,
                tempY + (rotation == 1 || rotation == 3 ? scaledWidth : scaledHeight) - inwardOffsetY - circleRadius,
                circleDiameter, circleDiameter);

        // Bottom-right circle
        g.fillOval(tempX + (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth) - inwardOffsetX - circleRadius,
                tempY + (rotation == 1 || rotation == 3 ? scaledWidth : scaledHeight) - inwardOffsetY - circleRadius,
                circleDiameter, circleDiameter);

        if (rotation != 0) {
            g.setTransform(oldTransform);
        }

        // Show resize rectangle in ResizeState
        if (MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            g.setColor(Color.LIGHT_GRAY);
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }
    }




    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
