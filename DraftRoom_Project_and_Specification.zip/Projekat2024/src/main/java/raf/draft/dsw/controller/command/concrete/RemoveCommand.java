package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;

import java.util.List;

public class RemoveCommand extends AbstractCommand {
    private RoomView currRoomView;
    private List<ItemPainter> painters;

    public RemoveCommand(RoomView roomView, List<ItemPainter> itemPainters){
        this.currRoomView = roomView;
        this.painters = itemPainters;
    }

    @Override
    public void doCommand() {
        DraftTreeImplementation DTI = (DraftTreeImplementation) MainFrame.getInstance().getDraftTree();

        for(ItemPainter selectedPainter : painters){
            selectedPainter.setSelected(false);
            DraftTreeItem nodeToDelete = DTI.findNodeByNameRecursive(DTI.getRoot(), selectedPainter.getNode().getName());
            DraftNodeComposite parent = (DraftNodeComposite) nodeToDelete.getDraftNode().getParent();

            MainFrame.getInstance().getDraftTree().removeChild(nodeToDelete);
            parent.removeChild(nodeToDelete.getDraftNode());
            ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(nodeToDelete.getDraftNode());

            currRoomView.getPainters().remove(selectedPainter);
        }

        currRoomView.getSelectedPainters().clear();
    }

    @Override
    public void undoCommand() {
        Room parent = currRoomView.getRoom();

        for(ItemPainter selectedPainter : painters){
            ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, selectedPainter.getNode());
            currRoomView.getPainters().add(selectedPainter);
        }
    }
}
