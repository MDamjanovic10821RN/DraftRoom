package raf.draft.dsw.controller.action;

import lombok.Getter;
import raf.draft.dsw.controller.action.actions.*;
import raf.draft.dsw.state.stateController.*;

@Getter
public class ActionManager {

    //-------------------------------------------ACTION INSTANCES:
    private ExitAction exitAction;
    private AboutUsAction aboutUsAction;
    private CreateNodeAction createNodeAction;
    private EditNodeAction editNodeAction;
    private DeleteNodeAction deleteNodeAction;
    private UndoAction undoAction;
    private RedoAction redoAction;
    private SaveAsAction saveAsAction;
    private SaveAction saveAction;
    private OpenProjectAction openProjectAction;
    private SaveRoomAsTemplateAction saveRoomAsTemplateAction;
    private UseRoomTemplateAction useRoomTemplateAction;
    //------------------------------------------STATE CONTROLLERS:
    private AddStateController addStateController;
    private CopyPasteStateController copyPasteStateController;
    private EditStateController editStateController;
    private MoveStateController moveStateController;
    private RemoveStateController removeStateController;
    private ResizeStateController resizeStateController;
    private RotateStateController rotateStateController;
    private SelectStateController selectStateController;
    private ZoomStateController zoomStateController;
    //------------------------------------------------------------

    public ActionManager(){ initializeActions(); }

    private void initializeActions() {
        exitAction = new ExitAction();
        aboutUsAction = new AboutUsAction();
        createNodeAction = new CreateNodeAction();
        editNodeAction = new EditNodeAction();
        deleteNodeAction = new DeleteNodeAction();
        undoAction = new UndoAction();
        redoAction = new RedoAction();
        saveAsAction = new SaveAsAction();
        saveAction = new SaveAction();
        openProjectAction = new OpenProjectAction();
        saveRoomAsTemplateAction = new SaveRoomAsTemplateAction();
        useRoomTemplateAction = new UseRoomTemplateAction();

        addStateController = new AddStateController();
        copyPasteStateController = new CopyPasteStateController();
        editStateController = new EditStateController();
        moveStateController = new MoveStateController();
        removeStateController = new RemoveStateController();
        resizeStateController = new ResizeStateController();
        rotateStateController = new RotateStateController();
        selectStateController = new SelectStateController();
        zoomStateController = new ZoomStateController();
    }
}
