package raf.draft.dsw.state.stateController;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ProjectView;

import java.awt.event.ActionEvent;

public class RemoveStateController extends AbstractRoomAction {

    public RemoveStateController(){
        putValue(SMALL_ICON, loadIcon("/images/removeElement.png"));
        putValue(NAME, "Remove Element");
        putValue(SHORT_DESCRIPTION, "Remove Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.startRemoveState();
        }
    }

}
