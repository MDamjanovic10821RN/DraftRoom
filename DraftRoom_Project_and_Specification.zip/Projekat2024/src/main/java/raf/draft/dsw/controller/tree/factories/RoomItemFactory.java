package raf.draft.dsw.controller.tree.factories;

import raf.draft.dsw.controller.tree.DraftNodeFactory;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;

public class RoomItemFactory extends DraftNodeFactory {
    public static int bedCount = 0;
    public static int boilerCount = 0;
    public static int closetCount = 0;
    public static int doorCount = 0;
    public static int showerCount = 0;
    public static int sinkCount = 0;
    public static int tableCount = 0;
    public static int toiletCount = 0;
    public static int washerCount = 0;

    @Override
    public DraftNode createNode(DraftNode parent) {
        return null;
    }

    public DraftNode createNode(DraftNode parent, int x, int y, int width, int length) {
        if(parent instanceof Room){
            switch (((Room)parent).getChildTypeToAdd()){
                case BED: bedCount++;
                        return new Bed("Bed"+bedCount, parent, x, y, width, length);
                case BOILER: boilerCount++;
                        return new Boiler("Boiler"+boilerCount, parent, x, y, width, length);
                case CLOSET: closetCount++;
                        return new Closet("Closet"+closetCount, parent, x, y, width, length);
                case DOOR: doorCount++;
                        return new Door("Door"+doorCount, parent, x, y, width, length);
                case SHOWER: showerCount++;
                        return new Shower("Shower"+showerCount, parent, x, y, width, length);
                case SINK: sinkCount++;
                        return new Sink("Sink"+sinkCount, parent, x, y, width, length);
                case TABLE: tableCount++;
                        return new Table("Table"+tableCount, parent, x, y, width, length);
                case TOILET: toiletCount++;
                        return new Toilet("Toilet"+toiletCount, parent, x, y, width, length);
                case WASHER: washerCount++;
                        return new Washer("Washer"+washerCount, parent, x, y, width, length);
            }
        }
        return null;
    }
}
