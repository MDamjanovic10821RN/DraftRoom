package raf.draft.dsw.controller.messageGenerator.logger.loggers;

import org.fusesource.jansi.Ansi;
import raf.draft.dsw.model.messages.Message;
import raf.draft.dsw.model.messages.MessageType;
import raf.draft.dsw.controller.messageGenerator.logger.Logger;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.gui.swing.MainFrame;

/**
 * ConsoleLogger ispisuje poruke koje ceka i
 * slusa iz MessageGenerator-a ne konzolu.
 */
public class ConsoleLogger implements Logger, ISubscriber {

    public ConsoleLogger(){
        MainFrame.getInstance().getMessageGenerator().addSubscriber(this);
    }

    //Ansi dependency je za ispisivanje obojenog teksta na konzolu - cisto da se ne zbunis sto je dodato
    @Override
    public void log(Message message, MessageType messageType) {
        if(messageType == MessageType.ERROR){
            System.out.println(Ansi.ansi().fg(Ansi.Color.RED).a("[ERROR]").reset().a(" "+message.getTimestamp()+" "+message.getText()));
        }else if(messageType == MessageType.WARNING){
            System.out.println(Ansi.ansi().fg(Ansi.Color.YELLOW).a("[WARNING]").reset().a(" "+message.getTimestamp()+" "+message.getText()));
        }else if(messageType == MessageType.NOTIFICATION){
            System.out.println(Ansi.ansi().fg(Ansi.Color.WHITE).a("[NOTIFICATION]").reset().a(" "+message.getTimestamp()+" "+message.getText()));
        }else{
            System.out.println(Ansi.ansi().fg(Ansi.Color.RED).a("[ERROR]").reset().a(" ERROR IN CONSOLELOGGER"));
        }
    }

    @Override
    public void update(Object notification) {
        Message info = (Message) notification;
        switch (info.getMessageType().toString()){
            case "ERROR":
                log(info, MessageType.ERROR);
                break;
            case "WARNING":
                log(info, MessageType.WARNING);
                break;
            case "NOTIFICATION":
                log(info, MessageType.NOTIFICATION);
                break;
        }
    }
}
