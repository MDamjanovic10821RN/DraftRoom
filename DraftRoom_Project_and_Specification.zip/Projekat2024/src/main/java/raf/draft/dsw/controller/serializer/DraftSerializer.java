package raf.draft.dsw.controller.serializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.controller.tree.factories.BuildingFactory;
import raf.draft.dsw.controller.tree.factories.ProjectFactory;
import raf.draft.dsw.controller.tree.factories.RoomFactory;
import raf.draft.dsw.controller.tree.factories.RoomItemFactory;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;
import raf.draft.dsw.state.ElementType;

import java.io.File;
import java.io.IOException;

public class DraftSerializer {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    static {
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }

    public void saveTemplate(Room room, String templateName) throws IOException{
        File templatesDir = new File("src/main/resources/templates");
        if (!templatesDir.exists()) {
            templatesDir.mkdirs(); // Create the directory if it doesn't exist
        }

        File file = new File(templatesDir, templateName + ".json");
        objectMapper.writeValue(file, room);

        MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.TEMPLATE_SAVED);
    }

    public Room loadTemplate(String filePath, DraftTreeItem selectedTreeNode) throws IOException{

        // za refresh stabla
        DraftNode selectedNode = selectedTreeNode.getDraftNode();
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            // Read JSON file
            JsonNode rootNode = objectMapper.readTree(new File(filePath));
            // Extract room properties
            String name = rootNode.get("name").asText();
            int width = rootNode.get("roomWidth").asInt();
            int length = rootNode.get("roomLength").asInt();


            if(selectedNode instanceof Project){
                ((Project)selectedNode).setChildTypeToAdd("ROOM");
            }

            Room room = ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(selectedTreeNode, width,length , "template");

            JsonNode children = rootNode.get("children");

            if (children != null && children.isArray()) {
                for (JsonNode child : children) {
                    String type = child.get("type").asText();
                    RoomItemFactory RIF = (RoomItemFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(room);

                    RoomItem item = createRoomItem(type, child, (DraftNode)room, RIF, false);

                    room.addChild(item);
                }
            }

            if(selectedNode instanceof Project){
                ((Project)selectedNode).addChild(room);
            }else if(selectedNode instanceof Building){
                ((Building)selectedNode).addChild(room);
            }

        } catch (Exception e) {
            throw new RuntimeException("Error loading the room", e);
        }
            // loaduj
        return null;
    }

    public void saveProjectAs(Project project) throws IOException {
        File file = new File(project.getPathToFolder());
        objectMapper.writeValue(file, project);
    }

    public void saveProject(Project project) throws IOException {
        File file = new File(project.getPathToFolder());

        if (!file.exists()) {
            throw new IOException("Cannot save project: File path is invalid.");
        }

        objectMapper.writeValue(file, project);
    }

    public Project load(String filePath) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(new File(filePath));

        // Construct the DraftNode model from JSON
        Project project = constructProject(rootNode);

        // Synchronize the tree with the newly loaded model
        DraftTreeImplementation treeImpl = (DraftTreeImplementation) MainFrame.getInstance().getDraftTree();
        treeImpl.synchronizeTree((DraftNodeComposite) ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer());

        return project;
    }

    private Project constructProject(JsonNode rootNode) {
        ProjectFactory pf = (ProjectFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory((DraftNode) ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer());
        pf.createNode((DraftNode) ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer());
        Project project = new Project(rootNode.get("name").asText(), (DraftNode) ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer(), rootNode.get("author").asText(), rootNode.get("pathToFolder").asText());
        project.setName(rootNode.get("name").asText());

        ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(ApplicationFramework.getInstance().getDraftRoomRepository().getProjectExplorer(), project, true);
        addChildren(project, rootNode.get("children"));

        return project;
    }

    private void addChildren(DraftNodeComposite parent, JsonNode childrenNode) {
        if (childrenNode == null || !childrenNode.isArray()) {
            return;
        }

        for (JsonNode childNode : childrenNode) {
            String type = childNode.get("type").asText();
            DraftNode child = createNode(type, childNode, (DraftNode) parent);

            if (child instanceof DraftNodeComposite) {
                addChildren((DraftNodeComposite) child, childNode.get("children"));
            }
        }
    }

    private DraftNode createNode(String type, JsonNode nodeData, DraftNode parent) {
        switch (type) {
            case "Building":
                Building building = new Building(nodeData.get("name").asText(), parent);
                building.setName(nodeData.get("name").asText());
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, building, true);
                return building;
            case "Room":
                Room room = new Room(nodeData.get("name").asText(), parent, nodeData.get("roomWidth").asInt(), nodeData.get("roomLength").asInt());
                room.setName(nodeData.get("name").asText());
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, room, true);
                return room;
            case "Bed":
            case "Boiler":
            case "Closet":
            case "Door":
            case "Shower":
            case "Sink":
            case "Table":
            case "Toilet":
            case "Washer":
                RoomItemFactory RIF = (RoomItemFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent);
                return  (DraftNode) createRoomItem(type, nodeData, parent, RIF, true);
            default:
                throw new IllegalArgumentException("Unknown type: " + type);
        }
    }

    private RoomItem createRoomItem(String type, JsonNode nodeData, DraftNode parent, RoomItemFactory RIF, Boolean copyName) {
        ((Room)parent).setFromTemplate(true);
        switch (type) {
            case "Bed":
                ((Room)parent).setChildTypeToAdd(ElementType.BED);
                Bed bed = (Bed) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                bed.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ bed.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, bed, true);
                return bed;
            case "Boiler":
                ((Room)parent).setChildTypeToAdd(ElementType.BOILER);
                Boiler boiler = (Boiler) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                boiler.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ boiler.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, boiler, true);
                return boiler;
            case "Closet":
                ((Room)parent).setChildTypeToAdd(ElementType.CLOSET);
                Closet closet = (Closet) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                closet.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ closet.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, closet, true);
                return closet;
            case "Door":
                ((Room)parent).setChildTypeToAdd(ElementType.DOOR);
                Door door = (Door) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                door.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ door.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, door, true);
                return door;
            case "Shower":
                ((Room)parent).setChildTypeToAdd(ElementType.SHOWER);
                Shower shower = (Shower) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                shower.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ shower.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, shower, true);
                return shower;
            case "Sink":
                ((Room)parent).setChildTypeToAdd(ElementType.SINK);
                Sink sink = (Sink) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                sink.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ sink.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, sink, true);
                return sink;
            case "Table":
                ((Room)parent).setChildTypeToAdd(ElementType.TABLE);
                Table table = (Table) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                table.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ table.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, table, true);
                return table;
            case "Toilet":
                ((Room)parent).setChildTypeToAdd(ElementType.TOILET);
                Toilet toilet = (Toilet) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                toilet.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ toilet.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, toilet, true);
                return toilet;
            case "Washer":
                ((Room)parent).setChildTypeToAdd(ElementType.WASHER);
                Washer washer = (Washer) RIF.createNode(parent, nodeData.get("locationX").asInt(), nodeData.get("locationY").asInt(), nodeData.get("width").asInt(), nodeData.get("length").asInt());
                washer.setRotation(nodeData.get("rotation").asInt());
                if(copyName){ washer.setName(nodeData.get("name").asText()); }
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, washer, true);
                return washer;
            default:
                throw new IllegalArgumentException("Unknown RoomItem type: " + type);
        }
    }
}
