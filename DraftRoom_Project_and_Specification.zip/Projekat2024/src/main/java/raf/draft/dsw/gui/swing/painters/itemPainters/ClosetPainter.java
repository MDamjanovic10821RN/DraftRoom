package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class ClosetPainter extends ItemPainter {

    public int scaledWidth;
    public int scaledLength;

    public ClosetPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;

        // Dynamically render position in MoveState
        if (MainFrame.getInstance().getMountedProject().getDynamicDrawing()) {
            x = getTempX();
            y = getTempY();
        } else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // Store the original transform
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();

        // Center coordinates for rotation
        int centerX = x + scaledWidth / 2;
        int centerY = y + scaledHeight / 2;

        int tempX = x;
        int tempY = y;

        // Adjust position for rotation
        if (rotation == 1) { // 90 degrees
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180 degrees
            tempX = x - scaledWidth;
            tempY = y - scaledHeight;
        } else if (rotation == 3) { // 270 degrees
            tempX = x - scaledHeight;
        }

        if (rotation != 0) {
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            int rotationAngle = rotation * 90;
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);
        }

        // Draw the main closet rectangle
        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.ORANGE);
        }

        if (rotation == 1 || rotation == 3) { // Adjust dimensions for rotated state
            g.fillRect(tempX, tempY, scaledHeight, scaledWidth);
        } else {
            g.fillRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Draw the border
        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.DARK_GRAY);
        }

        if (rotation == 1 || rotation == 3) {
            g.drawRect(tempX, tempY, scaledHeight, scaledWidth);
        } else {
            g.drawRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Draw the vertical dividing line
        int middleX = tempX + (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth) / 2;
        g.setColor(Color.BLACK);
        if (rotation == 1 || rotation == 3) {
            g.drawLine(middleX, tempY, middleX, tempY + scaledWidth);
        } else {
            g.drawLine(middleX, tempY, middleX, tempY + scaledHeight);
        }

        // Draw handles
        int handleWidth = (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth) / 12;
        int handleHeight = (rotation == 1 || rotation == 3 ? scaledWidth : scaledHeight) / 8;
        int handleOffsetY = (rotation == 1 || rotation == 3 ? scaledWidth : scaledHeight) / 3;
        int handleOffsetX = (rotation == 1 || rotation == 3 ? scaledHeight : scaledWidth) / 6;

        // Left handle
        int leftHandleX = middleX - handleOffsetX - handleWidth / 2;
        int leftHandleY = tempY + handleOffsetY;

        // Right handle
        int rightHandleX = middleX + handleOffsetX - handleWidth / 2;
        int rightHandleY = tempY + handleOffsetY;

        g.setColor(new Color(128, 128, 128, 200));
        g.fillRect(leftHandleX, leftHandleY, handleWidth, handleHeight);
        g.fillRect(rightHandleX, rightHandleY, handleWidth, handleHeight);

        g.setColor(Color.DARK_GRAY);
        g.drawRect(leftHandleX, leftHandleY, handleWidth, handleHeight);
        g.drawRect(rightHandleX, rightHandleY, handleWidth, handleHeight);

        // Restore transform
        if (rotation != 0) {
            g.setTransform(oldTransform);
        }

        // Resize rectangle
        if (MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }
    }

    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
