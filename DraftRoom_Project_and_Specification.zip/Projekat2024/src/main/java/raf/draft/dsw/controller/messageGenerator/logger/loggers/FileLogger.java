package raf.draft.dsw.controller.messageGenerator.logger.loggers;

import raf.draft.dsw.model.messages.Message;
import raf.draft.dsw.model.messages.MessageType;
import raf.draft.dsw.controller.messageGenerator.logger.Logger;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.gui.swing.MainFrame;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * FileLogger ispisuje poruke koje ceka i slusa iz
 * MessageGenerator-a unutar fajla /recources/log.txt
 */
public class FileLogger implements Logger, ISubscriber {

    private File logFile;
    private PrintWriter printWriter;

    public FileLogger(){
        MainFrame.getInstance().getMessageGenerator().addSubscriber(this);

        try{
            logFile = new File("src/main/resources/files/log.txt");
            if(!logFile.exists()){
                System.out.println("FILE WITH GIVEN PATH DOESN'T EXIST!");
            }

            //FileWriter 'false' da bi obrisao preostale poruke iz prethodnog pokretanja
            FileWriter fileWriter = new FileWriter(logFile, false);
            printWriter = new PrintWriter(fileWriter, true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void log(Message message, MessageType messageType) {
        printWriter.println("[" + messageType + "] "+message.getTimestamp()+" "+message.getText());
        printWriter.flush();
    }

    @Override
    public void update(Object notification) {
        Message info = (Message) notification;
        log(info, info.getMessageType());
    }

    /**
     * zove se na zatvaranju aplikacije da ne bi ostali otvoreni writer-i
     */
    public void close() {
        if (printWriter != null) {
            printWriter.close();
        }
    }
}
