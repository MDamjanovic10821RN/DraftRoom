package raf.draft.dsw.state.concrete;

import lombok.Getter;
import raf.draft.dsw.controller.command.concrete.AddCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.controller.tree.factories.RoomItemFactory;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.painters.itemPainters.*;
import raf.draft.dsw.gui.swing.windows.ElementDimensionsDialog;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import javax.swing.*;

@Getter
public class AddState implements State {

    private ElementType elementToAdd = ElementType.BED;
    private int elementWidth;
    private int elementLength;

    private RoomView currRoomView;
    private int x;
    private int y;

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.x = x;
        this.y = y;

        Room room = (Room)roomView.getRoom();
        room.setChildTypeToAdd(elementToAdd); // so that it is know which kind of child to make in factory ;)

        ElementDimensionsDialog elementDimensionsDialog = new ElementDimensionsDialog(this);

    }

    public void setElementToAdd(ElementType elementType){
        this.elementToAdd = elementType;
    }

    public void createElement(int w, int l){
        this.elementWidth = w;
        this.elementLength = l;

        // Does the item intersect the room or other elements? if not -> create item
        if(!currRoomView.outOfRoomBounds(x, y, elementWidth, elementLength)
        && !currRoomView.isIntersectingExistingItems(x, y, elementWidth, elementLength)) {

            AddCommand addCommand = new AddCommand(currRoomView, null, null, elementToAdd, x, y, elementWidth, elementLength);
            currRoomView.getCommandManager().addCommand(addCommand);

            //ADD LOGIC MIGRATED TO "AddCommand"
            //----------------------------------------------------------------------Creation of new node:
//            Room parent = currRoomView.getRoom();
//            RoomItemFactory nodeFactory = (RoomItemFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent);
//            DraftNode child = nodeFactory.createNode(parent, x, y, elementWidth, elementLength); // Creating child
//            ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(currRoomView.getRoom(), child); // Adding child to model
//
//            child.addSubscriber(currRoomView);
//
//            //---------------------------------------------------Adding adequate painter to CurrRoomView:
//            switch (elementToAdd) {
//                case BED -> currRoomView.getPainters().add(new BedPainter((DraftNode) child));
//                case DOOR -> currRoomView.getPainters().add(new DoorPainter((DraftNode) child));
//                case SINK -> currRoomView.getPainters().add(new SinkPainter((DraftNode) child));
//                case TABLE -> currRoomView.getPainters().add(new TablePainter((DraftNode) child));
//                case BOILER -> currRoomView.getPainters().add(new BoilerPainter((DraftNode) child));
//                case CLOSET -> currRoomView.getPainters().add(new ClosetPainter((DraftNode) child));
//                case SHOWER -> currRoomView.getPainters().add(new ShowerPainter((DraftNode) child));
//                case TOILET -> currRoomView.getPainters().add(new ToiletPainter((DraftNode) child));
//                case WASHER -> currRoomView.getPainters().add(new WasherPainter((DraftNode) child));
//            }

        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
        }
    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

}
