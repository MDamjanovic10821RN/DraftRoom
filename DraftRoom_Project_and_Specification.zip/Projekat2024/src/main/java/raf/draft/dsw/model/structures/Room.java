package raf.draft.dsw.model.structures;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;

@Getter
@Setter
public class Room extends DraftNodeComposite {
    private String oldName = "";
    private int roomWidth;
    private int roomLength;
    @JsonIgnore
    private ElementType childTypeToAdd = ElementType.BED; // To be set at change of "AddState type"

    // Variable to distinguish if the update method was from the serializer
    @JsonIgnore
    Boolean fromTemplate = false;

    public Room(String name, DraftNode parent) {
        super(name, parent);
    }

    public Room(String name, DraftNode parent, int width, int length) {
        super(name, parent);
        this.roomWidth = width;
        this.roomLength = length;
    }

    @Override
    public void addChild(DraftNode child) {
        if(child != null && child instanceof RoomItem){
            RoomItem childRoomItem = (RoomItem) child;

            if(!this.getChildren().contains(childRoomItem)){
                this.getChildren().add(childRoomItem);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void removeChild(DraftNode child) {
        if(child != null && child instanceof RoomItem){
            RoomItem childRoomItem = (RoomItem) child;

            if(this.getChildren().contains(childRoomItem)){
                this.getChildren().remove(childRoomItem);
                notifySubscribers(this);
            }
        }
    }

    @Override
    public void setNodeName(String newName) {
        this.oldName = this.getName();
        this.setName(newName);
        notifySubscribers(this);
    }

    @Override
    public void display(String name) {

    }

    @Override
    public String toString() {
        return "Room{" +
                "Name='" + getName() + '\'' +
                '}';
    }
}
