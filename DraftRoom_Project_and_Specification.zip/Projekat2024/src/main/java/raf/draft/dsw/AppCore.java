package raf.draft.dsw;

import raf.draft.dsw.core.ApplicationFramework;

public class AppCore {
    public static void main(String[] args) {
        ApplicationFramework appCore = ApplicationFramework.getInstance();
    }
}