package raf.draft.dsw.model.messages;

import lombok.AllArgsConstructor;
import lombok.Getter;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;

@Getter
@AllArgsConstructor
public class Message {
    private String text;
    private MessageType messageType;
    private ErrorCode errorCode;
    private String timestamp;
}
