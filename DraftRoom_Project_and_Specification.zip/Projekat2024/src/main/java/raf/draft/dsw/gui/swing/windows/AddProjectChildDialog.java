package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.action.actions.CreateNodeAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.nodes.DraftNode;

import javax.swing.*;
import java.awt.*;

public class AddProjectChildDialog extends JDialog {

    private JButton roomButton;
    private JButton buildingButton;
    private JLabel choiceLabel;

    CreateNodeAction controllerClass;

    public AddProjectChildDialog(CreateNodeAction createNodeAction) {
        controllerClass = createNodeAction;
        this.setTitle("Create New Project Element");

        choiceLabel = new JLabel("Choose what to create:");
        choiceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        choiceLabel.setForeground(new Color(60, 60, 60));
        choiceLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel labelPanel = new JPanel(new BorderLayout());
        labelPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));
        labelPanel.add(choiceLabel, BorderLayout.CENTER);

        roomButton = new JButton("Add Room");
        buildingButton = new JButton("Add Building");

        stylizeButton(roomButton);
        stylizeButton(buildingButton);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.add(buildingButton);
        buttonPanel.add(roomButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        setLayout(new BorderLayout(10, 10));
        setSize(300, 150);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(new Color(240, 240, 240));

        this.add(labelPanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.CENTER);

        roomButton.addActionListener(e -> {
            //controllerClass.addChildToProject("ROOM");
            dispose();
            RoomDimensionsDialog dialog = new RoomDimensionsDialog(controllerClass);
        });

        buildingButton.addActionListener(e -> {
            controllerClass.addChildToProject("BUILDING", 0, 0);
            dispose();
        });

        setModal(true);
        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

}
