package raf.draft.dsw.controller.tree.factories;

import raf.draft.dsw.controller.tree.DraftNodeFactory;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.ProjectExplorer;

public class ProjectExplorerFactory extends DraftNodeFactory {
    @Override
    public DraftNode createNode(DraftNode parent) {
        return new ProjectExplorer();
    }
}
