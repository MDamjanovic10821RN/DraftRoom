package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;

public class BedPainter extends ItemPainter {

    int scaledWidth;
    int scaledLength;


    public BedPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        }else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        //--------------------------------------------------------------------
        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();

        int tempX = x;
        int tempY = y;
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;

        } else if (rotation == 2) { // 180
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;

        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        if(rotation != 0){
            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);

        }

        // Main bed rectangle
        if(getSelected()){
            g.setColor(Color.BLUE);
        }else {
            g.setColor(Color.RED);
        }

        if(rotation == 1 || rotation == 3){ //temporary solution
            g.fillRect(tempX, tempY, scaledHeight, scaledWidth);
        }else {
            g.fillRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Bed border
        if(getSelected()){
            g.setColor(Color.BLUE);
        }else {
            g.setColor(Color.DARK_GRAY);
        }
        if(rotation == 1 || rotation == 3){ //temporary solution
            g.drawRect(tempX, tempY, scaledHeight, scaledWidth);
        }else {
            g.drawRect(tempX, tempY, scaledWidth, scaledHeight);
        }

        // Drawing pillow rectangle near top of bed
        int pillowHeight;
        int pillowWidth;
        int pillowX;
        int pillowY;
        if(rotation == 1 || rotation == 3) { //temporary solution
            pillowHeight = scaledWidth / 5; // Pillow height (20% of the bed's length)
            pillowWidth = (int) (scaledHeight / 1.2);  // Pillow width (less than 50% of the bed's width)
            pillowX = tempX + (scaledHeight - pillowWidth) / 2; // Center the pillow horizontally
            pillowY = tempY + 3; // Pillow is at top of bed + 3
        }else {
            pillowHeight = scaledHeight / 5; // Pillow height (20% of the bed's length)
            pillowWidth = (int) (scaledWidth / 1.2);  // Pillow width (less than 50% of the bed's width)
            pillowX = tempX + (scaledWidth - pillowWidth) / 2; // Center the pillow horizontally
            pillowY = tempY + 3; // Pillow is at top of bed + 3 --- EsTeTiKa
        }
        g.setColor(Color.WHITE); // Pillow color
        g.fillRect(pillowX, pillowY, pillowWidth, pillowHeight);

        // Pillow border
        g.setColor(Color.DARK_GRAY);
        g.drawRect(pillowX, pillowY, pillowWidth, pillowHeight);
        g.setTransform(oldTransform);

        // If currState == Resize -> show resize rectangle around painter
        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }

        if(rotation != 0){
            g.setTransform(oldTransform);
        }

        //DEBUG DOTS
        //g.setColor(Color.BLACK); // Set the color of the dot
        //int dotSize = 5; // Define the size of the dot
        //g.fillOval(centerX - dotSize / 2, centerY - dotSize / 2, dotSize, dotSize);
        //g.fillOval(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);

    }



    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;
    }
}
