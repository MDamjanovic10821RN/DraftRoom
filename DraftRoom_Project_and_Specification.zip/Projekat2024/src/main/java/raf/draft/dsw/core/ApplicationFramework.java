package raf.draft.dsw.core;

import lombok.Getter;
import raf.draft.dsw.controller.messageGenerator.generator.MessageGenerator;
import raf.draft.dsw.controller.messageGenerator.logger.Logger;
import raf.draft.dsw.controller.messageGenerator.logger.LoggerFactory;
import raf.draft.dsw.controller.messageGenerator.logger.LoggerType;
import raf.draft.dsw.controller.messageGenerator.logger.loggers.ConsoleLogger;
import raf.draft.dsw.controller.messageGenerator.logger.loggers.FileLogger;
import raf.draft.dsw.controller.serializer.DraftSerializer;
import raf.draft.dsw.controller.tree.DraftNodeFactories;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.repository.DraftRoomRepository;
import raf.draft.dsw.model.structures.ProjectExplorer;

import java.util.ArrayList;

@Getter
public class ApplicationFramework {

    private static ApplicationFramework instance;
    private DraftNodeFactories draftNodeFactory;
    private DraftRoomRepository draftRoomRepository;
    private DraftSerializer serializer;
    ConsoleLogger consoleLogger;
    FileLogger fileLogger;

    public ApplicationFramework(){
        initialize();
    }

    public void initialize(){
        MainFrame mainFrame = MainFrame.getInstance();

        draftNodeFactory = new DraftNodeFactories();
        draftRoomRepository = new DraftRoomRepository(new ArrayList<DraftNode>(), (ProjectExplorer) draftNodeFactory.getFactory(null).createNode(null));
        mainFrame.generateTree(draftRoomRepository.getProjectExplorer());

        mainFrame.initializeGUIComponents(); //necessary to avoid recursion

        LoggerFactory loggerFactory = new LoggerFactory();
        consoleLogger = (ConsoleLogger) loggerFactory.createLogger(LoggerType.CONSOLE);
        fileLogger = (FileLogger) loggerFactory.createLogger(LoggerType.FILE);

        this.serializer = new DraftSerializer();

        mainFrame.setVisible(true);
    }

    public static ApplicationFramework getInstance() {
        if(instance == null){
            instance = new ApplicationFramework();
        }

        return instance;
    }
}
