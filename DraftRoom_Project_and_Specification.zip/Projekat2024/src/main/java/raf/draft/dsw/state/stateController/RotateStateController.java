package raf.draft.dsw.state.stateController;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.gui.swing.windows.RotationDialog;

import java.awt.event.ActionEvent;

public class RotateStateController extends AbstractRoomAction {

    public RotateStateController(){
        putValue(SMALL_ICON, loadIcon("/images/rotate.png"));
        putValue(NAME, "Rotate Element");
        putValue(SHORT_DESCRIPTION, "Rotate Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainFrame.getInstance().getMountedProject().startRotateState();
        RotationDialog rotationDialog = new RotationDialog(this);
    }

}
