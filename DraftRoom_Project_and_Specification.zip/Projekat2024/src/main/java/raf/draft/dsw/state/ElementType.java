package raf.draft.dsw.state;

public enum ElementType {
    DOOR,
    BED,
    TABLE,
    CLOSET,
    SHOWER,
    WASHER,
    BOILER,
    SINK,
    TOILET
}
