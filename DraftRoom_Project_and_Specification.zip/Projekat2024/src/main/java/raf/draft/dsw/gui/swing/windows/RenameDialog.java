package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.action.actions.EditNodeAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.nodes.DraftNode;

import javax.swing.*;
import java.awt.*;

public class RenameDialog extends JDialog {
    private JButton button;
    private JTextField textField;
    private JLabel label;
    private EditNodeAction editNodeAction;

    public RenameDialog(EditNodeAction editNodeAction){
        super(MainFrame.getInstance(), "Rename", true);
        this.editNodeAction = editNodeAction;

        DraftNode node = MainFrame.getInstance().getDraftTree().getSelectedNode().getDraftNode();

        setSize(300, 150);
        setBackground(new Color(155, 145, 175));
        setLocationRelativeTo(null);

        label = new JLabel("New Name:");
        textField = new JTextField(15);
        textField.setText(node.getName());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout(5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.add(label, BorderLayout.NORTH);
        inputPanel.add(textField, BorderLayout.CENTER);

        button = new JButton("Save");
        stylizeButton(button);
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(button);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        button.addActionListener(e -> {
            if(textField.getText().isEmpty()){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.FIELDS_CANNOT_BE_EMPTY);
            }else if(ApplicationFramework.getInstance().getDraftRoomRepository().exists(textField.getText())){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.DUPLICATES_NOT_PERMITTED);
            }else{
                editNodeAction.editName((DraftNode) node, textField.getText()); //radi postovanja MVC
            }
            MainFrame.getInstance().getDraftTree().refresh();
            dispose();
        });

        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

}
