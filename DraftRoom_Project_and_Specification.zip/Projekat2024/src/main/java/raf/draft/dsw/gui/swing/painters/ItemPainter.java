package raf.draft.dsw.gui.swing.painters;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import java.awt.*;

@Getter
@Setter
public abstract class ItemPainter {

    DraftNode node;
    Boolean selected = false;

    // Used for live preview of moving without loosing OG coordinates
    int tempX = 0;
    int tempY = 0;
    // Used for live preview of resizing without loosing OG dimensions
    int tempScaledWidth = 0;
    int tempScaledLength = 0;
    // Coordinates and size of little white rectangle (for resizeState)
    private Rectangle whiteRectBounds;

    public ItemPainter(DraftNode node) {
        this.node = node;
    }

    public abstract void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight);

    public abstract boolean itemAt(Point pos);

    public void drawBigBlueRectangle(Graphics2D g, int x, int y, int width, int height) {

        // Blue border for the big rectangle
        g.setColor(Color.BLUE.darker());
        g.drawRect(x - 5, y - 5, width + 10, height + 10);

        // Dimensions of the little white rectangle
        int whiteRectWidth = 10; // Fixed width
        int whiteRectHeight = 10; // Fixed height

        // Position of little white rectangle (bottom right of big blue rectangle)
        int whiteRectX = x + width + 5 - whiteRectWidth;
        int whiteRectY = y + height + 5 - whiteRectHeight;

        // Save bounds of white rectangle for hit detection
        whiteRectBounds = new Rectangle(whiteRectX, whiteRectY, whiteRectWidth, whiteRectHeight);

        // Draw the little white rectangle
        g.setColor(Color.WHITE);
        g.fillRect(whiteRectX, whiteRectY, whiteRectWidth, whiteRectHeight);

        // Blue border for the little white rectangle
        g.setColor(Color.BLUE);
        g.drawRect(whiteRectX, whiteRectY, whiteRectWidth, whiteRectHeight);
    }

    /**
     * Checks if the given point is inside little white rectangle.
     */
    public boolean isPointInWhiteRect(Point point) {
        return whiteRectBounds != null && whiteRectBounds.contains(point);
    }

}
