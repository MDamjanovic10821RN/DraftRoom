package raf.draft.dsw.controller.tree.factories;

import raf.draft.dsw.controller.tree.DraftNodeFactory;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.Room;

public class RoomFactory extends DraftNodeFactory {
    public static int count = 0;
    @Override
    public DraftNode createNode(DraftNode parent) {
        count++;
        return new Room("Room" + count, parent);
    }

    public DraftNode createNode(DraftNode parent, int width, int length) {
        count++;
        return new Room("Room" + count, parent, width, length);
    }
}
