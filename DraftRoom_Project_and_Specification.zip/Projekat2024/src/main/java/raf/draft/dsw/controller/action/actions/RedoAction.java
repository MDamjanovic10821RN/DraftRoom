package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.RoomView;

import java.awt.event.ActionEvent;

public class RedoAction extends AbstractRoomAction {

    public RedoAction(){
        putValue(SMALL_ICON, loadIcon("/images/redo.png"));
        putValue(NAME, "Redo");
        putValue(SHORT_DESCRIPTION, "Redo");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            RoomView roomView = MainFrame.getInstance().getMountedProject().openRoom();
            if(roomView != null){
                roomView.getCommandManager().doCommand();
            }
        }
    }
}
