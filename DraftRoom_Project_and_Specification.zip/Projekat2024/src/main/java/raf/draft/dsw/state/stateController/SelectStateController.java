package raf.draft.dsw.state.stateController;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ProjectView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class SelectStateController extends AbstractRoomAction {

    public SelectStateController(){
        putValue(SMALL_ICON, loadIcon("/images/select.png"));
        putValue(NAME, "Select Element");
        putValue(SHORT_DESCRIPTION, "Select Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.startSelectState();
        }
    }
}
