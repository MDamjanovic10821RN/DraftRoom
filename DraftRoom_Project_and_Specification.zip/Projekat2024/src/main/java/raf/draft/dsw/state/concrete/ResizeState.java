package raf.draft.dsw.state.concrete;

import raf.draft.dsw.controller.command.concrete.ResizeCommand;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;

public class ResizeState implements State {
    private RoomView currRoomView;
    private int startX;
    private int startY;
    private int originalWidthPx, originalHeightPx;

    private ItemPainter resizingPainter;

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {

    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.startX = x;
        this.startY = y;

        // Mouse press is inside little white rectangle of a painter?
        for (ItemPainter painter : roomView.getPainters()) {
            if (painter.isPointInWhiteRect(new Point(x, y))) {
                resizingPainter = painter;

                // Original dimensions for potential reset on invalid resize
                RoomItem item = (RoomItem) painter.getNode();
                originalWidthPx = painter.getTempScaledWidth();
                originalHeightPx = painter.getTempScaledLength();

                break;
            }
        }
    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {
        if (resizingPainter != null) {
            // Drag offset in px
            int deltaX = x - startX;
            int deltaY = y - startY;

            // Dimensions in pixels
            int newWidthPx = originalWidthPx + deltaX;
            int newHeightPx = originalHeightPx + deltaY;

            // temp dimensions for dynamic preview
            resizingPainter.setTempScaledWidth(newWidthPx);
            resizingPainter.setTempScaledLength(newHeightPx);

            /**
             * repaint se poziva na osnovu promenjene privremene vrednosti koordinata unutar samih paintera.
             * Potrebne su privremene koordinate da bi se odrzala mogucnost vracanja u OG poziciju prilikom preklapanja itema.
             */
            roomView.repaint();
        }
    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {
        if (resizingPainter != null) {
            // Temporary dimensions in pixels
            int newWidthPx = resizingPainter.getTempScaledWidth();
            int newHeightPx = resizingPainter.getTempScaledLength();

            // Dimensions to centimeters for validation and storage in model
            double newWidthCm = newWidthPx / roomView.getCmToPx();
            double newHeightCm = newHeightPx / roomView.getCmToPx();

            // Position of painter
            RoomItem item = (RoomItem) resizingPainter.getNode();
            int xPos = item.getLocationX();
            int yPos = item.getLocationY();

            // Validation (room intersection ^ other item intersection)
            boolean isValid = !roomView.outOfRoomBounds(xPos, yPos, (int)newWidthCm, (int)newHeightCm) && !roomView.isIntersectingWithOtherItems(item, xPos, yPos, (int)newWidthCm, (int)newHeightCm);

            if (isValid) {
                ResizeCommand resizeCommand = new ResizeCommand(currRoomView, resizingPainter, (int)newWidthCm, (int)newHeightCm);
                currRoomView.getCommandManager().addCommand(resizeCommand);

                //LOGIC MIGRATED TO ResizeCommand
//                // Storing new values into model through edit so repaint will be called through update in roomView
//                item.edit(item.getName(), (int)newWidthCm, (int)newHeightCm);
            } else {
                // Reset dimensions to OG size
                resizingPainter.setTempScaledWidth(originalWidthPx);
                resizingPainter.setTempScaledLength(originalHeightPx);
                /**
                 * repaint se poziva na osnovu promenjene privremenih vrednosti sirine i visine unutar samih paintera.
                 * Ovde se vracaju privremene vrednosti na prvobitne... kad su izmenjene u modelu-> preko update() se azurira prikaz
                 */
                currRoomView.repaint();
            }

            resizingPainter = null;
        }
    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(true);
        MainFrame.getInstance().getMountedProject().setTempRoomPainterDimensions();
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
