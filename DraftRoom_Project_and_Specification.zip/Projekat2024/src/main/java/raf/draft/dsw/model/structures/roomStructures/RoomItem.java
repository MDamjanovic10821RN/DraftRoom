package raf.draft.dsw.model.structures.roomStructures;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Bed.class, name = "Bed"),
        @JsonSubTypes.Type(value = Boiler.class, name = "Boiler"),
        @JsonSubTypes.Type(value = Closet.class, name = "Closet"),
        @JsonSubTypes.Type(value = Door.class, name = "Door"),
        @JsonSubTypes.Type(value = Shower.class, name = "Shower"),
        @JsonSubTypes.Type(value = Sink.class, name = "Sink"),
        @JsonSubTypes.Type(value = Table.class, name = "Table"),
        @JsonSubTypes.Type(value = Toilet.class, name = "Toilet"),
        @JsonSubTypes.Type(value = Washer.class, name = "Washer")
})
@Getter
@Setter
public abstract class RoomItem extends DraftNode implements Prototype{

    private int locationX;
    private int locationY;

    private int width;
    private int length;

    private int rotation;
    @JsonIgnore
    private int OGX;
    @JsonIgnore
    private int OGY;

    public RoomItem(String name, DraftNode parent, int x, int y, int width, int length) {
        super(name, parent);

        this.locationX = x;
        this.locationY = y;
        this.width = width;
        this.length = length;

        this.rotation = 0;
        this.OGX = x;
        this.OGY = y;
    }

    public void edit(String name, int width, int length){
        setNodeName(name);
        this.width = width;
        this.length = length;
        notifySubscribers((DraftNode)this);
    }

    public void setCoords(int x, int y){
        this.locationX = x;
        this.locationY = y;
        notifySubscribers((DraftNode)this);
    }

    public void updateRotation(int rotation){
        this.rotation = rotation;
        notifySubscribers(this);
    }
}
