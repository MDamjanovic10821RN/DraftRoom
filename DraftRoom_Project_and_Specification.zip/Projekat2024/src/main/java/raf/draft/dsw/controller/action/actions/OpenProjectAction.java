package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

public class OpenProjectAction extends AbstractRoomAction {

    public OpenProjectAction(){
        putValue(SMALL_ICON, loadIcon("/images/openProject.png"));
        putValue(NAME, "Open Project");
        putValue(SHORT_DESCRIPTION, "Open Project");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser jfc = new JFileChooser();

        File projectFile = null;

        if (jfc.showSaveDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            projectFile = jfc.getSelectedFile();
        } else {
            return;
        }

        try {
            ApplicationFramework.getInstance().getSerializer().load(jfc.getSelectedFile().getAbsolutePath());
            //MainFrame.getInstance().getMountedProject().repaintRooms();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

}
