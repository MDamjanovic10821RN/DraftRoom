package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import java.util.List;

public class RotateCommand extends AbstractCommand {
    private RoomView currRoomview;
    private List<ItemPainter> painters;
    String rotationDirection;

    public RotateCommand(RoomView roomView, List<ItemPainter> painters, String rotationDirection){
        this.currRoomview = roomView;
        this.painters = painters;
        this.rotationDirection = rotationDirection;
    }

    @Override
    public void doCommand() {
        boolean showErrorMessage = false;

        // Validation: Who can, will approach
        for(ItemPainter painter : painters){
            RoomItem selectedItem = (RoomItem) painter.getNode();

            int currentRotation = selectedItem.getRotation();

            int newRotation = "RIGHT".equals(rotationDirection)
                    ? (currentRotation + 1) % 4
                    : (currentRotation + 3) % 4;

            // Validation
            boolean isValid = !currRoomview.outOfRoomBounds(selectedItem.getLocationX(), selectedItem.getLocationY(), selectedItem.getLength(), selectedItem.getWidth()) &&
                    !currRoomview.isIntersectingWithNonSelectedItems(selectedItem, selectedItem.getLocationX(), selectedItem.getLocationY(), selectedItem.getLength(), selectedItem.getWidth());

            if (isValid) {
                // Swap dimensions for 90 or 270 rotations
                if (newRotation % 2 != currentRotation % 2) {
                    int temp = selectedItem.getWidth();
                    selectedItem.setWidth(selectedItem.getLength());
                    selectedItem.setLength(temp);
                }

                // Updating rotation
                selectedItem.updateRotation(newRotation);

            } else {
                showErrorMessage = true;
            }
        }

        if(showErrorMessage){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
        }
    }

    @Override
    public void undoCommand() {

        for(ItemPainter painter : painters){
            RoomItem selectedItem = (RoomItem) painter.getNode();
            int currentRotation = selectedItem.getRotation();

            int newRotation = "RIGHT".equals(rotationDirection)
                    ? (currentRotation + 3) % 4
                    : (currentRotation + 1) % 4;

            if (newRotation % 2 != currentRotation % 2) {
                int temp = selectedItem.getWidth();
                selectedItem.setWidth(selectedItem.getLength());
                selectedItem.setLength(temp);
            }

            // Updating rotation
            selectedItem.updateRotation(newRotation);

        }
    }
}
