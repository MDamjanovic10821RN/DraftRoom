package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class BoilerPainter extends ItemPainter {

    public int scaledWidth;
    public int scaledLength;

    public BoilerPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;

        // Must dynamically render position if in MoveState
        if (MainFrame.getInstance().getMountedProject().getDynamicDrawing()) {
            x = getTempX();
            y = getTempY();
        } else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // Save the original transform
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();

        int tempX = x;
        int tempY = y;

        // Adjust position based on rotation
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;
        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        if (rotation != 0) {
            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);
        }

        // Set stroke and color for outer circle
        g.setStroke(new BasicStroke(3));

        // Calculate the circle's radius
        int radius = Math.min(scaledWidth, scaledHeight) / 2;
        int circleDiameter = 2 * radius;

        int circleX;
        int circleY;
        if (rotation == 1 || rotation == 3) {
            // Center the circle
            circleX = tempX + (scaledHeight - circleDiameter) / 2;
            circleY = tempY + (scaledWidth - circleDiameter) / 2;
        } else {
            // Center the circle
            circleX = tempX + (scaledWidth - circleDiameter) / 2;
            circleY = tempY + (scaledHeight - circleDiameter) / 2;
        }

        // Draw the outer boiler circle
        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.LIGHT_GRAY); // Boiler color
        }
        g.fillOval(circleX, circleY, circleDiameter, circleDiameter);

        if (getSelected()) {
            g.setColor(Color.BLUE);
        } else {
            g.setColor(Color.DARK_GRAY); // Border color
        }
        g.drawOval(circleX, circleY, circleDiameter, circleDiameter);

        // Draw the inner cross
        int centerX = circleX + radius; // Center of the circle (x-coordinate)
        int centerY = circleY + radius; // Center of the circle (y-coordinate)
        int crossLength = radius / 3;   // Length of cross arms

        g.setColor(Color.BLACK); // Cross color
        // Top-left to bottom-right diagonal
        g.drawLine(centerX - crossLength, centerY - crossLength,
                centerX + crossLength, centerY + crossLength);
        // Top-right to bottom-left diagonal
        g.drawLine(centerX + crossLength, centerY - crossLength,
                centerX - crossLength, centerY + crossLength);

        // Restore the original transform
        if (rotation != 0) {
            g.setTransform(oldTransform);
        }

        // Draw resize rectangle if in RESIZE state
        if (MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }
    }



    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
