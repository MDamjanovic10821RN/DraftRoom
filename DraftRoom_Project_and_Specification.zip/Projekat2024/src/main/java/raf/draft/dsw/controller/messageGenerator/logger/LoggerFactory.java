package raf.draft.dsw.controller.messageGenerator.logger;

import lombok.NoArgsConstructor;
import raf.draft.dsw.controller.messageGenerator.logger.loggers.ConsoleLogger;
import raf.draft.dsw.controller.messageGenerator.logger.loggers.FileLogger;

@NoArgsConstructor
public class LoggerFactory {
    public Logger createLogger (LoggerType loggerType){
        if(loggerType == LoggerType.CONSOLE){
            return new ConsoleLogger();
        } else if (loggerType == LoggerType.FILE) {
            return new FileLogger();
        }
        return null;
    }
}
