package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

public class ResizeCommand extends AbstractCommand {
    private RoomView currRoomView;
    private ItemPainter painter;
    int oldWidth;
    int oldHeight;
    int newWidth;
    int newHeight;

    public ResizeCommand(RoomView roomView, ItemPainter painter, int newWidth, int newHeight){
        this.currRoomView = roomView;
        this.painter = painter;
        this.oldWidth =  ((RoomItem)painter.getNode()).getWidth();
        this.oldHeight = ((RoomItem)painter.getNode()).getLength();
        this.newWidth = newWidth;
        this.newHeight = newHeight;
    }

    @Override
    public void doCommand() {
        painter.setTempScaledWidth((int)(newWidth * currRoomView.getCmToPx()));
        painter.setTempScaledLength((int)(newHeight * currRoomView.getCmToPx()));
        ((RoomItem)painter.getNode()).edit(painter.getNode().getName(), newWidth, newHeight);
    }

    @Override
    public void undoCommand() {
        painter.setTempScaledWidth((int)(oldWidth * currRoomView.getCmToPx()));
        painter.setTempScaledLength((int)(oldHeight * currRoomView.getCmToPx()));
        ((RoomItem)painter.getNode()).edit(painter.getNode().getName(), oldWidth, oldHeight);
    }
}
