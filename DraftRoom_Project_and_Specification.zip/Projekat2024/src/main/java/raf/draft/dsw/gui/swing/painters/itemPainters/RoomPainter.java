package raf.draft.dsw.gui.swing.painters.itemPainters;

import lombok.Getter;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import java.awt.*;

@Getter //NIJE U FUNKCIJI - IZBRISATI?
public class RoomPainter extends ItemPainter {

    private int panelHeight;
    private int panelWidth;
    private double cmToPxScale;

    int roomWidthPx;
    int roomHeightPx;

    public RoomPainter(DraftNode room, int h, int w) {
        super(room);
        this.panelHeight = h;
        this.panelWidth = w;

        double roomWidthCm = ((Room) room).getRoomWidth();
        double roomHeightCm = ((Room) room).getRoomLength();

        cmToPxScale = Math.min(panelWidth / roomWidthCm, panelHeight / roomHeightCm);

        roomWidthPx = (int) (roomWidthCm * cmToPxScale);
        roomHeightPx = (int) (roomHeightCm * cmToPxScale);

    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        Room room = (Room) getNode();

        double roomWidthCm = room.getRoomWidth();
        double roomHeightCm = room.getRoomLength();

        cmToPxScale = Math.min(panelWidth / roomWidthCm, panelHeight / roomHeightCm);

        roomWidthPx = (int) (roomWidthCm * cmToPxScale);
        roomHeightPx = (int) (roomHeightCm * cmToPxScale);

        // Calculate the top-left corner to center the rectangle in the panel
        int x = (panelWidth - roomWidthPx) / 2;
        int y = (panelHeight - roomHeightPx) / 2;

        // Draw the rectangle
        g.setColor(Color.WHITE); // Set a color for the rectangle
        g.fillRect(x, y, roomWidthPx, roomHeightPx);

        // Optional: Draw the border of the rectangle
        g.setColor(Color.BLACK);
        g.drawRect(x, y, roomWidthPx, roomHeightPx);
    }

    @Override
    public boolean itemAt(Point pos) {
        return false;
    }
}
