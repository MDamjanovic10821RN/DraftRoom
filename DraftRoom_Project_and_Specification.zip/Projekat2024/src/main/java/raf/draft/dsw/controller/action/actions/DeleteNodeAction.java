package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class DeleteNodeAction extends AbstractRoomAction {

    public DeleteNodeAction(){
        putValue(SMALL_ICON, loadIcon("/images/delete.png"));
        putValue(NAME, "Delete Node");
        putValue(SHORT_DESCRIPTION, "Delete Node");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        DraftTreeItem selectedNode = MainFrame.getInstance().getDraftTree().getSelectedNode();

        if(selectedNode instanceof DraftTreeItem){
            DraftNodeComposite parent = (DraftNodeComposite) selectedNode.getDraftNode().getParent();

            if(selectedNode.getDraftNode() instanceof ProjectExplorer){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NODE_CANNOT_BE_DELETED);

            }else if(selectedNode.getDraftNode() instanceof Room){
                MainFrame.getInstance().getDraftTree().removeChild(selectedNode);
                parent.removeChild(selectedNode.getDraftNode());
                ApplicationFramework.getInstance().getDraftRoomRepository().removeNestedElements(selectedNode.getDraftNode());

            }else if(selectedNode.getDraftNode() instanceof Building || selectedNode.getDraftNode() instanceof Project){
                if(selectedNode.getDraftNode() instanceof Building){
                    ((Project)selectedNode.getDraftNode().getParent()).setChanged(true);
                }
                MainFrame.getInstance().getDraftTree().removeChild(selectedNode);
                parent.removeChild(selectedNode.getDraftNode());
                ApplicationFramework.getInstance().getDraftRoomRepository().removeNestedElements(selectedNode.getDraftNode());

            }else if(selectedNode.getDraftNode() instanceof RoomItem){
                MainFrame.getInstance().getDraftTree().removeChild(selectedNode);
                parent.removeChild(selectedNode.getDraftNode());
                ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(selectedNode.getDraftNode());
            }
        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_NODES_SELECTED);
        }
    }
}
