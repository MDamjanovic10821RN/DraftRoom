package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.state.stateController.RotateStateController;

import javax.swing.*;
import java.awt.*;

public class RotationDialog extends JDialog{
    private JButton rightButton;
    private JButton leftButton;

    RotateStateController controllerClass;

    public RotationDialog(RotateStateController rotateStateController) {
        controllerClass = rotateStateController;
        this.setTitle("Rotation Direction");

        rightButton = new JButton("Rotate Right");
        leftButton = new JButton("Rotate Left");

        stylizeButton(rightButton);
        stylizeButton(leftButton);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.add(leftButton);
        buttonPanel.add(rightButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        setLayout(new BorderLayout(10, 10));
        setSize(300, 150);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(new Color(240, 240, 240));

        this.add(buttonPanel, BorderLayout.CENTER);

        rightButton.addActionListener(e -> {
            dispose();
            MainFrame.getInstance().getMountedProject().direction("RIGHT");
        });

        leftButton.addActionListener(e -> {
            dispose();
            MainFrame.getInstance().getMountedProject().direction("LEFT");
        });

        setModal(true);
        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }
}
