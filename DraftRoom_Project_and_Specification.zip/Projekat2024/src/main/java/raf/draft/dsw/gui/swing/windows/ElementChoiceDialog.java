package raf.draft.dsw.gui.swing.windows;

import raf.draft.dsw.controller.action.actions.CreateNodeAction;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.stateController.AddStateController;

import javax.swing.*;
import java.awt.*;

public class ElementChoiceDialog extends JDialog {

    private JButton doorButton;
    private JButton bedButton;
    private JButton tableButton;
    private JButton closetButton;
    private JButton showerButton;
    private JButton washerButton;
    private JButton boilerButton;
    private JButton sinkButton;
    private JButton toiletButton;
    private JLabel choiceLabel;

    AddStateController controllerClass;

    public ElementChoiceDialog(AddStateController addStateController) {
        controllerClass = addStateController;
        this.setTitle("Element Choice");

        choiceLabel = new JLabel("Choose what to create:");
        choiceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        choiceLabel.setForeground(new Color(60, 60, 60));
        choiceLabel.setHorizontalAlignment(SwingConstants.CENTER);

        doorButton = new JButton("Door");
        bedButton = new JButton("Bed");
        tableButton = new JButton("Table");
        closetButton = new JButton("Closet");
        showerButton = new JButton("Shower");
        washerButton = new JButton("Washer");
        boilerButton = new JButton("Boiler");
        sinkButton = new JButton("Sink");
        toiletButton = new JButton("Toilet");

        stylizeButton(doorButton);
        stylizeButton(bedButton);
        stylizeButton(tableButton);
        stylizeButton(closetButton);
        stylizeButton(showerButton);
        stylizeButton(washerButton);
        stylizeButton(boilerButton);
        stylizeButton(sinkButton);
        stylizeButton(toiletButton);


        doorButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.DOOR);
            dispose();
        });
        bedButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.BED);
            dispose();
        });
        tableButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.TABLE);
            dispose();
        });
        closetButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.CLOSET);
            dispose();
        });
        showerButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.SHOWER);
            dispose();
        });
        washerButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.WASHER);
            dispose();
        });
        boilerButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.BOILER);
            dispose();
        });
        sinkButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.SINK);
            dispose();
        });
        toiletButton.addActionListener(e -> {
            controllerClass.elementChosen(ElementType.TOILET);
            dispose();
        });

        setLayout(new BorderLayout(10, 10));
        add(choiceLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 3, 10, 10)); // 3 rows, 3 columns, 10px gaps
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        buttonPanel.add(doorButton);
        buttonPanel.add(bedButton);
        buttonPanel.add(tableButton);
        buttonPanel.add(closetButton);
        buttonPanel.add(showerButton);
        buttonPanel.add(washerButton);
        buttonPanel.add(boilerButton);
        buttonPanel.add(sinkButton);
        buttonPanel.add(toiletButton);

        add(buttonPanel, BorderLayout.CENTER);

        setSize(400, 300);
        setLocationRelativeTo(null);

        setModal(true);
        setVisible(true);
    }

    private void stylizeButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 110, 160), 1),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }
}
