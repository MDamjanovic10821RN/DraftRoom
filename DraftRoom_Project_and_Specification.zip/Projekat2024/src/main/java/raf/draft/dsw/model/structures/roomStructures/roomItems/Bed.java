package raf.draft.dsw.model.structures.roomStructures.roomItems;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.controller.tree.factories.RoomItemFactory;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.Prototype;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;

@Getter
@Setter
public class Bed extends RoomItem {

    public Bed(String name, DraftNode parent, int x, int y, int width, int length) {
        super(name, parent, x, y, width, length);
    }

    @Override
    public void setNodeName(String newName) {
        this.setName(newName);
        notifySubscribers(this);
    }

    @Override
    public void display(String name) {

    }

    @Override
    public Prototype kloniraj() {
        Room parent = (Room) getParent();
        parent.setChildTypeToAdd(ElementType.BED);

        RoomItemFactory nodeFactory = (RoomItemFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent);
        DraftNode child = nodeFactory.createNode(parent, getLocationX(), getLocationY(), getWidth(), getLength()); // Creating child
        ((RoomItem) child).setRotation(getRotation());

        String suffix = "(copy)";
        boolean enoughAlready = false;

        while(!enoughAlready){
            if(ApplicationFramework.getInstance().getDraftRoomRepository().exists(getName()+suffix)){
                suffix = suffix.concat("(copy)");
            }else {
                enoughAlready = true;
            }
        }
        child.setNodeName(getName()+suffix);

        return (Prototype) child;
    }
}
