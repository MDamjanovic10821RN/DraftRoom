package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.painters.itemPainters.*;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.Prototype;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CopyPasteCommand extends AbstractCommand {
    private RoomView currRoomView;
    private List<ItemPainter> painters;
    private List<ItemPainter> painterCopies;
    private int offset;

    public CopyPasteCommand(RoomView roomView, List<ItemPainter> copiedPainters, int offset){
        this.currRoomView = roomView;
        this.painters = copiedPainters;
        this.offset = offset;

        this.painterCopies = new ArrayList<>();
    }

    @Override
    public void doCommand() {
        if(painterCopies.isEmpty()){ // If there are no copies yet -> make them!
            Boolean showMessage = false;

            for(ItemPainter painter : painters){
                int newX = ((RoomItem)painter.getNode()).getLocationX() + offset;
                int newY = ((RoomItem)painter.getNode()).getLocationY() + offset;

                if(!currRoomView.outOfRoomBounds(newX, newY, ((RoomItem)painter.getNode()).getWidth(), ((RoomItem)painter.getNode()).getWidth() )){

                    Prototype copy = ((RoomItem) painter.getNode()).kloniraj();
                    ((RoomItem) copy).setLocationX(((RoomItem) painter.getNode()).getLocationX() + offset);
                    ((RoomItem) copy).setLocationY(((RoomItem) painter.getNode()).getLocationY() + offset);

                    ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(currRoomView.getRoom(), (DraftNode) copy); // Adding child to model
                    ((DraftNode)copy).addSubscriber(currRoomView);

                    ItemPainter copyPainter = null;
                    if(painter instanceof BedPainter){
                        copyPainter = new BedPainter((DraftNode) copy);
                    }if(painter instanceof BoilerPainter){
                        copyPainter = new BoilerPainter((DraftNode) copy);
                    }if(painter instanceof ClosetPainter){
                        copyPainter = new ClosetPainter((DraftNode) copy);
                    }if(painter instanceof DoorPainter){
                        copyPainter = new DoorPainter((DraftNode) copy);
                    }if(painter instanceof ShowerPainter){
                        copyPainter = new ShowerPainter((DraftNode) copy);
                    }if(painter instanceof SinkPainter){
                        copyPainter = new SinkPainter((DraftNode) copy);
                    }if(painter instanceof TablePainter){
                        copyPainter = new TablePainter((DraftNode) copy);
                    }if(painter instanceof ToiletPainter){
                        copyPainter = new ToiletPainter((DraftNode) copy);
                    }if(painter instanceof WasherPainter){
                        copyPainter = new WasherPainter((DraftNode) copy);
                    }

                    currRoomView.getPainters().add(copyPainter);
                    this.painterCopies.add(copyPainter);

                }else{
                    showMessage = true;
                }
            }

            if(showMessage){
                MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
            }
        }else{ // Else -> restore them!
            Room parent = currRoomView.getRoom();

            for (ItemPainter painter : painterCopies) {
                ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(parent, painter.getNode());
                currRoomView.getPainters().add(painter);
            }
        }
    }

    @Override
    public void undoCommand() {
        DraftTreeImplementation DTI = (DraftTreeImplementation)MainFrame.getInstance().getDraftTree();

        for(ItemPainter painter : painterCopies){
            DraftTreeItem nodeToDelete = DTI.findNodeByNameRecursive(DTI.getRoot(), painter.getNode().getName());
            DraftNodeComposite parent = (DraftNodeComposite) nodeToDelete.getDraftNode().getParent();

            MainFrame.getInstance().getDraftTree().removeChild(nodeToDelete);
            parent.removeChild(nodeToDelete.getDraftNode());
            ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(nodeToDelete.getDraftNode());

            currRoomView.getPainters().remove(painter);
        }
    }

}
