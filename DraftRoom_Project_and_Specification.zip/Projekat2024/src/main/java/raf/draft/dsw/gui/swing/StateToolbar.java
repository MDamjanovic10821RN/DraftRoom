package raf.draft.dsw.gui.swing;

import javax.swing.*;

public class StateToolbar extends JToolBar {
    public StateToolbar(){
        super(VERTICAL);
        setFloatable(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(MainFrame.getInstance().getActionManager().getSelectStateController());
        add(MainFrame.getInstance().getActionManager().getAddStateController());
        add(MainFrame.getInstance().getActionManager().getRemoveStateController());
        add(MainFrame.getInstance().getActionManager().getCopyPasteStateController());
        add(MainFrame.getInstance().getActionManager().getMoveStateController());
        add(MainFrame.getInstance().getActionManager().getEditStateController());

        addSeparator();
        add(Box.createVerticalGlue());

        add(MainFrame.getInstance().getActionManager().getResizeStateController());
        add(MainFrame.getInstance().getActionManager().getRotateStateController());
        add(MainFrame.getInstance().getActionManager().getZoomStateController());

    }
}
