package raf.draft.dsw.state.concrete;

import raf.draft.dsw.controller.command.concrete.AddCommand;
import raf.draft.dsw.controller.command.concrete.RemoveCommand;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RemoveState implements State {
    private RoomView currRoomView;
    private int x;
    private int y;

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        this.currRoomView = roomView;
        this.x = x;
        this.y = y;

//        Room room = (Room)roomView.getRoom();
        ItemPainter clickedPainter = roomView.clickedPainter(new Point(x, y));

        if(clickedPainter != null){

//            DraftTreeImplementation DTI = (DraftTreeImplementation)MainFrame.getInstance().getDraftTree();

            if(currRoomView.getSelectedPainters().contains(clickedPainter)){

                RemoveCommand removeCommand = new RemoveCommand(currRoomView, List.copyOf(currRoomView.getSelectedPainters()));
                currRoomView.getCommandManager().addCommand(removeCommand);

                // LOGIC MIGRATED TO RemoveCommand
//                for(ItemPainter selectedPainter : roomView.getSelectedPainters()){
//                    DraftTreeItem nodeToDelete = DTI.findNodeByNameRecursive(DTI.getRoot(), selectedPainter.getNode().getName());
//                    DraftNodeComposite parent = (DraftNodeComposite) nodeToDelete.getDraftNode().getParent();
//
//                    MainFrame.getInstance().getDraftTree().removeChild(nodeToDelete);
//                    parent.removeChild(nodeToDelete.getDraftNode());
//                    ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(nodeToDelete.getDraftNode());
//
//                    currRoomView.getPainters().remove(selectedPainter);
//                }
//
//                currRoomView.getSelectedPainters().clear();

            }else{

                List<ItemPainter> painterList = new ArrayList<>();
                painterList.add(clickedPainter);

                RemoveCommand removeCommand = new RemoveCommand(currRoomView, painterList);
                currRoomView.getCommandManager().addCommand(removeCommand);

                // LOGIC MIGRATED TO RemoveCommand
//                DraftTreeItem nodeToDelete = DTI.findNodeByNameRecursive(DTI.getRoot(), clickedPainter.getNode().getName());
//                DraftNodeComposite parent = (DraftNodeComposite) nodeToDelete.getDraftNode().getParent();
//
//                MainFrame.getInstance().getDraftTree().removeChild(nodeToDelete);
//                parent.removeChild(nodeToDelete.getDraftNode());
//                ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(nodeToDelete.getDraftNode());
//
//                currRoomView.getPainters().remove(clickedPainter);

            }
        }

    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {

    }

}
