package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class WasherPainter extends ItemPainter {

    public int scaledLength;
    public int scaledWidth;
    public WasherPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        }else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();
        if(rotation != 0){
            // Calculate the center of the item for rotation
            int centerX = x + scaledWidth / 2;
            int centerY = y + scaledHeight / 2;

            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), centerX, centerY);
            g.transform(rotationTransform);

            // Adjusting positions for rotate
            if (rotation == 1) { // 90
                x = x + scaledWidth - scaledHeight;
            } else if (rotation == 2) { // 180
                x = x - scaledWidth + scaledHeight;
                y = y - scaledHeight + scaledWidth;
            } else if (rotation == 3) { // 270
                y = y + scaledHeight - scaledWidth;
            }
        }

        g.setStroke(new BasicStroke(3));

        // Draw the outer washing machine rectangle
        if(getSelected()){
            g.setColor(Color.blue);
        }else {
            g.setColor(Color.WHITE); // Washing machine color
        }

        if(rotation == 1 || rotation == 3){
            g.fillRect(x, y, scaledHeight, scaledWidth);

            g.setColor(Color.DARK_GRAY); // Border color
            g.drawRect(x, y, scaledHeight, scaledWidth);

            // Determine the circle's size and position
            int radius = Math.min(scaledHeight, scaledWidth);
            int diameter = radius - radius / 5; // Circle's diameter
            int circleX = x + (scaledHeight - diameter) / 2; // Center the circle horizontally
            int circleY = y + (scaledWidth - diameter) / 2; // Center the circle vertically

            // Draw the inner washing machine circle
            g.setColor(Color.LIGHT_GRAY); // Circle (drum) color
            g.fillOval(circleX, circleY, diameter, diameter);

            g.setColor(Color.DARK_GRAY); // Circle border color
            g.drawOval(circleX, circleY, diameter, diameter);

        }else {
            g.fillRect(x, y, scaledWidth, scaledHeight);

            g.setColor(Color.DARK_GRAY); // Border color
            g.drawRect(x, y, scaledWidth, scaledHeight);

            // Determine the circle's size and position
            int radius = Math.min(scaledWidth, scaledHeight);
            int diameter = radius - radius / 5; // Circle's diameter
            int circleX = x + (scaledWidth - diameter) / 2; // Center the circle horizontally
            int circleY = y + (scaledHeight - diameter) / 2; // Center the circle vertically

            // Draw the inner washing machine circle
            g.setColor(Color.LIGHT_GRAY); // Circle (drum) color
            g.fillOval(circleX, circleY, diameter, diameter);

            g.setColor(Color.DARK_GRAY); // Circle border color
            g.drawOval(circleX, circleY, diameter, diameter);
        }

        if(rotation != 0){
            g.setTransform(oldTransform);
        }

        if (MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            g.setColor(Color.lightGray);
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }

    }


    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
