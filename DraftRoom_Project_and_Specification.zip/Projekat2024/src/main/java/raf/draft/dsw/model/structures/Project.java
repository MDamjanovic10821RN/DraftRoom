package raf.draft.dsw.model.structures;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;

@Getter
@Setter
public class Project extends DraftNodeComposite {
    private String name;
    private String author = "Author";
    private String pathToFolder = "Not Defined";
    @JsonIgnore
    private String childTypeToAdd = "BUILDING";
    @JsonIgnore
    private Boolean changed = false;

    public Project(String name, DraftNode parent, String autor, String putanjaDoFoldera) {
        super(name, parent);
        this.author = autor;
        this.pathToFolder = putanjaDoFoldera;
    }
    public Project(String name, DraftNode parent) {
        super(name, parent);
        this.name = name;
    }

    @Override
    public void addChild(DraftNode child) {
        if(child != null){
            if(child instanceof Building) {

                Building childBuilding = (Building) child;

                if(!this.getChildren().contains(childBuilding)) {
                    this.getChildren().add(childBuilding);
                    notifySubscribers(this);
                }

            }else if(child instanceof Room){

                Room childRoom = (Room) child;

                if(!this.getChildren().contains(childRoom)){
                    this.getChildren().add(childRoom);
                    notifySubscribers(this);
                }

            }
        }
    }

    @Override
    public void removeChild(DraftNode child) {
        if(child != null){
            if(child instanceof Building) {

                Building childBuilding = (Building) child;

                if (this.getChildren().contains(childBuilding)) {
                    this.getChildren().remove(childBuilding);
                    notifySubscribers(this);
                }

            }else if(child instanceof Room){

                Room childRoom = (Room) child;

                if(this.getChildren().contains(childRoom)){
                    this.getChildren().remove(childRoom);
                    notifySubscribers(this);
                }

            }
        }
    }

    public void edit(String name, String author, String path){
        this.name = name;
        this.author = author;
        this.pathToFolder = path;
        notifySubscribers(this);
    }

    public void setChanged(Boolean changed) {
        this.changed = changed;
    }
    public Boolean isChanged(){
        return changed;
    }

    @Override
    public void setNodeName(String newName) {

    }

    @Override
    public void display(String name) {

    }

    @Override
    public String toString() {
        return "Project{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", pathToFolder='" + pathToFolder + '\'' +
                '}';
    }
}
