package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.model.structures.roomStructures.roomItems.Door;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class DoorPainter extends ItemPainter {

    public int scaledWidth;
    public int scaledLength;
    public DoorPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {

        this.scaledLength = scaledHeight;
        this.scaledWidth = scaledWidth;

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        }else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();
        if(rotation != 0){
            // Calculate the center of the item for rotation
            int centerX = x + scaledWidth / 2;
            int centerY = y + scaledHeight / 2;

            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);

            // Adjusting positions for rotate

        }

        int tempX = x;
        int tempY = y;
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;
        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        // Draw the straight line (door edge)


        if(getSelected()){
            g.setColor(Color.BLUE);
        }else {
            g.setColor(Color.BLACK); // Door color
        }

        if(rotation == 1 || rotation == 3){

            int lineX1 = tempX; // Start of the line (top left corner)
            int lineY1 = tempY;
            int lineX2 = tempX; // End of the line (bottom left corner)
            int lineY2 = tempY + scaledWidth;
            g.setStroke(new BasicStroke(3)); // Thicker line for the door edge
            g.drawLine(lineX1, lineY1, lineX2, lineY2);
            // Draw the curved line (door arc)
            int arcWidth = scaledHeight * 2; // Width of the arc
            int arcHeight = scaledWidth *2 ; // Height of the arc
            int arcX = tempX - scaledHeight; // Adjust X to align arc with straight line
            int arcY = tempY; // Start arc at the same Y position as the top of the door
            g.drawArc(arcX, arcY, arcWidth, arcHeight, 0, 90); // Arc opening to the right

        }else{
            int lineX1 = tempX; // Start of the line (top left corner)
            int lineY1 = tempY;
            int lineX2 = tempX; // End of the line (bottom left corner)
            int lineY2 = tempY + scaledHeight;
            g.setStroke(new BasicStroke(3)); // Thicker line for the door edge
            g.drawLine(lineX1, lineY1, lineX2, lineY2);
            // Draw the curved line (door arc)
            int arcWidth = scaledWidth * 2; // Width of the arc
            int arcHeight = scaledHeight *2 ; // Height of the arc
            int arcX = tempX - scaledWidth; // Adjust X to align arc with straight line
            int arcY = tempY; // Start arc at the same Y position as the top of the door
            g.drawArc(arcX, arcY, arcWidth, arcHeight, 0, 90); // Arc opening to the right

        }


        if(rotation != 0){
            g.setTransform(oldTransform);
        }

        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            g.setColor(Color.lightGray);
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }

    }

    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
