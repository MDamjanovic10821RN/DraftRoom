package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

import java.util.List;

public class MoveCommand extends AbstractCommand {
    private RoomView currRoomView;
    private List<ItemPainter> painters;
    int deltaX;
    int deltaY;

    public MoveCommand(RoomView roomView, List<ItemPainter> painters, int deltaX, int deltaY){
        this.currRoomView = roomView;
        this.painters = painters;
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }

    @Override
    public void doCommand() {
        // Updating models loop
        for(ItemPainter painter : painters){
            RoomItem item = (RoomItem) painter.getNode();
            int newX = item.getLocationX() + deltaX;
            int newY = item.getLocationY() + deltaY;

            painter.setTempX(newX);
            painter.setTempY(newY);

            // Applying snapping to room borders
            applyBorderSnapping(painter);

            // To trigger update in Roomview when movement is validated ;)
            item.setCoords(painter.getTempX(), painter.getTempY());
        }
    }

    @Override
    public void undoCommand() {
        // Updating models loop
        for(ItemPainter painter : painters){
            RoomItem item = (RoomItem) painter.getNode();
            int newX = item.getLocationX() - deltaX;
            int newY = item.getLocationY() - deltaY;

            painter.setTempX(newX);
            painter.setTempY(newY);

            // Applying snapping to room borders
            applyBorderSnapping(painter);

            // To trigger update in Roomview when movement is validated ;)
            item.setCoords(painter.getTempX(), painter.getTempY());
        }
    }

    private Boolean applyBorderSnapping(ItemPainter painter) {
        RoomItem roomItem = (RoomItem) painter.getNode();
        Boolean snapped = false;

        // Top border
        if (Math.abs(painter.getTempY() - currRoomView.getRoomTopLeft().y) <= 10) {
            //roomItem.setLocationY(currRoomView.getRoomTopLeft().y);
            painter.setTempY(currRoomView.getRoomTopLeft().y);
            snapped = true;
        }

        // Left border
        if (Math.abs(painter.getTempX() - currRoomView.getRoomTopLeft().x) <= 10) {
            //roomItem.setLocationX(currRoomView.getRoomTopLeft().x);
            painter.setTempX(currRoomView.getRoomTopLeft().x);
            snapped = true;
        }

        // Bottom border
        if (Math.abs(currRoomView.getRoomBottomRight().y - (painter.getTempY() + roomItem.getLength() * currRoomView.getCmToPx())) <= 10) {
            int newY = (int) (currRoomView.getRoomBottomRight().y - roomItem.getLength() * currRoomView.getCmToPx());
            //roomItem.setLocationY(newY);
            painter.setTempY(newY);
            snapped = true;
        }

        // Right border
        if (Math.abs(currRoomView.getRoomBottomRight().x - (painter.getTempX() + roomItem.getWidth() * currRoomView.getCmToPx())) <= 10) {
            int newX = (int) (currRoomView.getRoomBottomRight().x - roomItem.getWidth() * currRoomView.getCmToPx());
            //roomItem.setLocationX(newX);
            painter.setTempX(newX);
            snapped = true;
        }

        return snapped;
    }

}
