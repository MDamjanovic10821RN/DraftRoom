package raf.draft.dsw.controller.tree;

import raf.draft.dsw.model.nodes.DraftNode;

public abstract class DraftNodeFactory {
    /**
     * Prosledjuje se instanca DraftNode-a koji treba da bude roditelj
     * novonastalom cvoru. Metoda vraca novu instancu iz node factory.
     * @param parent
     */
    public abstract DraftNode createNode(DraftNode parent);
}
