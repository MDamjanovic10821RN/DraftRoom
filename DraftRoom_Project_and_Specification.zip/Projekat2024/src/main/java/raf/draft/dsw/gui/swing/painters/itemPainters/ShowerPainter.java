package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class ShowerPainter extends ItemPainter {

    public int scaledLength;
    public int scaledWidth;

    public ShowerPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {
        this.scaledLength = scaledHeight;
        this.scaledWidth = scaledWidth;

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        } else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();
        if(rotation != 0) {
            // Rotate around the top-left corner (x, y)
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);

            // Adjusting positions for rotate

        }

        int tempX = x;
        int tempY = y;
        if (rotation == 1) { // 90 degrees
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180 degrees
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;
        } else if (rotation == 3) { // 270 degrees
            tempX = x - scaledHeight;
        }

        // Outer bath rectangle dimensions
        int outerArcWidth = scaledWidth / 5; // Slightly rounded corners
        int outerArcHeight = scaledHeight / 5;

        // Inner bath rectangle dimensions
        int innerPadding = Math.min(scaledWidth, scaledHeight) / 10; // Padding for inner rectangle
        int innerX = tempX + innerPadding;
        int innerY = tempY + innerPadding;
        int innerWidth = scaledWidth - 2 * innerPadding;
        int innerHeight = scaledHeight - 2 * innerPadding;
        int innerArcWidth = innerWidth / 2;  // Almost circular corners
        int innerArcHeight = innerHeight / 2;

        // Draw the outer bath
//        Stroke originalStroke = g.getStroke();
//        g.setStroke(new BasicStroke(3));

        if(getSelected()) {
            g.setColor(Color.blue);
        } else {
            g.setColor(Color.LIGHT_GRAY); // Bath color
        }

        if(rotation == 1 || rotation == 3) {
            g.fillRoundRect(tempX, tempY, scaledHeight, scaledWidth, outerArcWidth, outerArcHeight);
            g.setStroke(new BasicStroke(2));
            g.setColor(Color.DARK_GRAY); // Bath border color
            g.drawRoundRect(tempX, tempY, scaledHeight, scaledWidth, outerArcWidth, outerArcHeight);
            // Draw the inner bath rectangle
            g.setColor(Color.cyan); // Inner bath color
            g.fillRoundRect(innerX, innerY, innerHeight, innerWidth, innerArcHeight, innerArcWidth);
            g.setColor(Color.GRAY); // Inner bath border color
            g.drawRoundRect(innerX, innerY, innerHeight, innerWidth, innerArcHeight, innerArcWidth);
        }else{
            g.fillRoundRect(tempX, tempY, scaledWidth, scaledHeight, outerArcWidth, outerArcHeight);
            g.setStroke(new BasicStroke(2));
            g.setColor(Color.DARK_GRAY); // Bath border color
            g.drawRoundRect(tempX, tempY, scaledWidth, scaledHeight, outerArcWidth, outerArcHeight);
            // Draw the inner bath rectangle
            g.setColor(Color.cyan); // Inner bath color
            g.fillRoundRect(innerX, innerY, innerWidth, innerHeight, innerArcWidth, innerArcHeight);
            g.setColor(Color.GRAY); // Inner bath border color
            g.drawRoundRect(innerX, innerY, innerWidth, innerHeight, innerArcWidth, innerArcHeight);

        }


        if(rotation != 0) {
            g.setTransform(oldTransform);
        }

        // Draw resize rectangle if needed
        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            g.setColor(Color.lightGray);
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }
    }


    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
