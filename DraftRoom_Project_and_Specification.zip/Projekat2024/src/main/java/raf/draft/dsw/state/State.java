package raf.draft.dsw.state;

import raf.draft.dsw.gui.swing.windows.RoomView;

public interface State {

    void mouseClicked(int x, int y, RoomView roomView);
    void mousePressed(int x, int y, RoomView roomView);
    void mouseReleased(int x, int y, RoomView roomView);
    void mouseDragged(int x, int y, RoomView roomView);
    void createElement(int w, int l);
    void edit(String name, int width, int length);
    void prepare();
    void setElementToAdd(ElementType elementType);
    RoomView getRoomView();
    void direction(String direction);
    // dodati jos sve metode iz svih implementacija

}
