package raf.draft.dsw.state;

import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.state.concrete.*;

public class StateManager {

    private State currentState;

    //states:---------------------------------------------------
    private StartState startState;
    private AddState addState;
    private CopyPasteState copyPasteState;
    private EditState editState;
    private MoveState moveState;
    private RemoveState removeState;
    private ResizeState resizeState;
    private RotateState rotateState;
    private SelectState selectState;
    private ZoomState zoomState;
    //----------------------------------------------------------

    public StateManager() {
        initiateStates();
    }

    public void initiateStates(){

        startState = new StartState();
        addState = new AddState();
        copyPasteState = new CopyPasteState();
        editState = new EditState();
        moveState = new MoveState();
        removeState = new RemoveState();
        resizeState = new ResizeState();
        rotateState = new RotateState();
        selectState = new SelectState();
        zoomState = new ZoomState();

        currentState = startState;
    }

    public State getCurrentState() { return currentState; }

    //Setters:--------------------------------------------------
    public void setStartState() { currentState = startState; }
    public void setAddState(ElementType elementType) {
        currentState = addState;
        currentState.setElementToAdd(elementType);
        currentState.prepare();
    }
    public void setCopyPasteState() {
        currentState = copyPasteState;
        currentState.prepare();
    }
    public void setEditState() {
        currentState = editState;
        currentState.prepare();
    }
    public void setMoveState() {
        currentState = moveState;
        currentState.prepare();
    }
    public void setRemoveState() {
        currentState = removeState;
        currentState.prepare();
    }
    public void setResizeState() {
        currentState = resizeState;
        currentState.prepare();
    }
    public void setRotateState() {
        currentState = rotateState;
        currentState.prepare();
    }
    public void setSelectState() {
        currentState = selectState;
        currentState.prepare();
    }
    public void setZoomState() {
        currentState = zoomState;
        currentState.prepare();
    }

    //State Methods:--------------------------------------------
    public void doMouseClicked(int x, int y, RoomView roomView){ currentState.mouseClicked(x, y, roomView); }

    public void doMousePressed(int x, int y, RoomView roomView){ currentState.mousePressed(x, y, roomView); }

    public void doMouseReleased(int x, int y, RoomView roomView){
        currentState.mouseReleased(x, y, roomView);
    }

    public void doMouseDragged(int x, int y, RoomView roomView){
        currentState.mouseDragged(x, y, roomView);
    }

    public void doSetElementDimensions(int w, int l){ currentState.createElement(w, l); };

    public void doEdit(String name, int width, int length){ currentState.edit(name, width, length);}

    public RoomView doGetRoomView(){ return currentState.getRoomView(); }

    public void doPrepare(){ currentState.prepare(); }

    public void doDirection(String direction) { currentState.direction(direction); }

    // Dodati sve metode kako se budu dodavale u State interfejsu


}
