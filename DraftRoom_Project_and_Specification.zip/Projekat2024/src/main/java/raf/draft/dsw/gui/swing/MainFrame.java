package raf.draft.dsw.gui.swing;

import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.controller.action.ActionManager;
import raf.draft.dsw.gui.swing.TreeView.DraftTree;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.model.messages.Message;
import raf.draft.dsw.controller.messageGenerator.generator.MessageGenerator;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.model.structures.ProjectExplorer;

import javax.swing.*;
import java.awt.*;
@Getter
@Setter
public class MainFrame extends JFrame implements ISubscriber {

    private static MainFrame instance;

    private ActionManager actionManager;
    private MessageGenerator messageGenerator;

    private DraftTree draftTree;
    private JTree projectExplorerTree;

    private MyMenuBar menu;
    private MyToolBar toolBar;
    private StateToolbar stateToolbar;
    private JScrollPane workspace;
    private ProjectView mountedProject = null;

    private JPanel tempTextPanel;

    private MainFrame(){
        this.actionManager = new ActionManager();

        this.messageGenerator = new MessageGenerator();
        messageGenerator.addSubscriber(this);

        draftTree = new DraftTreeImplementation();

        initialize();
    }

    private void initialize(){
        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        int screenHeight = screenSize.height;
        int screenWidth = screenSize.width;
        setSize(screenWidth / 2, screenHeight / 2);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("DraftRoom");
    }

    /**
     * Funkcija koja omogucava odvajanje GUI komponenti od samog konstruktora MainFrame-a. Potrebno
     * je da bi se izbegla rekurzija -> ApplicationFramework zove konstruktor Mainframe-a koji zove
     * konstruktor odvojenih komponenti koje sadrzi. Svaka komponenta zove Mainframe.getInstance();
     * koji nije jos do kraja inicijalozovan -> vrti se u beskonacnoj rekurziji.
     */
    public void initializeGUIComponents(){

        menu = new MyMenuBar();
        setJMenuBar(menu);

        toolBar = new MyToolBar();
        add(toolBar, BorderLayout.NORTH);
        stateToolbar = new StateToolbar();
        add(stateToolbar, BorderLayout.EAST);

        workspace = new JScrollPane();
        JScrollPane treeScrollPane = new JScrollPane(projectExplorerTree);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, treeScrollPane, workspace);
        getContentPane().add(splitPane,BorderLayout.CENTER);
        splitPane.setDividerLocation(171);
        splitPane.setOneTouchExpandable(true);

        //pocetni ekran - nema selektovan projekat da se prikaze
        tempTextPanel = new JPanel(new GridBagLayout());
        tempTextPanel.setBackground(new Color(210, 210, 210));
        JLabel label = new JLabel("Workspace");
        label.setForeground(new Color(111, 111, 111));
        tempTextPanel.add(label);

        workspace.setViewportView(tempTextPanel);

    }

    public static MainFrame getInstance() {
        if(instance == null){
            instance = new MainFrame();
        }
        return instance;
    }

    /**
     * Funkcija prima Objekat tipa "Message" koja sadrzi Timestamp; enum ErrorCode; enum MessageType; i sam sadrzaj poruke.
     * U zavisnosti od MessageType, prikazace se proslednjena poruka u adekvatnom JOptionPane-u.
     */
    @Override
    public void update(Object notification) {

        if(notification instanceof Message){
            Message info = (Message) notification;
            switch (info.getMessageType().toString()){
                case "ERROR":
                    JOptionPane.showMessageDialog(this,info.getTimestamp()+" "+info.getErrorCode()+"\n\n"+info.getText(),"ERROR",JOptionPane.ERROR_MESSAGE);
                    break;
                case "WARNING":
                    JOptionPane.showMessageDialog(this,info.getTimestamp()+"\n"+info.getText(),"WARNING",JOptionPane.WARNING_MESSAGE);
                    break;
                case "NOTIFICATION":
                    JOptionPane.showMessageDialog(this,info.getTimestamp()+"\n"+info.getText(),"NOTIFICATION",JOptionPane.INFORMATION_MESSAGE);
                    break;
            }
        }else if(notification instanceof Class){
            // iskoristiti ovaj if za naredne IPublisher-e ukoliko ih bude bilo ovde
        }
    }

    public void generateTree(ProjectExplorer pe){
        projectExplorerTree = draftTree.generateTree(pe);
    }

    public void refreshTree(ProjectExplorer projectExplorer) {
        ((DraftTreeImplementation)draftTree).synchronizeTree(projectExplorer);
    }

    public void mountProjectView(ProjectView projectView){
        workspace.setViewportView(projectView);
        this.mountedProject = projectView;
    }
    public void dismountProjectView(){ workspace.setViewportView(tempTextPanel); }
}
