package raf.draft.dsw.state.stateController;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ProjectView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MoveStateController extends AbstractRoomAction {

    public MoveStateController(){
        putValue(SMALL_ICON, loadIcon("/images/move.png"));
        putValue(NAME, "Move Element");
        putValue(SHORT_DESCRIPTION, "Move Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.startMoveState();
        }
    }
}
