package raf.draft.dsw.state.stateController;

import lombok.Getter;
import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ProjectView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

@Getter
public class EditStateController extends AbstractRoomAction {

    public EditStateController(){
        putValue(SMALL_ICON, loadIcon("/images/editElement.png"));
        putValue(NAME, "Edit Element");
        putValue(SHORT_DESCRIPTION, "Edit Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.startEditState();
        }
    }

}
