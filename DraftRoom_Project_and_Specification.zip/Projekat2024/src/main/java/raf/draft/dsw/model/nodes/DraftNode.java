package raf.draft.dsw.model.nodes;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import raf.draft.dsw.controller.observer.IPublisher;
import raf.draft.dsw.controller.observer.ISubscriber;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;

import java.util.ArrayList;
import java.util.List;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type" // Add a "type" field in JSON to identify the subclass
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Project.class, name = "Project"),
        @JsonSubTypes.Type(value = Building.class, name = "Building"),
        @JsonSubTypes.Type(value = Room.class, name = "Room"),
        @JsonSubTypes.Type(value = Bed.class, name = "Bed"),
        @JsonSubTypes.Type(value = Boiler.class, name = "Boiler"),
        @JsonSubTypes.Type(value = Closet.class, name = "Closet"),
        @JsonSubTypes.Type(value = Door.class, name = "Door"),
        @JsonSubTypes.Type(value = Shower.class, name = "Shower"),
        @JsonSubTypes.Type(value = Sink.class, name = "Sink"),
        @JsonSubTypes.Type(value = Table.class, name = "Table"),
        @JsonSubTypes.Type(value = Toilet.class, name = "Toilet"),
        @JsonSubTypes.Type(value = Washer.class, name = "Washer")
})
@Getter
@Setter
public abstract class DraftNode implements IPublisher {
    private String name;
    @JsonIgnore
    private DraftNode parent;
    @JsonIgnore
    transient public List<ISubscriber> subscribers;

    public DraftNode(String name, DraftNode parent) {
        this.name = name;
        this.parent = parent;
    }

    @Override
    public void addSubscriber(ISubscriber subscriber) {
        if(subscriber == null) {
            return;
        }
        if(this.subscribers == null){
            this.subscribers = new ArrayList<>();
        }
        if(this.subscribers.contains(subscriber)) {
            return;
        }else{
            this.subscribers.add(subscriber);

        }
    }

    @Override
    public void removeSubscriber(ISubscriber subscriber) {
        if(subscriber == null || !(this.subscribers.contains(subscriber)) || this.subscribers == null){
            return;
        }
        else{
            this.subscribers.remove(subscriber);
        }
    }

    @Override
    public void notifySubscribers(Object notification) {
        if(notification == null || this.subscribers == null || this.getSubscribers().isEmpty()){
            return;
        }
        for(ISubscriber listener: subscribers){
            listener.update(notification);
        }
    }

    public abstract void setNodeName(String newName);

    //not in use
    public abstract void display(String name);


}
