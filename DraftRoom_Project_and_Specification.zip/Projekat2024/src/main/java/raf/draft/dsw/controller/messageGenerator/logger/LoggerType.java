package raf.draft.dsw.controller.messageGenerator.logger;

public enum LoggerType {
    CONSOLE,
    FILE
}
