package raf.draft.dsw.gui.swing.TreeView;

import com.sun.tools.javac.Main;
import lombok.Getter;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.controller.tree.DraftNodeFactory;
import raf.draft.dsw.controller.tree.factories.ProjectExplorerFactory;
import raf.draft.dsw.controller.tree.factories.RoomFactory;
import raf.draft.dsw.controller.tree.factories.RoomItemFactory;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;

import javax.swing.*;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
@Getter
public class DraftTreeImplementation implements DraftTree{

    private DraftTreeView treeView;
    private DefaultTreeModel treeModel;
    private DraftTreeItem root;

    @Override
    public DraftTreeView generateTree(ProjectExplorer projectExplorer) {

        this.root = new DraftTreeItem(projectExplorer);
        treeModel = new DefaultTreeModel(root);
        treeView = new DraftTreeView(treeModel);

        return treeView;
    }

    @Override
    public DraftTreeItem getSelectedNode() {
        return (DraftTreeItem) treeView.getLastSelectedPathComponent();
    }

    @Override
    public void addChild(DraftTreeItem parent) {

        if(!(parent.getDraftNode() instanceof DraftNodeComposite)){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_ADD_CHILD);

        }else if(parent.getDraftNode() instanceof Room) {
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_ADD_ITEM);

        }else{

            DraftNodeFactory nodeFactory = ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent.getDraftNode()); //dobija se odgovarajuca fabrika
            DraftNode child = nodeFactory.createNode(parent.getDraftNode()); //dobija se adekvatna instanca deteta

            parent.add(new DraftTreeItem(child)); //dodavanje na samo stablo
            ((DraftNodeComposite) parent.getDraftNode()).addChild(child); //dodavanje u logicku strukturu stabla
            ApplicationFramework.getInstance().getDraftRoomRepository().addElement(child); //dodavanje u repozitorijum

        }

        treeView.expandPath(treeView.getSelectionPath());
        SwingUtilities.updateComponentTreeUI(treeView);

    }

    /** Special instance of when Room must be created **/
    public void addChild(DraftTreeItem parent, int width, int length ) {

        if(!(parent.getDraftNode() instanceof Project) && !(parent.getDraftNode() instanceof Building)){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_ADD_CHILD);
        }else{
            DraftNodeFactory nodeFactory = ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent.getDraftNode()); //dobija se odgovarajuca fabrika
            DraftNode child = ((RoomFactory)nodeFactory).createNode(parent.getDraftNode(), width, length); //dobija se instanca sobe (Room)

            parent.add(new DraftTreeItem(child)); //dodavanje na samo stablo
            ((DraftNodeComposite) parent.getDraftNode()).addChild(child); //dodavanje u logicku strukturu stabla
            ApplicationFramework.getInstance().getDraftRoomRepository().addElement(child); //dodavanje u repozitorijum

            treeView.expandPath(treeView.getSelectionPath());
            SwingUtilities.updateComponentTreeUI(treeView);
        }

    }


    /** Special instance of when Room Template must be created **/
    public Room addChild(DraftTreeItem parent, int width, int length , String string ) {

        if(!(parent.getDraftNode() instanceof Project) && !(parent.getDraftNode() instanceof Building)){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_ADD_CHILD);
        }else{
            DraftNodeFactory nodeFactory = ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent.getDraftNode()); //dobija se odgovarajuca fabrika
            DraftNode child = ((RoomFactory)nodeFactory).createNode(parent.getDraftNode(), width, length); //dobija se instanca sobe (Room)

            parent.add(new DraftTreeItem(child)); //dodavanje na samo stablo
            ((DraftNodeComposite) parent.getDraftNode()).addChild(child); //dodavanje u logicku strukturu stabla
            ApplicationFramework.getInstance().getDraftRoomRepository().addElement(child); //dodavanje u repozitorijum

            treeView.expandPath(treeView.getSelectionPath());
            SwingUtilities.updateComponentTreeUI(treeView);
            return (Room) child;

        }
        return null;
    }


    /** Special instance of when RoomItem must be created **/
    public void addChild(DraftNode parent, DraftNode child){

        if(parent instanceof Room){

            DraftTreeItem parentTreeItem = findNodeByNameRecursive(root, ((Room)parent).getName());
            parentTreeItem.add(new DraftTreeItem(child));
            ((DraftNodeComposite)parent).addChild(child);
            ApplicationFramework.getInstance().getDraftRoomRepository().addElement(child);

            treeView.expandPath(treeView.getSelectionPath());
            SwingUtilities.updateComponentTreeUI(treeView);

        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_ADD_CHILD);
        }
    }

    /** Special instance of when loading existing project from file **/
    public void addChild(DraftNode parent, DraftNode child, Boolean flag){
        DraftTreeItem parentTreeItem = findNodeByNameRecursive(root, parent.getName());
        parentTreeItem.add(new DraftTreeItem(child));
        ((DraftNodeComposite)parent).addChild(child);
        ApplicationFramework.getInstance().getDraftRoomRepository().addElement(child);

        treeView.expandPath(treeView.getSelectionPath());
        SwingUtilities.updateComponentTreeUI(treeView);
    }

    @Override
    public void removeChild(DraftTreeItem child) {

        DraftNode forRemoval = null;
        DraftTreeItem parent = (DraftTreeItem) child.getParent();

        if(parent == null){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_NODES_SELECTED);
        }else{
            for(var node : ((DraftNodeComposite) parent.getDraftNode()).getChildren()){
                if(node.getName().equals(child.getDraftNode().getName()))
                    forRemoval = child.getDraftNode();
            }

            ((DraftNodeComposite) parent.getDraftNode()).removeChild(forRemoval);
            parent.remove(child);
            treeView.expandPath(treeView.getSelectionPath());
            SwingUtilities.updateComponentTreeUI(treeView);
        }
    }

    @Override
    public void refresh() {
        SwingUtilities.updateComponentTreeUI(treeView);
    }

    public DraftTreeItem findNodeByNameRecursive(DraftTreeItem node, String name) {

        if (node == null) {
            return null;
        }

        // Checking if current node matches name
        if (node.toString().equals(name)) {
            return node;
        }

        // Recursively checking all children
        for (int i = 0; i < node.getChildCount(); i++) {
            DraftTreeItem child = (DraftTreeItem) node.getChildAt(i);
            DraftTreeItem result = findNodeByNameRecursive(child, name);
            if (result != null) {
                return result;
            }
        }

        return null; // Not found
    }

    public void synchronizeTree(DraftNodeComposite rootNode) {
        root = new DraftTreeItem(rootNode);
        buildTreeRecursive(rootNode, root);

        // Update model and view
        treeModel.setRoot(root);
        SwingUtilities.updateComponentTreeUI(treeView);
    }

    private void buildTreeRecursive(DraftNodeComposite parentNode, DraftTreeItem parentItem) {
        for (DraftNode childNode : parentNode.getChildren()) {
            DraftTreeItem childItem = new DraftTreeItem(childNode);
            parentItem.add(childItem);

            if (childNode instanceof DraftNodeComposite) {
                buildTreeRecursive((DraftNodeComposite) childNode, childItem);
            }
        }
    }

}
