package raf.draft.dsw.gui.swing.TreeView.treeElements;

import raf.draft.dsw.model.nodes.DraftNode;

import javax.swing.tree.DefaultMutableTreeNode;

public class DraftTreeItem extends DefaultMutableTreeNode {
    private DraftNode draftNode;

    public DraftTreeItem(DraftNode nodeModel){
        this.draftNode = nodeModel;
    }

    public DraftNode getDraftNode(){ return draftNode; }

    public void setName(String name){ this.draftNode.setName(name); }

    @Override
    public String toString() {
        return draftNode.getName();
    }
}
