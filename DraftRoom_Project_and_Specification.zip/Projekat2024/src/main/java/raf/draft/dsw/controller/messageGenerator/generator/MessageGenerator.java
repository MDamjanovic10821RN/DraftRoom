package raf.draft.dsw.controller.messageGenerator.generator;

import lombok.NoArgsConstructor;
import raf.draft.dsw.controller.observer.IPublisher;
import raf.draft.dsw.controller.observer.ISubscriber;
import raf.draft.dsw.model.messages.Message;
import raf.draft.dsw.model.messages.MessageType;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * MessagGenerator klasa sluzi da bi se generisala (najcesce) ERROR poruka i
 * prosledila Listener-ima koji osluskuju i treba da prikazu kreirane poruke.
 */
@NoArgsConstructor
public class MessageGenerator implements IPublisher {

    private List<ISubscriber> subscribers;

    public void generateMessage(ErrorCode errorCode){

        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = currentTime.format(formatter);

        Message message;

        switch (errorCode.toString()){
            case "TEST":
                message = new Message("Don't be alarmed. This is just a test message!", MessageType.ERROR, ErrorCode.TEST, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "NODE_CANNOT_BE_DELETED":
                message = new Message("The node you have selected cannot be deleted.", MessageType.ERROR, ErrorCode.NODE_CANNOT_BE_DELETED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "FIELDS_CANNOT_BE_EMPTY":
                message = new Message("The given fields cannot be left empty.", MessageType.ERROR, ErrorCode.FIELDS_CANNOT_BE_EMPTY, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "NO_NODES_SELECTED":
                message = new Message("No selected tree items for action to execute.", MessageType.ERROR, ErrorCode.NO_NODES_SELECTED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "CANNOT_ADD_CHILD":
                message = new Message("Only Project Explorer, Projects, and buildings can have subdivisions.", MessageType.ERROR, ErrorCode.CANNOT_ADD_CHILD, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "CANNOT_EDIT_NODE":
                message = new Message("Project Explorer cannot be edited.", MessageType.ERROR, ErrorCode.CANNOT_EDIT_NODE, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "DUPLICATES_NOT_PERMITTED":
                message = new Message("Duplicate names are not permitted.", MessageType.ERROR, ErrorCode.DUPLICATES_NOT_PERMITTED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "INVALID_TYPES":
                message = new Message("The values you inserted are not the correct type.", MessageType.ERROR, ErrorCode.INVALID_TYPES, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "CANNOT_DELETE_ITEM":
                message = new Message("Room items cannot be deleted from tree structure.", MessageType.ERROR, ErrorCode.CANNOT_DELETE_ITEM, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "CANNOT_ADD_ITEM":
                message = new Message("Room items cannot be added from tree structure.", MessageType.ERROR, ErrorCode.CANNOT_ADD_ITEM, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "ITEM_OUT_OF_BOUNDS":
                message = new Message("Room items cannot intersect room or other items.", MessageType.ERROR, ErrorCode.ITEM_OUT_OF_BOUNDS, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "NOTHING_COPIED":
                message = new Message("No selected items in room to be copied. Select item(s) you wish to copy.\nIDEJA: prvo se selektuju itemi, na klik dugmeta za Copy/Paste state se kopiraju;\nKlikom misem na sobu se nalepe.", MessageType.NOTIFICATION, ErrorCode.NOTHING_COPIED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "ITEMS_COPIED":
                message = new Message("Selected item(s) copied. Click anywhere in room to paste.", MessageType.NOTIFICATION, ErrorCode.ITEMS_COPIED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "SAVE_AS_FIRST":
                message = new Message("The project hasn't been saved to a location yet.", MessageType.ERROR, ErrorCode.SAVE_AS_FIRST, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "PROJECT_SAVED":
                message = new Message("Project successfully saved.", MessageType.NOTIFICATION, ErrorCode.PROJECT_SAVED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "NO_OPEN_ROOM":
                message = new Message("There are no opened room tabs.", MessageType.ERROR, ErrorCode.NO_OPEN_ROOM, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "TEMPLATE_SAVED":
                message = new Message("Template successfully saved.", MessageType.NOTIFICATION, ErrorCode.TEMPLATE_SAVED, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "HOW_TO_LOAD_TEMPLATE":
                message = new Message("Project or Buidling where you would like to add new template room must be selected in tree structure.", MessageType.NOTIFICATION, ErrorCode.HOW_TO_LOAD_TEMPLATE, "["+timestamp+"]");
                notifySubscribers(message);
                break;
            case "MUST_OPEN_PROJECT_FIRST":
                message = new Message("Project where you would like to load the template must be opened first", MessageType.ERROR, ErrorCode.MUST_OPEN_PROJECT_FIRST, "["+timestamp+"]");
                notifySubscribers(message);
                break;




        }
    }

    @Override
    public void addSubscriber(ISubscriber subscriber) {
        if(subscriber == null) {
            return;
        }
        if(this.subscribers == null){
            this.subscribers = new ArrayList<ISubscriber>();
        }
        if(this.subscribers.contains(subscriber)) {
            return;
        }else{
            this.subscribers.add(subscriber);
        }
    }

    @Override
    public void removeSubscriber(ISubscriber subscriber) {
        if(subscriber == null || !this.subscribers.contains(subscriber) || this.subscribers == null){
            return;
        }else{
            this.subscribers.remove(subscriber);
        }
    }

    @Override
    public void notifySubscribers(Object notification) {
        if(notification == null || this.subscribers == null || this.subscribers.isEmpty()) {
            System.out.println("[MESSAGE GENERATOR:] Problem with notification and/or subscribers list:\n notification: "+notification+"\n subscribers: "+subscribers);
            return;
        }

        for(ISubscriber listener: subscribers){
            listener.update(notification);
        }

    }
}
