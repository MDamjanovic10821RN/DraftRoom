package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class AboutUsAction extends AbstractRoomAction {

    public AboutUsAction(){
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_I, ActionEvent.ALT_MASK));
        putValue(SMALL_ICON, loadIcon("/images/aboutUs.png"));
        putValue(NAME, "About Us");
        putValue(SHORT_DESCRIPTION, "About us");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ImageIcon us = new ImageIcon(getClass().getResource("/images/us.jpg"));
        JOptionPane.showMessageDialog(MainFrame.getInstance(),"MILOŠ DAMJANOVIĆ\nindex: 108/2021/RN\n \n \nFILIP ZDRAVKOVIĆ\nindex: 134/2022/RN", "a photo of us",JOptionPane.INFORMATION_MESSAGE, us);
    }
}
