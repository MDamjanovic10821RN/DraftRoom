package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.controller.tree.factories.RoomItemFactory;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.painters.itemPainters.*;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;

public class AddCommand extends AbstractCommand {
    private RoomView currRoomView;
    private RoomItem item;
    private ItemPainter painter;
    private ElementType elementToAdd;
    private int x;
    private int y;
    private int elementWidth;
    private int elementLength;

    public AddCommand(RoomView roomView, RoomItem roomItem, ItemPainter itemPainter, ElementType elementToAdd, int x, int y, int elementWidth, int elementLength){
        this.currRoomView = roomView;
        this.item = roomItem;
        this.painter = itemPainter;

        this.elementToAdd = elementToAdd;
        this.x = x;
        this.y = y;
        this.elementWidth = elementWidth;
        this.elementLength = elementLength;
    }

    @Override
    public void doCommand() {

        if(item == null){// If the item == null (first call of doCommand for this item)-> create new node and painter
            Room parent = currRoomView.getRoom();
            RoomItemFactory nodeFactory = (RoomItemFactory) ApplicationFramework.getInstance().getDraftNodeFactory().getFactory(parent);
            DraftNode child = nodeFactory.createNode(parent, x, y, elementWidth,  elementLength); // Creating child
            ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(currRoomView.getRoom(), child); // Adding child to model

            this.item = (RoomItem) child;
            child.addSubscriber(currRoomView);

            //---------------------------------------------------Adding adequate painter to CurrRoomView:
            switch (elementToAdd) {
                case BED:   BedPainter bdpt = new BedPainter((DraftNode) child);
                            currRoomView.getPainters().add(bdpt);
                            this.painter = (ItemPainter) bdpt;
                            break;
                case DOOR:  DoorPainter dpt = new DoorPainter((DraftNode) child);
                            currRoomView.getPainters().add(dpt);
                            this.painter = (ItemPainter) dpt;
                            break;
                case SINK:  SinkPainter skpt = new SinkPainter((DraftNode) child);
                            currRoomView.getPainters().add(skpt);
                            this.painter = (ItemPainter) skpt;
                            break;
                case TABLE: TablePainter tbpt = new TablePainter((DraftNode) child);
                            currRoomView.getPainters().add(tbpt);
                            this.painter = (ItemPainter) tbpt;
                            break;
                case BOILER:BoilerPainter blpt = new BoilerPainter((DraftNode) child);
                            currRoomView.getPainters().add(blpt);
                            this.painter = (ItemPainter) blpt;
                            break;
                case CLOSET:ClosetPainter clpt = new ClosetPainter((DraftNode) child);
                            currRoomView.getPainters().add(clpt);
                            this.painter = (ItemPainter) clpt;
                            break;
                case SHOWER:ShowerPainter swpt = new ShowerPainter((DraftNode) child);
                            currRoomView.getPainters().add(swpt);
                            this.painter = (ItemPainter) swpt;
                            break;
                case TOILET:ToiletPainter topt = new ToiletPainter((DraftNode) child);
                            currRoomView.getPainters().add(topt);
                            this.painter = (ItemPainter) topt;
                            break;
                case WASHER:WasherPainter wapt = new WasherPainter((DraftNode) child);
                            currRoomView.getPainters().add(wapt);
                            this.painter = (ItemPainter) wapt;
                            break;
            }

        }else{ // Else -> don't create a new node, use the existing one
            ((DraftTreeImplementation) MainFrame.getInstance().getDraftTree()).addChild(currRoomView.getRoom(), item);
            currRoomView.getPainters().add(painter);
        }
    }

    @Override
    public void undoCommand() {
        DraftTreeImplementation DTI = (DraftTreeImplementation)MainFrame.getInstance().getDraftTree();

        DraftTreeItem nodeToDelete = DTI.findNodeByNameRecursive(DTI.getRoot(), painter.getNode().getName());
        DraftNodeComposite parent = (DraftNodeComposite) nodeToDelete.getDraftNode().getParent();

        MainFrame.getInstance().getDraftTree().removeChild(nodeToDelete);
        parent.removeChild(nodeToDelete.getDraftNode());
        ApplicationFramework.getInstance().getDraftRoomRepository().removeElement(nodeToDelete.getDraftNode());

        currRoomView.getPainters().remove(painter);
    }
}
