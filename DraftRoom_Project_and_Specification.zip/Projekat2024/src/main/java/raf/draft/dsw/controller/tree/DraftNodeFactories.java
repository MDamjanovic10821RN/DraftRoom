package raf.draft.dsw.controller.tree;

import lombok.NoArgsConstructor;
import raf.draft.dsw.controller.tree.factories.*;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;
import raf.draft.dsw.model.structures.Room;

@NoArgsConstructor
public class DraftNodeFactories {
    private ProjectExplorerFactory projectExplorerFactory = new ProjectExplorerFactory();
    private ProjectFactory projectFactory = new ProjectFactory();
    private BuildingFactory buildingFactory = new BuildingFactory();
    private RoomFactory roomFactory = new RoomFactory();
    private RoomItemFactory roomItemFactory = new RoomItemFactory();

    /**
     * node = null -> projectExplorerFactory
     * node = ProjectExplorer -> projectFactory
     * node = Project -> buildingFactory
     * node = Building -> roomFactory
     * node = Room -> roomItemFactory
     * error -> null
     * @param node
     * @return
     */
    public DraftNodeFactory getFactory(DraftNode node){
        if(node == null){
            return projectExplorerFactory;
        }else if(node instanceof ProjectExplorer){
            return projectFactory;
        }else if(node instanceof Project){
            if(((Project)node).getChildTypeToAdd().equals("BUILDING")) {
                return buildingFactory;
            }else if(((Project)node).getChildTypeToAdd().equals("ROOM")){
                return roomFactory;
            }
        }else if(node instanceof Building){
            return roomFactory;
        }else if(node instanceof Room){
            return roomItemFactory;
        }else{
            return null;
        }
        return null;
    }
}
