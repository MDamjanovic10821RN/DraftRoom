package raf.draft.dsw.model.repository;

import jdk.dynalink.linker.LinkerServices;
import lombok.Getter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;

import java.util.Iterator;
import java.util.List;
@Getter
public class DraftRoomRepository {
    private ProjectExplorer projectExplorer;
    private List<DraftNode> elements;

    public DraftRoomRepository(List<DraftNode> elements, ProjectExplorer projectExplorer) {
        this.projectExplorer = projectExplorer;
        this.elements = elements;
        this.elements.add(projectExplorer);
    }

    public void addElement(DraftNode node) {
        if (!elements.contains(node)) {
            elements.add(node);
        }
    }

    public void removeElement(DraftNode node) {
        if(elements.contains(node)) {
            elements.remove(node);
        }
    }

    public void removeNestedElements(DraftNode node){
        if (elements.contains(node)) {
            elements.remove(node);

            Iterator<DraftNode> iterator = elements.iterator();
            while (iterator.hasNext()) {
                DraftNode current = iterator.next();
                if (!elements.contains(current.getParent())) {
                    iterator.remove();
                }
            }
        }
    }

    public DraftNode getElement(String elementName){
        for(DraftNode element : elements){
            if(element.getName().equals(elementName)){
                return element;
            }
        }
        return null;
    }

    public Boolean exists(String elementName){
        Boolean exists = false;

        for(DraftNode currentNode : elements){
            if(currentNode.getName().equals(elementName)){
                return true;
            }
        }

        return exists;
    }

    public void editElement(DraftNode OGNode, String name, String author, String filePath){

        if(OGNode instanceof Project){
            for(DraftNode element : elements){
                if(element.getName().equals(OGNode.getName())){
                    element.setName(name);
                    ((Project)element).setAuthor(author);
                    ((Project)element).setPathToFolder(filePath);
                    break;
                }
            }
        }else{
            for(DraftNode element : elements){
                if(element.getName().equals(OGNode.getName())){
                    element.setName(name);
                    break;
                }
            }
        }
    }

}
