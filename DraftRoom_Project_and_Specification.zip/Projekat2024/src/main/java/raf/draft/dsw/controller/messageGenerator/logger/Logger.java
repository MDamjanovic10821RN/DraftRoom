package raf.draft.dsw.controller.messageGenerator.logger;

import raf.draft.dsw.model.messages.Message;
import raf.draft.dsw.model.messages.MessageType;

public interface Logger {
    void log(Message message, MessageType messageType);
}
