package raf.draft.dsw.controller.command.concrete;

import raf.draft.dsw.controller.command.AbstractCommand;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;

public class EditCommand extends AbstractCommand {
    private RoomView currRoomView;
    private ItemPainter painter;
    int oldWidth;
    int oldHeight;
    String oldName;
    int newWidth;
    int newHeight;
    String newName;

    public EditCommand(RoomView roomView, ItemPainter painter, int newWidth, int newHeight, String newName){
        this.currRoomView = roomView;
        this.painter = painter;
        this.oldWidth =  ((RoomItem)painter.getNode()).getWidth();
        this.oldHeight = ((RoomItem)painter.getNode()).getLength();
        this.oldName = painter.getNode().getName();
        this.newWidth = newWidth;
        this.newHeight = newHeight;
        this.newName = newName;
    }

    @Override
    public void doCommand() {
        ((RoomItem)painter.getNode()).edit(newName, newWidth, newHeight);
        if(!newName.equals(oldName)){ MainFrame.getInstance().getDraftTree().refresh(); }
    }

    @Override
    public void undoCommand() {
        ((RoomItem)painter.getNode()).edit(oldName, oldWidth, oldHeight);
        if(!newName.equals(oldName)){ MainFrame.getInstance().getDraftTree().refresh(); }
    }
}
