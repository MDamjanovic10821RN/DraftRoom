package raf.draft.dsw.controller.tree.factories;

import raf.draft.dsw.controller.tree.DraftNodeFactory;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.nodes.DraftNodeComposite;
import raf.draft.dsw.model.structures.Project;

public class ProjectFactory extends DraftNodeFactory {
    public static int count = 0;
    @Override
    public DraftNode createNode(DraftNode parent) {
        count++;
        return new Project("Project" + count, parent);
    }
}
