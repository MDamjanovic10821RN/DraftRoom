package raf.draft.dsw.state.stateController;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ElementChoiceDialog;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.state.ElementType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AddStateController extends AbstractRoomAction {

    public AddStateController(){
        putValue(SMALL_ICON, loadIcon("/images/addElement.png"));
        putValue(NAME, "Add Element");
        putValue(SHORT_DESCRIPTION, "Add Element");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ElementChoiceDialog elementChoiceDialog = new ElementChoiceDialog(this);
        }
    }

    public void elementChosen(ElementType elementType){
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.startAddState(elementType);
        }
    }

}
