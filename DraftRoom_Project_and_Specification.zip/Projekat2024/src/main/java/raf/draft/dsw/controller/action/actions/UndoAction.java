package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.ElementChoiceDialog;
import raf.draft.dsw.gui.swing.windows.RoomView;

import java.awt.event.ActionEvent;

public class UndoAction extends AbstractRoomAction {

    public UndoAction(){
        putValue(SMALL_ICON, loadIcon("/images/undo.png"));
        putValue(NAME, "Undo");
        putValue(SHORT_DESCRIPTION, "Undo");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(MainFrame.getInstance().getMountedProject() != null){
            RoomView roomView = MainFrame.getInstance().getMountedProject().openRoom();
            if(roomView != null){
                roomView.getCommandManager().undoCommand();
            }
        }
    }
}
