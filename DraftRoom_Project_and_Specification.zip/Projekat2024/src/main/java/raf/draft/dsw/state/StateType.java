package raf.draft.dsw.state;

public enum StateType {
    ADD,
    CP,
    EDIT,
    MOVE,
    REMOVE,
    RESIZE,
    ROTATE,
    SELECT,
    ZOOM,
    START
}
