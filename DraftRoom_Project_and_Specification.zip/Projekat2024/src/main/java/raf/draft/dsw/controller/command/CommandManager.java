package raf.draft.dsw.controller.command;

import raf.draft.dsw.gui.swing.windows.RoomView;

import java.util.ArrayList;
import java.util.List;

public class CommandManager {
    private List<AbstractCommand> commands = new ArrayList<AbstractCommand>();
    private int currentCommand = 0;

    RoomView roomView;

    public CommandManager(RoomView roomView){
        this.roomView = roomView;
    }

    public void addCommand(AbstractCommand command){
        while(currentCommand < commands.size())
            commands.remove(currentCommand);
        commands.add(command);
        doCommand();
    }

    public void doCommand(){
        if(currentCommand < commands.size()){
            commands.get(currentCommand++).doCommand();
        }
    }

    public  void undoCommand(){
        if(currentCommand > 0){
            commands.get(--currentCommand).undoCommand();
        }
    }
}
