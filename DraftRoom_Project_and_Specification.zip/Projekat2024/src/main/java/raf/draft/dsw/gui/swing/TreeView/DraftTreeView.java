package raf.draft.dsw.gui.swing.TreeView;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeCellRenderer;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeSelectionListener;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;

import javax.swing.*;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DraftTreeView extends JTree {
    public DraftTreeView(DefaultTreeModel defaultTreeModel){
        setModel(defaultTreeModel);
        DraftTreeCellRenderer treeCellRenderer = new DraftTreeCellRenderer();
        addTreeSelectionListener(new DraftTreeSelectionListener());
        setCellRenderer(treeCellRenderer);
        setEditable(true);

        this.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e){
                if(e.getClickCount()==2){
                    expandPath(getSelectionPath());

                    Object[] path = getSelectionPath().getPath();
                    Project project = null;
                    Building building = null;

                    if(path.length == 1) return;

                    for(Object o: path){

                        if(((DraftTreeItem) o).getDraftNode() instanceof Project) {
                            MainFrame.getInstance().mountProjectView(new ProjectView(((DraftTreeItem) o).getDraftNode()));
                        }

                        if(((DraftTreeItem) o).getDraftNode() instanceof Building){
                            building = (Building) ((DraftTreeItem) o).getDraftNode();
                        }
                    }
                }
            }
        });
    }
}
