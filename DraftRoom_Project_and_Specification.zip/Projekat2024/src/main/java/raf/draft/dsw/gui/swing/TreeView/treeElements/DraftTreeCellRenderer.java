package raf.draft.dsw.gui.swing.TreeView.treeElements;

import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;
import raf.draft.dsw.model.structures.Room;
import raf.draft.dsw.model.structures.roomStructures.roomItems.*;

import javax.swing.*;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;
import java.net.URL;

public class DraftTreeCellRenderer extends DefaultTreeCellRenderer {
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {

        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        URL imageURL = null;

        if (((DraftTreeItem)value).getDraftNode() instanceof ProjectExplorer) {
            imageURL = getClass().getResource("/images/projectExplorer.png");
        }
        else if (((DraftTreeItem)value).getDraftNode() instanceof Project) {
            imageURL = getClass().getResource("/images/project.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Building){
            imageURL = getClass().getResource("/images/building.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Room){
            imageURL = getClass().getResource("/images/room.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Bed){
            imageURL = getClass().getResource("/images/bed.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Boiler){
            imageURL = getClass().getResource("/images/boiler.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Closet){
            imageURL = getClass().getResource("/images/closet.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Door){
            imageURL = getClass().getResource("/images/door.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Shower){
            imageURL = getClass().getResource("/images/shower.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Sink){
            imageURL = getClass().getResource("/images/sink.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Table){
            imageURL = getClass().getResource("/images/table.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Toilet){
            imageURL = getClass().getResource("/images/toilet.png");
        }
        else if(((DraftTreeItem)value).getDraftNode() instanceof Washer){
            imageURL = getClass().getResource("/images/washer.png");
        }

        Icon icon = null;
        if (imageURL != null) {
            ImageIcon originalIcon = new ImageIcon(imageURL);
            Image resizedImage = originalIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH); // Set desired width & height
            icon = new ImageIcon(resizedImage);
        }
        setIcon(icon);

        return this;
    }
}
