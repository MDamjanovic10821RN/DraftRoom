package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.core.ApplicationFramework;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.TreeView.DraftTreeImplementation;
import raf.draft.dsw.gui.swing.TreeView.treeElements.DraftTreeItem;
import raf.draft.dsw.gui.swing.windows.AddProjectChildDialog;
import raf.draft.dsw.gui.swing.windows.RoomDimensionsDialog;
import raf.draft.dsw.model.structures.Building;
import raf.draft.dsw.model.structures.Project;

import java.awt.event.ActionEvent;

public class CreateNodeAction extends AbstractRoomAction {

    public CreateNodeAction(){
        putValue(SMALL_ICON, loadIcon("/images/create.png"));
        putValue(NAME, "Create node");
        putValue(SHORT_DESCRIPTION, "Create Node");
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        DraftTreeItem selectedNode = MainFrame.getInstance().getDraftTree().getSelectedNode();

        if(selectedNode instanceof DraftTreeItem){
            if(selectedNode.getDraftNode() instanceof Project){ //ako prosledjen Project
                AddProjectChildDialog dialog = new AddProjectChildDialog(this);
                ((Project)selectedNode.getDraftNode()).setChanged(true);

            }else if(selectedNode.getDraftNode() instanceof Building){ //Ako prosledjen Building, ProjectExplorer, Room - > isto kao ranije
                RoomDimensionsDialog dialog = new RoomDimensionsDialog(this);
                ((Project)selectedNode.getDraftNode().getParent()).setChanged(true);

            }else{//Ako prosledjen ProjectExplorer, Room - > isto kao ranije
                MainFrame.getInstance().getDraftTree().addChild(selectedNode);

            }
        }else{
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_NODES_SELECTED);
        }
    }

    /**
     * Type string: BUILDING ili ROOM
     * @param type
     */
    public void addChildToProject(String type, int width, int length){ //wrapper funkcija da bi se ispostovala MVC arhitektura

        DraftTreeItem selectedProject = MainFrame.getInstance().getDraftTree().getSelectedNode();
        ((Project)selectedProject.getDraftNode()).setChildTypeToAdd(type);

        if(type.equals("ROOM")){
            ((DraftTreeImplementation)MainFrame.getInstance().getDraftTree()).addChild(selectedProject, width, length);
        }else{
            MainFrame.getInstance().getDraftTree().addChild(selectedProject);
        }

        ((Project)selectedProject.getDraftNode()).setChanged(true);
    }

    public void addRoomToBuilding(int width, int length){

        DraftTreeItem selectedBuilding = MainFrame.getInstance().getDraftTree().getSelectedNode();
        ((DraftTreeImplementation)MainFrame.getInstance().getDraftTree()).addChild(selectedBuilding, width, length);

        ((Project)selectedBuilding.getDraftNode().getParent()).setChanged(true);
    }

}
