package raf.draft.dsw.state.concrete;

import raf.draft.dsw.controller.command.concrete.RotateCommand;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.gui.swing.windows.ProjectView;
import raf.draft.dsw.gui.swing.windows.RoomView;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.ElementType;
import raf.draft.dsw.state.State;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RotateState implements State {

    @Override
    public void mouseClicked(int x, int y, RoomView roomView) {
        Point clickPoint = new Point(x, y);
        ItemPainter clickedPainter = roomView.clickedPainter(clickPoint);

        if (clickedPainter != null) {
            RoomItem item = (RoomItem) clickedPainter.getNode();

            if(roomView.getSelectedPainters().contains(clickedPainter)){

                RotateCommand rotateCommand = new RotateCommand(roomView, List.copyOf(roomView.getSelectedPainters()), MainFrame.getInstance().getMountedProject().getRotationDirection());
                roomView.getCommandManager().addCommand(rotateCommand);

                //LOGIC MIGRATED TO RotateCommand
//                boolean showErrorMessage = false;
//
//                // Validation: Who can, will approach
//                for(ItemPainter painter : roomView.getSelectedPainters()){
//                    RoomItem selectedItem = (RoomItem) painter.getNode();
//
//                    int currentRotation = selectedItem.getRotation();
//                    String rotationDirection = MainFrame.getInstance().getMountedProject().getRotationDirection();
//
//                    int newRotation = "RIGHT".equals(rotationDirection)
//                            ? (currentRotation + 1) % 4
//                            : (currentRotation + 3) % 4;
//
//                    // Validation
//                    boolean isValid = !roomView.outOfRoomBounds(selectedItem.getLocationX(), selectedItem.getLocationY(), selectedItem.getLength(), selectedItem.getWidth()) &&
//                            !roomView.isIntersectingWithNonSelectedItems(selectedItem, selectedItem.getLocationX(), selectedItem.getLocationY(), selectedItem.getLength(), selectedItem.getWidth());
//
//                    if (isValid) {
//                        // Swap dimensions for 90 or 270 rotations
//                        if (newRotation % 2 != currentRotation % 2) {
//                            int temp = selectedItem.getWidth();
//                            selectedItem.setWidth(selectedItem.getLength());
//                            selectedItem.setLength(temp);
//                        }
//
//                        // Updating rotation
//                        selectedItem.updateRotation(newRotation);
//
//                    } else {
//                        showErrorMessage = true;
//                    }
//                }
//
//                if(showErrorMessage){
//                    MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
//                }

            }else {

                List<ItemPainter> painterList = new ArrayList<>();
                painterList.add(clickedPainter);

                RotateCommand rotateCommand = new RotateCommand(roomView, painterList, MainFrame.getInstance().getMountedProject().getRotationDirection());
                roomView.getCommandManager().addCommand(rotateCommand);

                //LOGIC MIGRATED TO RotateCommand
//                int currentRotation = item.getRotation();
//                String rotationDirection = MainFrame.getInstance().getMountedProject().getRotationDirection();
//
//                int newRotation = "RIGHT".equals(rotationDirection)
//                        ? (currentRotation + 1) % 4
//                        : (currentRotation + 3) % 4;
//
//                // Validation
//                boolean isValid = !roomView.outOfRoomBounds(item.getLocationX(), item.getLocationY(), item.getLength(), item.getWidth()) &&
//                        !roomView.isIntersectingWithOtherItems(item, item.getLocationX(), item.getLocationY(), item.getLength(), item.getWidth());
//
//                if (isValid) {
//                    // Swap dimensions for 90° or 270° rotations
//                    if (newRotation % 2 != currentRotation % 2) {
//                        int temp = item.getWidth();
//                        item.setWidth(item.getLength());
//                        item.setLength(temp);
//                    }
//
//                    // Updating rotation
//                    item.updateRotation(newRotation);
//
//                } else {
//                    MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.ITEM_OUT_OF_BOUNDS);
//                }
            }
        }
    }

    @Override
    public void mousePressed(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseReleased(int x, int y, RoomView roomView) {

    }

    @Override
    public void mouseDragged(int x, int y, RoomView roomView) {

    }

    @Override
    public void createElement(int w, int l) {

    }

    @Override
    public void edit(String name, int width, int length) {

    }

    @Override
    public void prepare() {
        MainFrame.getInstance().getMountedProject().setDynamicDrawing(false);
        MainFrame.getInstance().getMountedProject().setDrawResizeBox(false);
        MainFrame.getInstance().getMountedProject().repaintRooms();
    }

    @Override
    public void setElementToAdd(ElementType elementType) {

    }

    @Override
    public RoomView getRoomView() {
        return null;
    }

    @Override
    public void direction(String direction) {
        if(MainFrame.getInstance().getMountedProject() != null){
            ProjectView projectView = MainFrame.getInstance().getMountedProject();
            projectView.setRotationDirection(direction);
        }
    }

}
