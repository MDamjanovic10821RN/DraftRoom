package raf.draft.dsw.controller.action.actions;

import raf.draft.dsw.controller.action.AbstractRoomAction;
import raf.draft.dsw.controller.messageGenerator.generator.ErrorCode;
import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.windows.EditProjectDialog;
import raf.draft.dsw.gui.swing.windows.RenameDialog;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.Project;
import raf.draft.dsw.model.structures.ProjectExplorer;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class EditNodeAction extends AbstractRoomAction {

    public EditNodeAction(){
        putValue(SMALL_ICON, loadIcon("/images/edit.png"));
        putValue(NAME, "Edit Node");
        putValue(SHORT_DESCRIPTION, "Edit Node");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        DraftNode selectedNode = MainFrame.getInstance().getDraftTree().getSelectedNode().getDraftNode();

        if(selectedNode == null){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.NO_NODES_SELECTED);
        }else if(selectedNode instanceof ProjectExplorer){
            MainFrame.getInstance().getMessageGenerator().generateMessage(ErrorCode.CANNOT_EDIT_NODE);
        }else if(selectedNode instanceof Project){
            EditProjectDialog editProjectDialog = new EditProjectDialog(this);
        }else{
            RenameDialog renameDialog = new RenameDialog(this);
        }
    }

    //dodate wrapper metode da bi se preko kontrolera model menjao (odrzavanje MVC arhitekture)
    public void editProject(Project project, String newName, String newAuthor, String newPath){
        project.edit(newName, newAuthor, newPath);
    }

    public void editName(DraftNode node, String newName){
        node.setNodeName(newName);
    }
}
