package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class ToiletPainter extends ItemPainter {

    public int scaledWidth;
    public int scaledLength;

    public ToiletPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {

        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        /** Kvadrat sa preko cije stranice je krug velicine stranice pa puta 3  **/

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        }else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();
        if(rotation != 0){
            // Calculate the center of the item for rotation
            int centerX = x + scaledWidth / 2;
            int centerY = y + scaledHeight / 2;

            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);

            // Adjusting positions for rotate



        }
        int tempX = x;
        int tempY = y;
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;

        } else if (rotation == 2) { // 180

            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;

        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        int largeWidth;
        int largeHeight;
        int middleWidth;
        int middleHeight;
        int smallWidth;
        int smallHeight;
        if(rotation == 1 || rotation == 3){
            // Define the dimensions for each shape (large, middle, small)
            largeWidth = scaledHeight;
            largeHeight = scaledWidth;

            // Make the middle shape bigger (larger relative to the large shape)
            middleWidth = (int) (largeWidth * 0.75);
            middleHeight = (int) (largeHeight * 0.75);

            smallWidth = middleWidth / 2;  // Small shape is half the size of the middle one
            smallHeight = middleHeight / 2;
        }else {
            // Define the dimensions for each shape (large, middle, small)
            largeWidth = scaledWidth;
            largeHeight = scaledHeight;

            // Make the middle shape bigger (larger relative to the large shape)
            middleWidth = (int) (largeWidth * 0.75);
            middleHeight = (int) (largeHeight * 0.75);

            smallWidth = middleWidth / 2;  // Small shape is half the size of the middle one
            smallHeight = middleHeight / 2;
        }

        // Rectangle for the largest shape
        int largeRectX = tempX;
        int largeRectY = tempY;

        if(getSelected()){
            g.setColor(Color.blue);
        }else{
            g.setColor(Color.lightGray); // Color for the largest shape
        }

        g.fillRect(largeRectX, largeRectY, largeWidth, largeHeight); // Draw rectangle

        // Draw the circle at the bottom of the largest shape to hide the bottom side
        int largeCircleRadius = largeWidth / 2;
        int largeCircleX = tempX;
        int largeCircleY = tempY + largeHeight - largeCircleRadius;

        if(getSelected()){
            g.setColor(Color.blue);
        }else{
            g.setColor(Color.lightGray); // Same color as rectangle

        }

        g.fillOval(largeCircleX, largeCircleY, largeWidth, largeWidth); // Circle at bottom

        // Make the lines of the largest object thicker
        g.setColor(Color.DARK_GRAY); // Line color
        g.setStroke(new BasicStroke(3)); // Make lines thicker
        int largeLineY = tempY + largeHeight / 7;
       // Draw the line under top side

        // draw line
        int middleX = tempX + (largeWidth - middleWidth) / 2;
        int middleY = tempY + (largeHeight - middleHeight) / 2 + 5;

        g.setColor(Color.white); // Color for the middle shape
        g.fillRect(middleX, middleY, middleWidth, middleHeight); // Middle rectangle

        // Draw the circle at the bottom of the middle shape
        int middleCircleRadius = middleWidth / 2;
        int middleCircleX = middleX;
        int middleCircleY = middleY + middleHeight - middleCircleRadius;
        g.setColor(Color.white);
        g.fillOval(middleCircleX, middleCircleY, middleWidth, middleWidth);

        // --- Draw the smallest shape ---
        int smallX = middleX + (middleWidth - smallWidth) / 2;
        int smallY = middleY + (middleHeight - smallHeight) / 2;

        g.setColor(Color.cyan);
        g.fillRect(smallX, smallY, smallWidth, smallHeight);

        // Draw the circle at the bottom of the small shape
        int smallCircleRadius = smallWidth / 2;
        int smallCircleX = smallX;
        int smallCircleY = smallY + smallHeight - smallCircleRadius;
        g.setColor(Color.cyan);
        g.fillOval(smallCircleX, smallCircleY, smallWidth, smallWidth); // Circle at bottom

        int smallCircleAboveLineRadius = scaledHeight/20;  // Small circle radius
        int smallCircleAboveLineX = tempX + (largeWidth - smallCircleAboveLineRadius * 2) / 2;
        int smallCircleAboveLineY = tempY + scaledHeight/30;  // Just under the top side

        g.setColor(Color.BLACK);  // Color for the small circle
        g.fillOval(smallCircleAboveLineX, smallCircleAboveLineY, smallCircleAboveLineRadius , smallCircleAboveLineRadius );


        //g.drawLine(tempX, largeLineY, tempY + largeWidth, largeLineY);

        if(rotation != 0){
            g.setTransform(oldTransform);
        }

        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setStroke(new BasicStroke(1));
            g.setColor(Color.lightGray);
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }

    }


    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
