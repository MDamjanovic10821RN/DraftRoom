package raf.draft.dsw.gui.swing.painters.itemPainters;

import raf.draft.dsw.gui.swing.MainFrame;
import raf.draft.dsw.gui.swing.painters.ItemPainter;
import raf.draft.dsw.model.nodes.DraftNode;
import raf.draft.dsw.model.structures.roomStructures.RoomItem;
import raf.draft.dsw.state.StateType;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class SinkPainter extends ItemPainter {

    public int scaledWidth;
    public int scaledLength;

    public SinkPainter(DraftNode node) {
        super(node);
    }

    @Override
    public void paint(Graphics2D g, RoomItem item, int scaledWidth, int scaledHeight) {

        this.scaledWidth = scaledWidth;
        this.scaledLength = scaledHeight;

        int x = 0;
        int y = 0;
        // Must dynamically render position if in MoveState
        if(MainFrame.getInstance().getMountedProject().getDynamicDrawing()){
            x = getTempX();
            y = getTempY();
        }else {
            // Position (top left) from node
            x = ((RoomItem) getNode()).getLocationX();
            y = ((RoomItem) getNode()).getLocationY();
        }

        // In case rotation of item != 0 (item is not upright)
        AffineTransform oldTransform = g.getTransform();
        int rotation = item.getRotation();
        if(rotation != 0){
            // Calculate the center of the item for rotation
            int centerX = x + scaledWidth / 2;
            int centerY = y + scaledHeight / 2;

            // Rotate the graphics context based on the item's rotation
            int rotationAngle = rotation * 90; // Convert rotation (0–3) to degrees
            // Apply rotation transform
            AffineTransform rotationTransform = new AffineTransform();
            rotationTransform.rotate(Math.toRadians(rotationAngle), x, y);
            g.transform(rotationTransform);

            // Adjusting positions for rotate


        }
        int tempX = x;
        int tempY = y;
        if (rotation == 1) { // 90
            tempY = y - scaledWidth;
        } else if (rotation == 2) { // 180
            tempX = tempX - scaledWidth;
            tempY = tempY - scaledHeight;
        } else if (rotation == 3) { // 270
            tempX = x - scaledHeight;
        }

        // Define triangle points


        if(getSelected()){
            g.setColor(Color.blue);
        }else {
            g.setColor(Color.LIGHT_GRAY); // Sink color
        }

        if(rotation == 1 || rotation == 3){
            int triangleBaseX1 = tempX;                        // Left corner of the base
            int triangleBaseX2 = tempX + scaledHeight;          // Right corner of the base
            int triangleBaseY = tempY + scaledWidth;          // Base y-coordinate
            int triangleApexX = tempX + scaledHeight / 2;       // Apex (middle of the base)
            int triangleApexY = tempY;                         // Apex y-coordinate

            // Draw the triangle
            int[] xPoints = {triangleBaseX1, triangleBaseX2, triangleApexX};
            int[] yPoints = {triangleBaseY, triangleBaseY, triangleApexY};
            g.fillPolygon(xPoints, yPoints, 3);

            g.setColor(Color.DARK_GRAY); // Border color
            g.drawPolygon(xPoints, yPoints, 3);

            // Calculate the center of the triangle (centroid)
            int centerX = (triangleBaseX1 + triangleBaseX2 + triangleApexX) / 3;
            int centerY = (triangleBaseY + triangleBaseY + triangleApexY) / 3;

            // Draw the outer circle in the center
            int outerCircleRadius = Math.min(scaledWidth, scaledHeight) / 10;
            int outerCircleDiameter = 2 * outerCircleRadius;
            int outerCircleX = centerX - outerCircleRadius;
            int outerCircleY = centerY - outerCircleRadius;

            g.setColor(Color.WHITE); // Outer circle color
            g.fillOval(outerCircleX, outerCircleY, outerCircleDiameter, outerCircleDiameter);

            g.setColor(Color.DARK_GRAY); // Outer circle border color
            g.drawOval(outerCircleX, outerCircleY, outerCircleDiameter, outerCircleDiameter);

            // Draw the inner smaller circle
            int innerCircleRadius = outerCircleRadius / 2;
            int innerCircleDiameter = 2 * innerCircleRadius;
            int innerCircleX = centerX - innerCircleRadius;
            int innerCircleY = centerY - innerCircleRadius;

            g.setColor(Color.GRAY); // Inner circle color
            g.fillOval(innerCircleX, innerCircleY, innerCircleDiameter, innerCircleDiameter);

            g.setColor(Color.DARK_GRAY); // Inner circle border color
            g.drawOval(innerCircleX, innerCircleY, innerCircleDiameter, innerCircleDiameter);

        }else{
            int triangleBaseX1 = tempX;                        // Left corner of the base
            int triangleBaseX2 = tempX + scaledWidth;          // Right corner of the base
            int triangleBaseY = tempY + scaledHeight;          // Base y-coordinate
            int triangleApexX = tempX + scaledWidth / 2;       // Apex (middle of the base)
            int triangleApexY = tempY;                         // Apex y-coordinate

            // Draw the triangle
            int[] xPoints = {triangleBaseX1, triangleBaseX2, triangleApexX};
            int[] yPoints = {triangleBaseY, triangleBaseY, triangleApexY};
            g.fillPolygon(xPoints, yPoints, 3);

            g.setColor(Color.DARK_GRAY); // Border color
            g.drawPolygon(xPoints, yPoints, 3);

            // Calculate the center of the triangle (centroid)
            int centerX = (triangleBaseX1 + triangleBaseX2 + triangleApexX) / 3;
            int centerY = (triangleBaseY + triangleBaseY + triangleApexY) / 3;

            // Draw the outer circle in the center
            int outerCircleRadius = Math.min(scaledWidth, scaledHeight) / 10;
            int outerCircleDiameter = 2 * outerCircleRadius;
            int outerCircleX = centerX - outerCircleRadius;
            int outerCircleY = centerY - outerCircleRadius;

            g.setColor(Color.WHITE); // Outer circle color
            g.fillOval(outerCircleX, outerCircleY, outerCircleDiameter, outerCircleDiameter);

            g.setColor(Color.DARK_GRAY); // Outer circle border color
            g.drawOval(outerCircleX, outerCircleY, outerCircleDiameter, outerCircleDiameter);

            // Draw the inner smaller circle
            int innerCircleRadius = outerCircleRadius / 2;
            int innerCircleDiameter = 2 * innerCircleRadius;
            int innerCircleX = centerX - innerCircleRadius;
            int innerCircleY = centerY - innerCircleRadius;

            g.setColor(Color.GRAY); // Inner circle color
            g.fillOval(innerCircleX, innerCircleY, innerCircleDiameter, innerCircleDiameter);

            g.setColor(Color.DARK_GRAY); // Inner circle border color
            g.drawOval(innerCircleX, innerCircleY, innerCircleDiameter, innerCircleDiameter);

        }


        if(rotation != 0){
            g.setTransform(oldTransform);
        }

        if(MainFrame.getInstance().getMountedProject().getDrawResizeBox()) {
            g.setColor(Color.lightGray);
            g.setStroke(new BasicStroke(1));
            drawBigBlueRectangle(g, x, y, scaledWidth, scaledHeight);
        }
    }


    @Override
    public boolean itemAt(Point pos) {
        // Top-left corner of painter
        int x = ((RoomItem) getNode()).getLocationX();
        int y = ((RoomItem) getNode()).getLocationY();

        // is point within rectangle bounds?
        boolean contains = (pos.x >= x && pos.x <= x + scaledWidth) &&
                (pos.y >= y && pos.y <= y + scaledLength);

        return contains;

    }
}
